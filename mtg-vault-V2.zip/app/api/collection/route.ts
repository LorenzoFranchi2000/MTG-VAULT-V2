import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { collectionSnapshot } from "@/lib/db/schema"
import { desc, eq } from "drizzle-orm"
import { headers } from "next/headers"

async function userId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return null
  return session.user.id
}

export async function GET() {
  const id = await userId()
  if (!id) return Response.json({ authenticated: false }, { status: 401 })
  const rows = await db.select().from(collectionSnapshot).where(eq(collectionSnapshot.userId, id)).orderBy(desc(collectionSnapshot.updatedAt)).limit(1)
  return Response.json({ authenticated: true, snapshot: rows[0] ?? null })
}

export async function PUT(request: Request) {
  const id = await userId()
  if (!id) return Response.json({ authenticated: false }, { status: 401 })
  const body = await request.json() as { payload?: unknown; version?: number }
  if (!body.payload || typeof body.payload !== "object") return Response.json({ error: "Invalid payload" }, { status: 400 })
  const existing = await db.select({ id: collectionSnapshot.id }).from(collectionSnapshot).where(eq(collectionSnapshot.userId, id)).limit(1)
  const now = new Date()
  if (existing[0]) {
    await db.update(collectionSnapshot).set({ payload: body.payload, version: body.version ?? 1, updatedAt: now }).where(eq(collectionSnapshot.id, existing[0].id))
  } else {
    await db.insert(collectionSnapshot).values({ id: crypto.randomUUID(), userId: id, payload: body.payload, version: body.version ?? 1, createdAt: now, updatedAt: now })
  }
  return Response.json({ ok: true, updatedAt: now.toISOString() })
}
