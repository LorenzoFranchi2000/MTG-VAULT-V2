// Scryfall API layer: search, card lookup, prints, and price refresh.
// Docs: https://scryfall.com/docs/api

import type { CardData, LangCode } from "./types"

const API = "https://api.scryfall.com"

function num(v: string | null | undefined): number | null {
  if (v == null) return null
  const n = Number.parseFloat(v)
  return Number.isFinite(n) ? n : null
}

// Map a raw Scryfall card object into our compact CardData.
export function mapCard(c: any, lang: LangCode = "en"): CardData {
  const face = c.card_faces && c.card_faces[0] && !c.image_uris ? c.card_faces[0] : c
  const imgs = c.image_uris || face.image_uris || {}
  const printedName =
    lang === "it" && c.printed_name ? c.printed_name : c.printed_name || undefined
  return {
    id: c.id,
    oracleId: c.oracle_id ?? face.oracle_id ?? c.id,
    name: c.name,
    printedName,
    setName: c.set_name,
    set: c.set,
    collectorNumber: c.collector_number,
    rarity: c.rarity,
    image: imgs.normal ?? imgs.large ?? imgs.small ?? null,
    imageLarge: imgs.large ?? imgs.normal ?? null,
    artCrop: imgs.art_crop ?? null,
    manaCost: c.mana_cost ?? face.mana_cost,
    cmc: typeof c.cmc === "number" ? c.cmc : typeof face.cmc === "number" ? face.cmc : undefined,
    typeLine: c.type_line ?? face.type_line,
    oracleText: c.oracle_text ?? face.oracle_text,
    flavorText: c.flavor_text ?? face.flavor_text,
    artist: c.artist,
    rulingsUri: c.rulings_uri,
    colors: c.colors ?? face.colors ?? [],
    colorIdentity: c.color_identity ?? [],
    legalities: c.legalities ?? {},
    eur: num(c.prices?.eur),
    eurFoil: num(c.prices?.eur_foil),
    usd: num(c.prices?.usd),
    usdFoil: num(c.prices?.usd_foil),
    tix: num(c.prices?.tix),
    tixFoil: num(c.prices?.tix_foil),
    cardmarketUrl: c.purchase_uris?.cardmarket,
    scryfallUrl: c.scryfall_uri,
  }
}

export async function autocomplete(q: string): Promise<string[]> {
  if (q.trim().length < 2) return []
  const res = await fetch(`${API}/cards/autocomplete?q=${encodeURIComponent(q)}`)
  if (!res.ok) return []
  const data = await res.json()
  return data.data ?? []
}

// Full-text search returning distinct prints, best image first.
export async function searchPrints(q: string, lang: LangCode): Promise<CardData[]> {
  if (q.trim().length < 2) return []
  const loc = scryfallLang(lang)
  const langParam = loc ? `&lang=${encodeURIComponent(loc)}` : ""
  const res = await fetch(
    `${API}/cards/search?q=${encodeURIComponent(q)}&unique=prints&order=released&dir=desc${langParam}`,
  )
  if (!res.ok) return []
  const data = await res.json()
  return (data.data ?? []).map((c: any) => mapCard(c, lang))
}

// Search returning ONE result per distinct card (no duplicate reprints).
// Used for the main search/scan step so the user picks the card first.
export async function searchCards(q: string, lang: LangCode): Promise<CardData[]> {
  if (q.trim().length < 2) return []
  const loc = scryfallLang(lang)
  const langParam = loc ? `&lang=${encodeURIComponent(loc)}` : ""
  const res = await fetch(
    `${API}/cards/search?q=${encodeURIComponent(q)}&unique=cards&order=name&dir=asc${langParam}`,
  )
  if (!res.ok) return []
  const data = await res.json()
  return (data.data ?? []).map((c: any) => mapCard(c, lang))
}

// All printings (reprints) of a given card, oldest → newest.
// Used by the edition picker once a card has been chosen.
export async function getPrints(card: CardData, lang: LangCode): Promise<CardData[]> {
  const q = card.oracleId
    ? `oracleid:${card.oracleId}`
    : `!"${card.name.replace(/"/g, "")}"`
  const res = await fetch(
    `${API}/cards/search?q=${encodeURIComponent(q)}&unique=prints&order=released&dir=asc`,
  )
  if (!res.ok) return [card]
  const data = await res.json()
  const prints = (data.data ?? []).map((c: any) => mapCard(c, lang))
  return prints.length ? prints : [card]
}

export async function namedExact(name: string, lang: LangCode): Promise<CardData | null> {
  const loc = scryfallLang(lang)
  const url = loc 
    ? `${API}/cards/named?exact=${encodeURIComponent(name)}&lang=${encodeURIComponent(loc)}`
    : `${API}/cards/named?exact=${encodeURIComponent(name)}`
  const res = await fetch(url)
  if (!res.ok) return null
  return mapCard(await res.json(), lang)
}

// Typo-tolerant lookup. Scryfall's fuzzy matcher is what turns OCR noise
// like "Sol Rlng" into Sol Ring — exact match cannot do that.
// Enhanced to support multilingual search for cards in any language.
export async function namedFuzzy(name: string, lang: LangCode): Promise<CardData | null> {
  if (name.trim().length < 3) return null
  
  // Try with language parameter first for multilingual support
  const loc = scryfallLang(lang)
  const url = loc 
    ? `${API}/cards/named?fuzzy=${encodeURIComponent(name)}&lang=${encodeURIComponent(loc)}`
    : `${API}/cards/named?fuzzy=${encodeURIComponent(name)}`
  
  const res = await fetch(url)
  if (!res.ok) return null
  return mapCard(await res.json(), lang)
}

export async function getBySetCollector(
  set: string,
  collectorNumber: string,
  mapLang: LangCode = "en",
  printedLang?: string,
): Promise<CardData | null> {
  const code = set.toLowerCase().trim()
  const cn = collectorNumber.toLowerCase().trim()
  if (!code || !cn) return null
  const loc = printedLang ? scryfallLang(printedLang) : undefined
  if (loc && loc !== "en") {
    const localized = await fetch(
      `${API}/cards/${encodeURIComponent(code)}/${encodeURIComponent(cn)}/${encodeURIComponent(loc)}`,
    )
    if (localized.ok) return mapCard(await localized.json(), mapLang)
  }
  const res = await fetch(`${API}/cards/${encodeURIComponent(code)}/${encodeURIComponent(cn)}`)
  if (!res.ok) return null
  return mapCard(await res.json(), mapLang)
}

const LANG_ALIAS: Record<string, string> = {
  en: "en",
  eng: "en",
  it: "it",
  ita: "it",
  de: "de",
  deu: "de",
  ger: "de",
  fr: "fr",
  fra: "fr",
  es: "es",
  esp: "es",
  spa: "es",
  pt: "pt",
  por: "pt",
  ja: "ja",
  jp: "ja",
  jpn: "ja",
  ko: "ko",
  kor: "ko",
  ru: "ru",
  rus: "ru",
  zhs: "zhs",
  cs: "zhs",
  cn: "zhs",
  zht: "zht",
  ph: "ph",
}

export function scryfallLang(code: string): string | undefined {
  return LANG_ALIAS[code.toLowerCase().trim()]
}

export async function searchPrintedName(text: string, mapLang: LangCode): Promise<CardData | null> {
  const cleaned = text.replace(/"/g, "").trim()
  if (cleaned.length < 3) return null
  const loc = scryfallLang(mapLang)
  const langParam = loc ? `&lang=${encodeURIComponent(loc)}` : ""
  const queries = [`printed_name:"${cleaned}" unique:prints${langParam}`, `printed_name:${cleaned} unique:cards${langParam}`]
  for (const q of queries) {
    const res = await fetch(`${API}/cards/search?q=${encodeURIComponent(q)}`)
    if (!res.ok) continue
    const data = await res.json()
    const first = data.data?.[0]
    if (first) return mapCard(first, mapLang)
  }
  return null
}

export async function getById(id: string, lang: LangCode): Promise<CardData | null> {
  const res = await fetch(`${API}/cards/${id}`)
  if (!res.ok) return null
  return mapCard(await res.json(), lang)
}

// Batch price/data refresh (max 75 ids per request per Scryfall rules).
export async function collectionByIds(ids: string[], lang: LangCode): Promise<CardData[]> {
  const out: CardData[] = []
  for (let i = 0; i < ids.length; i += 75) {
    const chunk = ids.slice(i, i + 75)
    const res = await fetch(`${API}/cards/collection`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifiers: chunk.map((id) => ({ id })) }),
    })
    if (!res.ok) continue
    const data = await res.json()
    for (const c of data.data ?? []) out.push(mapCard(c, lang))
    // be polite to the API
    if (i + 75 < ids.length) await new Promise((r) => setTimeout(r, 120))
  }
  return out
}

export type CardIdentifier =
  | { id: string }
  | { name: string }
  | { name: string; set: string }
  | { set: string; collector_number: string }

// Batch lookup by arbitrary identifiers (used by the collection importer).
// Scryfall accepts at most 75 identifiers per request and silently drops the
// ones it cannot match, which the caller reports as "not found".
export async function collectionByIdentifiers(
  identifiers: CardIdentifier[],
  lang: LangCode,
  onProgress?: (done: number, total: number) => void,
): Promise<CardData[]> {
  const out: CardData[] = []
  for (let i = 0; i < identifiers.length; i += 75) {
    const chunk = identifiers.slice(i, i + 75)
    try {
      const res = await fetch(`${API}/cards/collection`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifiers: chunk }),
      })
      if (res.ok) {
        const data = await res.json()
        for (const c of data.data ?? []) out.push(mapCard(c, lang))
      }
    } catch {
      // Network hiccup on one chunk must not abort the whole import.
    }
    onProgress?.(Math.min(i + 75, identifiers.length), identifiers.length)
    if (i + 75 < identifiers.length) await new Promise((r) => setTimeout(r, 120))
  }
  return out
}

export function imageOf(card: CardData): string | null {
  return card.image
}

export interface Ruling {
  date: string
  source: string
  comment: string
}

// Fetch official rulings for a card (lazy, only when the user expands them).
export async function getRulings(card: CardData): Promise<Ruling[]> {
  const url = card.rulingsUri || `${API}/cards/${card.id}/rulings`
  try {
    const res = await fetch(url)
    if (!res.ok) return []
    const data = await res.json()
    return (data.data ?? []).map((r: any) => ({
      date: r.published_at,
      source: r.source,
      comment: r.comment,
    }))
  } catch {
    return []
  }
}
