"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react"
import type { CardData, Entry, Folder, Settings } from "./types"
import { idbGet, idbSet } from "./idb"
import { translator, type TFunc } from "./i18n"
import { appendSnapshot, seedHistory, todayKey } from "./prices"
import { collectionByIds } from "./scryfall"
import { applyAppearance } from "./appearance"
import { remoteGet, remotePut } from "./sync"
import { useSession } from "./auth-client"

const K_ENTRIES = "entries"
const K_FOLDERS = "folders"
const K_SETTINGS = "settings"

const DEFAULT_SETTINGS: Settings = {
  lang: "it",
  theme: "system",
  currency: "eur",
  priceLevel: "average",
  priceMarket: "cardmarket",
  accent: "gold",
  customAccent: "#a964d6",
  selectionColor: "#f4f1ec",
  shape: "default",
  density: "comfortable",
  collectionBackground: "plain",
}

// A curated starter palette for folders (WUBRG + neutrals + extras).
export const FOLDER_COLORS = [
  "#e7c86b", // gold
  "#f4f0e6", // white
  "#5aa9e6", // blue
  "#3b3b45", // black
  "#e0685a", // red
  "#5fb37a", // green
  "#c47ad0", // multicolor
  "#b98a5a", // artifact / brown
  "#e08f4f", // orange
  "#7d8bd6", // periwinkle
]

interface Ctx {
  ready: boolean
  entries: Entry[]
  folders: Folder[]
  settings: Settings
  t: TFunc
  syncing: boolean
  cloudConnected: boolean
  lastCloudSync: string | null
  addEntry: (card: CardData, opts: Partial<Entry>) => Promise<void>
  addEntries: (items: { card: CardData; opts: Partial<Entry> }[]) => Promise<number>
  updateEntry: (id: string, patch: Partial<Entry>) => Promise<void>
  removeEntry: (id: string) => Promise<void>
  addFolder: (name: string, color: string, style?: Pick<Folder, "icon" | "background" | "iconColor" | "backgroundColor">) => Promise<Folder>
  updateFolder: (id: string, patch: Partial<Folder>) => Promise<void>
  removeFolder: (id: string) => Promise<void>
  setSettings: (patch: Partial<Settings>) => Promise<void>
  refreshPrices: () => Promise<void>
  exportData: () => string
  importData: (json: string) => Promise<boolean>
}

const CollectionContext = createContext<Ctx | null>(null)

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}

export function CollectionProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false)
  const [entries, setEntries] = useState<Entry[]>([])
  const [folders, setFolders] = useState<Folder[]>([])
  const entriesRef = useRef<Entry[]>([])
  const foldersRef = useRef<Folder[]>([])
  const [settings, setSettingsState] = useState<Settings>(DEFAULT_SETTINGS)
  const [syncing, setSyncing] = useState(false)
  const [lastCloudSync, setLastCloudSync] = useState<string | null>(null)
  const didSync = useRef(false)
  const cloudSyncReady = useRef(false)
  const { data: session } = useSession()
  // Timestamp of the newest collection document we know the server holds. Used
  // to detect when another device has written a newer copy than ours.
  const lastServerAt = useRef(0)
  const pushTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const suppressPush = useRef(false)

  // Adopt a collection document coming from the server (or the local cache),
  // updating refs, React state, and the offline cache in one shot. Writes made
  // while adopting must not bounce straight back to the server.
  const adopt = useCallback((e: Entry[], f: Folder[]) => {
    suppressPush.current = true
    entriesRef.current = e
    foldersRef.current = f
    setEntries(e)
    setFolders(f)
    void idbSet(K_ENTRIES, e)
    void idbSet(K_FOLDERS, f)
    // Release the guard after the state updates have been queued.
    setTimeout(() => {
      suppressPush.current = false
    }, 0)
  }, [])

  // Debounced push of the whole collection to the host. Batches rapid scanner
  // adds into a single request.
  const schedulePush = useCallback(() => {
    if (suppressPush.current) return
    if (pushTimer.current) clearTimeout(pushTimer.current)
    pushTimer.current = setTimeout(async () => {
      const at = await remotePut(entriesRef.current, foldersRef.current)
      if (at) lastServerAt.current = at
    }, 500)
  }, [])

  // Pull the latest collection from the host and adopt it if it is newer than
  // what we currently hold (i.e. another device changed something).
  const pullRemote = useCallback(async () => {
    const doc = await remoteGet()
    if (!doc) return
    if (doc.updatedAt > lastServerAt.current) {
      lastServerAt.current = doc.updatedAt
      adopt(doc.entries, doc.folders)
    }
  }, [adopt])

  // Load persisted state: server first (shared across devices), then fall back
  // to the local IndexedDB cache when the host is unreachable.
  useEffect(() => {
    ;(async () => {
      const s = await idbGet<Settings>(K_SETTINGS)
      if (s) setSettingsState({ ...DEFAULT_SETTINGS, ...s })

      const doc = await remoteGet()
      if (doc) {
        lastServerAt.current = doc.updatedAt
        adopt(doc.entries, doc.folders)
        // If the server is empty but this device has a local cache, seed the
        // server from the cache so existing collections aren't lost on first run.
        if (doc.entries.length === 0 && doc.folders.length === 0) {
          const [ce, cf] = await Promise.all([idbGet<Entry[]>(K_ENTRIES), idbGet<Folder[]>(K_FOLDERS)])
          if ((ce && ce.length) || (cf && cf.length)) {
            adopt(ce ?? [], cf ?? [])
            const at = await remotePut(ce ?? [], cf ?? [])
            if (at) lastServerAt.current = at
          }
        }
      } else {
        const [e, f] = await Promise.all([idbGet<Entry[]>(K_ENTRIES), idbGet<Folder[]>(K_FOLDERS)])
        if (e) {
          entriesRef.current = e
          setEntries(e)
        }
        if (f) {
          foldersRef.current = f
          setFolders(f)
        }
      }
      setReady(true)
    })()
  }, [adopt])

  // Account sync: merge local IndexedDB with the private Neon snapshot on login.
  useEffect(() => {
    if (!ready || !session?.user || cloudSyncReady.current) return
    cloudSyncReady.current = true
    setSyncing(true)
    void (async () => {
      try {
        const response = await fetch("/api/collection", { cache: "no-store" })
        if (!response.ok) return
        const result = await response.json() as { snapshot?: { payload?: { entries?: Entry[]; folders?: Folder[] } } | null }
        const cloud = result.snapshot?.payload
        const mergedEntries = Array.from(new Map([...(cloud?.entries ?? []), ...entriesRef.current].map((entry) => [entry.id, entry])).values())
        const mergedFolders = Array.from(new Map([...(cloud?.folders ?? []), ...foldersRef.current].map((folder) => [folder.id, folder])).values())
        adopt(mergedEntries, mergedFolders)
        const saved = await fetch("/api/collection", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ payload: { entries: mergedEntries, folders: mergedFolders, settings }, version: 1 }) })
        if (saved.ok) setLastCloudSync(new Date().toISOString())
      } catch {
        // IndexedDB remains the offline source of truth.
      } finally {
        setSyncing(false)
      }
    })()
  }, [ready, session?.user, settings, adopt])

  // Push later local edits to the authenticated account with a small debounce.
  useEffect(() => {
    if (!ready || !session?.user || !cloudSyncReady.current) return
    const timer = window.setTimeout(() => {
      void fetch("/api/collection", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ payload: { entries, folders, settings }, version: 1 }) }).then((response) => {
        if (response.ok) setLastCloudSync(new Date().toISOString())
      }).catch(() => undefined)
    }, 700)
    return () => window.clearTimeout(timer)
  }, [ready, session?.user, entries, folders, settings])

  // Keep devices in sync: re-pull when the tab regains focus and on a light
  // interval while it stays open.
  useEffect(() => {
    if (!ready) return
    const onVisible = () => {
      if (document.visibilityState === "visible") void pullRemote()
    }
    document.addEventListener("visibilitychange", onVisible)
    window.addEventListener("focus", onVisible)
    const id = setInterval(() => void pullRemote(), 20000)
    return () => {
      document.removeEventListener("visibilitychange", onVisible)
      window.removeEventListener("focus", onVisible)
      clearInterval(id)
    }
  }, [ready, pullRemote])

  // Apply theme to <html>.
  useEffect(() => {
    if (!ready) return
    const root = document.documentElement
    const apply = (dark: boolean) => root.classList.toggle("dark", dark)
    if (settings.theme === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)")
      apply(mq.matches)
      const handler = (ev: MediaQueryListEvent) => apply(ev.matches)
      mq.addEventListener("change", handler)
      return () => mq.removeEventListener("change", handler)
    }
    apply(settings.theme === "dark")
  }, [settings.theme, ready])

  // Apply accent color + corner shape as inline CSS variables on <html>.
  useEffect(() => {
    if (!ready) return
    applyAppearance(settings.accent, settings.shape, settings.customAccent, settings.selectionColor)
  }, [settings.accent, settings.customAccent, settings.selectionColor, settings.shape, ready])

  // Keep a mutable snapshot alongside React state. The scanner can add cards
  // rapidly, so mutations must never close over an older `entries` array.
  const persistEntries = useCallback((update: Entry[] | ((prev: Entry[]) => Entry[])) => {
    const prev = entriesRef.current
    const next = typeof update === "function" ? update(prev) : update
    entriesRef.current = next
    setEntries(next)
    void idbSet(K_ENTRIES, next)
    schedulePush()
  }, [schedulePush])
  const persistFolders = useCallback((update: Folder[] | ((prev: Folder[]) => Folder[])) => {
    const prev = foldersRef.current
    const next = typeof update === "function" ? update(prev) : update
    foldersRef.current = next
    setFolders(next)
    void idbSet(K_FOLDERS, next)
    schedulePush()
  }, [schedulePush])

  const t = useMemo(() => translator(settings.lang), [settings.lang])

  const addEntry = useCallback<Ctx["addEntry"]>(
    async (card, opts) => {
      const entry: Entry = {
        id: uid(),
        card,
        quantity: opts.quantity ?? 1,
        foil: opts.foil ?? false,
        condition: opts.condition ?? "NM",
        language: opts.language,
        purchasePrice: opts.purchasePrice,
        folderId: opts.folderId ?? null,
        position: opts.position ?? "",
        note: opts.note,
        addedAt: opts.addedAt ?? Date.now(),
        priceHistory: seedHistory(card),
        lastPriceSync: todayKey(),
      }
      persistEntries((prev) => [entry, ...prev])
    },
    [persistEntries],
  )

  // Bulk insert used by the CSV/TXT importer: one state write for the whole
  // batch, so importing hundreds of cards stays responsive.
  const addEntries = useCallback<Ctx["addEntries"]>(
    async (items) => {
      if (items.length === 0) return 0
      const now = Date.now()
      const created: Entry[] = items.map(({ card, opts }, i) => ({
        id: uid() + i.toString(36),
        card,
        quantity: opts.quantity ?? 1,
        foil: opts.foil ?? false,
        condition: opts.condition ?? "NM",
        language: opts.language,
        purchasePrice: opts.purchasePrice,
        folderId: opts.folderId ?? null,
        position: opts.position ?? "",
        note: opts.note,
        addedAt: opts.addedAt ?? now,
        priceHistory: seedHistory(card),
        lastPriceSync: todayKey(),
      }))
      persistEntries((prev) => [...created, ...prev])
      return created.length
    },
    [persistEntries],
  )

  const updateEntry = useCallback<Ctx["updateEntry"]>(
    async (id, patch) => {
      persistEntries((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)))
    },
    [persistEntries],
  )

  const removeEntry = useCallback<Ctx["removeEntry"]>(
    async (id) => {
      persistEntries((prev) => prev.filter((e) => e.id !== id))
    },
    [persistEntries],
  )

  const addFolder = useCallback<Ctx["addFolder"]>(
    async (name, color, style) => {
      const folder: Folder = { id: uid(), name, color, createdAt: Date.now(), ...style }
      persistFolders((prev) => [...prev, folder])
      return folder
    },
    [persistFolders],
  )

  const updateFolder = useCallback<Ctx["updateFolder"]>(
    async (id, patch) => {
      persistFolders((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f)))
    },
    [persistFolders],
  )

  const removeFolder = useCallback<Ctx["removeFolder"]>(
    async (id) => {
      persistFolders((prev) => prev.filter((f) => f.id !== id))
      persistEntries((prev) => prev.map((e) => (e.folderId === id ? { ...e, folderId: null } : e)))
    },
    [persistFolders, persistEntries],
  )

  const setSettings = useCallback<Ctx["setSettings"]>(
    async (patch) => {
      const next = { ...settings, ...patch }
      setSettingsState(next)
      await idbSet(K_SETTINGS, next)
    },
    [settings],
  )

  const refreshPrices = useCallback(async () => {
    if (entries.length === 0) return
    setSyncing(true)
    try {
      const ids = Array.from(new Set(entries.map((e) => e.card.id)))
      const fresh = await collectionByIds(ids, settings.lang)
      const byId = new Map(fresh.map((c) => [c.id, c]))
      const today = todayKey()
      persistEntries((prev) =>
        prev.map((e) => {
          const c = byId.get(e.card.id)
          if (!c) return e
          return {
            ...e,
            card: { ...e.card, ...c },
            priceHistory: appendSnapshot(e.priceHistory, c),
            lastPriceSync: today,
          }
        }),
      )
    } finally {
      setSyncing(false)
    }
  }, [entries, settings.lang, persistEntries])

  // One automatic price sync per day, in the background after load.
  useEffect(() => {
    if (!ready || didSync.current || entries.length === 0) return
    const today = todayKey()
    const stale = entries.some((e) => e.lastPriceSync !== today)
    if (!stale) {
      didSync.current = true
      return
    }
    didSync.current = true
    const id = setTimeout(() => void refreshPrices(), 1500)
    return () => clearTimeout(id)
  }, [ready, entries, refreshPrices])

  const exportData = useCallback(() => {
    return JSON.stringify({ version: 1, entries, folders, settings }, null, 2)
  }, [entries, folders, settings])

  const importData = useCallback<Ctx["importData"]>(
    async (json) => {
      try {
        const data = JSON.parse(json)
        if (Array.isArray(data.entries)) persistEntries(data.entries)
        if (Array.isArray(data.folders)) persistFolders(data.folders)
        if (data.settings) await setSettings(data.settings)
        return true
      } catch {
        return false
      }
    },
    [persistEntries, persistFolders, setSettings],
  )

  const value: Ctx = {
    ready,
    entries,
    folders,
    settings,
    t,
    syncing,
    cloudConnected: Boolean(session?.user),
    lastCloudSync,
    addEntry,
    addEntries,
    updateEntry,
    removeEntry,
    addFolder,
    updateFolder,
    removeFolder,
    setSettings,
    refreshPrices,
    exportData,
    importData,
  }

  return <CollectionContext.Provider value={value}>{children}</CollectionContext.Provider>
}

export function useCollection(): Ctx {
  const ctx = useContext(CollectionContext)
  if (!ctx) throw new Error("useCollection must be used within CollectionProvider")
  return ctx
}
