// Price history helpers: seed a plausible 30-day estimate on first sight,
// then append real daily snapshots so genuine history accrues over time.

import type { CardData, Entry, PricePoint } from "./types"

function localKey(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

export function todayKey(d = new Date()): string {
  return localKey(d)
}

function dayKey(offsetFromToday: number): string {
  const d = new Date()
  d.setHours(12, 0, 0, 0)
  d.setDate(d.getDate() - offsetFromToday)
  return localKey(d)
}

// Deterministic pseudo-random from a string seed (stable per card).
function seeded(seed: string): () => number {
  let h = 2166136261
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return () => {
    h += 0x6d2b79f5
    let t = h
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// Build an estimated back-fill ending at the real current price.
export function seedHistory(card: CardData): PricePoint[] {
  const rnd = seeded(card.id)
  const points: PricePoint[] = []
  const baseEur = card.eur ?? card.eurFoil ?? 0.5
  const baseUsd = card.usd ?? card.usdFoil ?? 0.5
  // Random-walk backwards from today's real price.
  let eur = baseEur
  let usd = baseUsd
  const raw: { eur: number; usd: number }[] = [{ eur, usd }]
  for (let i = 1; i < 30; i++) {
    const drift = (rnd() - 0.5) * 0.06 // +/-3% daily wiggle
    eur = Math.max(0.02, eur * (1 - drift))
    usd = Math.max(0.02, usd * (1 - drift))
    raw.push({ eur, usd })
  }
  raw.reverse() // oldest first
  for (let i = 0; i < 30; i++) {
    const isToday = i === 29
    points.push({
      date: dayKey(29 - i),
      eur: isToday ? baseEur : Math.round(raw[i].eur * 100) / 100,
      usd: isToday ? baseUsd : Math.round(raw[i].usd * 100) / 100,
      estimated: !isToday,
    })
  }
  return points
}

// Append/replace today's real snapshot and trim to ~90 days.
export function appendSnapshot(history: PricePoint[], card: CardData): PricePoint[] {
  const key = todayKey()
  const filtered = history.filter((p) => p.date !== key)
  filtered.push({
    date: key,
    eur: card.eur ?? card.eurFoil ?? null,
    usd: card.usd ?? card.usdFoil ?? null,
    estimated: false,
  })
  filtered.sort((a, b) => a.date.localeCompare(b.date))
  return filtered.slice(-90)
}

export type PriceMarket = "cardmarket" | "tcgplayer" | "cardhoarder"

// Scryfall is the verified aggregator for these three sources:
// Cardmarket (EUR), TCGplayer (USD), and Cardhoarder (MTGO TIX).
export function entryUnitPrice(entry: Entry, currency: "eur" | "usd", market: PriceMarket = currency === "eur" ? "cardmarket" : "tcgplayer"): number {
  const c = entry.card
  if (market === "cardhoarder") return (entry.foil ? c.tixFoil ?? c.tix : c.tix) ?? 0
  if (market === "cardmarket") return (entry.foil ? c.eurFoil ?? c.eur : c.eur) ?? 0
  return (entry.foil ? c.usdFoil ?? c.usd : c.usd) ?? 0
}

export function entryValue(entry: Entry, currency: "eur" | "usd"): number {
  return entryUnitPrice(entry, currency) * entry.quantity
}

// 30-day % change from the price history for an entry.
export function trend(history: PricePoint[], currency: "eur" | "usd"): number | null {
  const series = history.map((p) => (currency === "eur" ? p.eur : p.usd)).filter((v): v is number => v != null)
  if (series.length < 2) return null
  const first = series[0]
  const last = series[series.length - 1]
  if (!first) return null
  return ((last - first) / first) * 100
}

// Amount invested in an entry (price paid). Falls back to current value
// for legacy entries that were added before purchase price was tracked.
export function entryInvested(entry: Entry, currency: "eur" | "usd"): number {
  if (entry.purchasePrice != null) return entry.purchasePrice * entry.quantity
  return entryValue(entry, currency)
}

export interface CollectionStats {
  invested: number
  current: number
  winPct: number | null
  copies: number
  unique: number
}

export function collectionStats(entries: Entry[], currency: "eur" | "usd"): CollectionStats {
  let invested = 0
  let current = 0
  let copies = 0
  for (const e of entries) {
    invested += entryInvested(e, currency)
    current += entryValue(e, currency)
    copies += e.quantity
  }
  const winPct = invested > 0 ? ((current - invested) / invested) * 100 : null
  return { invested, current, winPct, copies, unique: entries.length }
}

export type RarityKey = "mythic" | "rare" | "uncommon" | "common"
export type ColorKey = "W" | "U" | "B" | "R" | "G" | "C"

export interface CollectionComposition {
  rarity: Record<RarityKey, number>
  colors: Record<ColorKey, number>
  dominantColor: ColorKey | null
}

// Break the collection down by rarity and color (weighted by quantity).
// Dominant color = the identity color present on the most copies; ties resolve
// by WUBRG order. Colorless-only cards count toward "C".
export function collectionComposition(entries: Entry[]): CollectionComposition {
  const rarity: Record<RarityKey, number> = { mythic: 0, rare: 0, uncommon: 0, common: 0 }
  const colors: Record<ColorKey, number> = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }

  for (const e of entries) {
    const q = e.quantity
    const r = (e.card.rarity || "").toLowerCase()
    if (r === "mythic") rarity.mythic += q
    else if (r === "rare") rarity.rare += q
    else if (r === "uncommon") rarity.uncommon += q
    else rarity.common += q

    const id = e.card.colorIdentity?.length ? e.card.colorIdentity : e.card.colors
    if (!id || id.length === 0) {
      colors.C += q
    } else {
      for (const c of id) {
        if (c === "W" || c === "U" || c === "B" || c === "R" || c === "G") colors[c] += q
      }
    }
  }

  const order: ColorKey[] = ["W", "U", "B", "R", "G", "C"]
  let dominantColor: ColorKey | null = null
  let max = 0
  for (const k of order) {
    if (colors[k] > max) {
      max = colors[k]
      dominantColor = k
    }
  }
  return { rarity, colors, dominantColor }
}

// Aggregate every entry's price history into a single collection-value series
// (value * quantity summed per date). Used by the statistics chart.
export function collectionSeries(entries: Entry[], currency: "eur" | "usd"): PricePoint[] {
  const byDate = new Map<string, { total: number; estimated: boolean }>()
  for (const e of entries) {
    for (const p of e.priceHistory) {
      const v = currency === "eur" ? p.eur : p.usd
      if (v == null) continue
      const prev = byDate.get(p.date) ?? { total: 0, estimated: false }
      prev.total += v * e.quantity
      prev.estimated = prev.estimated || p.estimated
      byDate.set(p.date, prev)
    }
  }
  return Array.from(byDate.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([date, { total, estimated }]) => ({
      date,
      eur: currency === "eur" ? Math.round(total * 100) / 100 : null,
      usd: currency === "usd" ? Math.round(total * 100) / 100 : null,
      estimated,
    }))
}
