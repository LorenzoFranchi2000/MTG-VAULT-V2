"use client"

import { useState } from "react"
import { Cloud, LogIn, LogOut, UserPlus } from "lucide-react"
import { signIn, signOut, signUp, useSession } from "@/lib/auth-client"

export function AccountPanel() {
  const { data: session, isPending } = useSession()
  const [mode, setMode] = useState<"sign-in" | "sign-up">("sign-in")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (isSubmitting) return
    setMessage("")
    setIsSubmitting(true)
    try {
      const result = mode === "sign-in"
        ? await signIn.email({ email: email.trim(), password })
        : await signUp.email({ email: email.trim(), password, name: name.trim() || email.trim().split("@")[0] })
      if (result.error) {
        const code = result.error.code ?? ""
        if (mode === "sign-up" && (code.includes("USER_ALREADY_EXISTS") || code.includes("EMAIL_ALREADY_EXISTS"))) {
          setMessage("Questa email è già registrata. Prova ad accedere.")
        } else if (mode === "sign-up" && code.includes("PASSWORD")) {
          setMessage("La password non rispetta i requisiti richiesti.")
        } else if (mode === "sign-in") {
          setMessage("Email o password non corrette.")
        } else {
          setMessage("Registrazione non riuscita. Controlla i dati e riprova.")
        }
      } else {
        setMessage(mode === "sign-up" ? "Account creato. La collezione verrà sincronizzata." : "Accesso completato. La collezione verrà sincronizzata.")
      }
    } catch {
      setMessage("Servizio account non disponibile. Riprova tra poco.")
    } finally {
      setIsSubmitting(false)
    }
  }
  if (isPending) return <div className="rounded-2xl border border-border bg-card p-4 text-sm text-muted-foreground">Controllo account…</div>
  if (session?.user) return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-3">
        <span className="grid size-10 place-items-center rounded-full bg-accent text-sm font-bold">{session.user.name?.slice(0, 1).toUpperCase()}</span>
        <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{session.user.name}</div><div className="truncate text-xs text-muted-foreground">{session.user.email}</div></div>
        <button onClick={() => void signOut()} className="grid size-9 place-items-center rounded-full border border-border" aria-label="Esci"><LogOut className="size-4" /></button>
      </div>
      <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground"><Cloud className="size-4 text-primary" /> Collezione sincronizzata tra dispositivi</div>
    </div>
  )
  return (
    <form onSubmit={submit} className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-3 flex items-start gap-3"><Cloud className="mt-0.5 size-5 text-primary" /><div><div className="text-sm font-semibold">Account e sincronizzazione</div><p className="text-xs leading-relaxed text-muted-foreground">Accedi per ritrovare la tua collezione su telefono e PC.</p></div></div>
      {mode === "sign-up" && <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" className="mb-2 h-10 w-full rounded-xl border border-border bg-background px-3 text-sm" />}
      <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="mb-2 h-10 w-full rounded-xl border border-border bg-background px-3 text-sm" />
      <input required minLength={8} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password (min. 8 caratteri)" className="h-10 w-full rounded-xl border border-border bg-background px-3 text-sm" />
      <button disabled={isSubmitting} className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60">{mode === "sign-in" ? <LogIn className="size-4" /> : <UserPlus className="size-4" />}{isSubmitting ? "Attendi…" : mode === "sign-in" ? "Accedi" : "Crea account"}</button>
      <button type="button" onClick={() => setMode(mode === "sign-in" ? "sign-up" : "sign-in")} className="mt-3 w-full text-xs text-muted-foreground underline">{mode === "sign-in" ? "Non hai un account? Registrati" : "Hai già un account? Accedi"}</button>
      {message && <p className="mt-3 text-center text-xs text-muted-foreground">{message}</p>}
    </form>
  )
}
