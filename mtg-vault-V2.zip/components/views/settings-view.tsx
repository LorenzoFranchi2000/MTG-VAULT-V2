"use client"

import { useRef } from "react"
import { Download, HardDrive, Upload } from "lucide-react"
import type { AccentKey, DensityKey, LangCode, Settings, ShapeKey } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { ACCENTS, DENSITIES, SHAPES } from "@/lib/appearance"
import type { BackgroundKey } from "@/lib/folder-style"
import { BackgroundPicker } from "@/components/folder-style-picker"
import { ImportExportPanel } from "@/components/import-export-panel"
import { useToast } from "@/components/ui/toast"
import { AccountPanel } from "@/components/account-panel"

export function SettingsView() {
  const { settings, setSettings, t, exportData, importData, cloudConnected, syncing, lastCloudSync } = useCollection()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)

  const doExport = () => {
    const blob = new Blob([exportData()], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `mtg-vault-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const doImport = async (file: File) => {
    const text = await file.text()
    const ok = await importData(text)
    toast(ok ? t("importDone") : t("importErr"))
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-4 lg:max-w-5xl lg:px-8">
      <Section title="Account e sincronizzazione" defaultOpen>
        <AccountPanel />
        <div className="mt-2 flex items-center gap-2 px-1 text-xs text-muted-foreground">
          <span className={`size-2 rounded-full ${cloudConnected ? (syncing ? "animate-pulse bg-primary" : "bg-emerald-500") : "bg-muted-foreground"}`} />
          {cloudConnected ? (syncing ? "Sincronizzazione in corso…" : lastCloudSync ? `Sincronizzato alle ${new Date(lastCloudSync).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "Account collegato") : "Solo dispositivo: accedi per sincronizzare tra PC e telefono"}
        </div>
      </Section>

      <Section title={t("currency")} defaultOpen>
        <Segmented
          value={settings.currency}
          options={[
            { value: "eur", label: "EUR € (Cardmarket)" },
            { value: "usd", label: "USD $" },
          ]}
          onChange={(v) => void setSettings({ currency: v as Settings["currency"] })}
        />
      </Section>

      <Section title="Prezzi" defaultOpen>
        <div className="settings-panel space-y-3 rounded-2xl p-4">
          <div className="text-xs font-medium text-muted-foreground">Valore mostrato</div>
          <Segmented value={settings.priceLevel} options={[{ value: "low", label: "LOW" }, { value: "average", label: "AVG" }, { value: "high", label: "HIGH" }]} onChange={(v) => void setSettings({ priceLevel: v as Settings["priceLevel"] })} />
          <div className="text-xs font-medium text-muted-foreground">Marketplace</div>
          <Segmented
            value={settings.priceMarket}
            options={[
              { value: "cardmarket", label: "Cardmarket · EUR" },
              { value: "tcgplayer", label: "TCGplayer · USD" },
            ]}
            onChange={(v) => void setSettings({ priceMarket: v as Settings["priceMarket"], currency: v === "tcgplayer" ? "usd" : "eur" })}
          />
          <p className="text-xs leading-relaxed text-muted-foreground">I prezzi vengono aggiornati tramite Scryfall, che espone i dati pubblici di Cardmarket in EUR e TCGplayer in USD. Il cambio marketplace aggiorna automaticamente anche la valuta visualizzata.</p>
        </div>
      </Section>

      <Section title={t("language")}>
        <Segmented
          value={settings.lang}
          options={[
            { value: "it", label: "Italiano" },
            { value: "en", label: "English" },
          ]}
          onChange={(v) => void setSettings({ lang: v as LangCode })}
        />
      </Section>

      <Section title={t("theme")}>
        <Segmented
          value={settings.theme}
          options={[
            { value: "light", label: t("themeLight") },
            { value: "dark", label: t("themeDark") },
            { value: "system", label: t("themeSystem") },
          ]}
          onChange={(v) => void setSettings({ theme: v as Settings["theme"] })}
        />
      </Section>

      <Section title={t("appearance")}>
          {/* Accent color */}
          <div className="mb-2 text-xs font-medium text-muted-foreground">Preset</div>
          <div className="flex flex-wrap gap-2.5">
            {(Object.keys(ACCENTS) as AccentKey[]).map((k) => {
              const on = settings.accent === k
              return (
                <button
                  key={k}
                  onClick={() => void setSettings({ accent: k })}
                  aria-pressed={on}
                  aria-label={t(ACCENTS[k].labelKey)}
                  className={`size-9 rounded-full transition-all ${
                    on ? "ring-2 ring-foreground ring-offset-2 ring-offset-card" : "opacity-80"
                  }`}
                  style={{ backgroundColor: ACCENTS[k].swatch }}
                />
              )
            })}
          </div>
          <label className="mt-3 flex items-center gap-3 rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm">
            <input type="color" value={settings.customAccent} onChange={(e) => void setSettings({ accent: "custom" as AccentKey, customAccent: e.target.value })} className="size-9 cursor-pointer rounded-full border-0 bg-transparent p-0" aria-label="Scegli colore personalizzato" />
            <span><span className="block font-semibold">Colore personalizzato</span><span className="font-mono text-xs text-muted-foreground">Scegli dalla gamma completa</span></span>
          </label>

          <label className="mt-3 flex items-center gap-3 rounded-xl border border-border bg-background/60 px-3 py-2.5 text-sm">
            <input type="color" value={settings.selectionColor} onChange={(e) => void setSettings({ selectionColor: e.target.value })} className="size-9 cursor-pointer rounded-full border-0 bg-transparent p-0" aria-label="Colore delle opzioni selezionate" />
            <span><span className="block font-semibold">Colore selezione</span><span className="font-mono text-xs text-muted-foreground">Segmenti, filtri e modalità attiva</span></span>
          </label>

          {/* Corner shape */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("shape")}</div>
          <Segmented
            value={settings.shape}
            options={(Object.keys(SHAPES) as ShapeKey[]).map((k) => ({ value: k, label: t(SHAPES[k].labelKey) }))}
            onChange={(v) => void setSettings({ shape: v as ShapeKey })}
          />

          {/* Grid density */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("layoutDensity")}</div>
          <Segmented
            value={settings.density}
            options={(Object.keys(DENSITIES) as DensityKey[]).map((k) => ({
              value: k,
              label: t(DENSITIES[k].labelKey),
            }))}
            onChange={(v) => void setSettings({ density: v as DensityKey })}
          />

          {/* Backdrop for the collection / folder views */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("collectionBackground")}</div>
          <BackgroundPicker
            value={settings.collectionBackground}
            color={ACCENTS[settings.accent].swatch}
            onChange={(v: BackgroundKey) => void setSettings({ collectionBackground: v })}
            t={t}
          />
      </Section>

      <Section title={t("dataManagement")}>
        <ImportExportPanel />
      </Section>

      <Section title={t("storage")}>
        <div className="settings-panel rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <HardDrive className="mt-0.5 size-5 shrink-0 text-muted-foreground" />
            <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{t("storageDesc")}</p>
          </div>
          <div className="mt-4 flex gap-2.5">
            <button
              onClick={doExport}
              className="flex flex-1 items-center justify-center gap-2 rounded-full border border-border py-3 text-sm font-semibold"
            >
              <Download className="size-4" />
              {t("exportData")}
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="flex flex-1 items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground"
            >
              <Upload className="size-4" />
              {t("importData")}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) void doImport(f)
                e.target.value = ""
              }}
            />
          </div>
        </div>
      </Section>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        MTG Vault · Magic: The Gathering collection manager · data by Scryfall
      </p>
    </div>
  )
}

function Section({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  return (
    <details open={defaultOpen || undefined} className="group mb-6">
      <summary className="mb-2 flex cursor-pointer list-none items-center justify-between px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground [&::-webkit-details-marker]:hidden">
        <span>{title}</span>
        <span aria-hidden className="text-[11px] transition-transform group-open:rotate-180">⌄</span>
      </summary>
      <div>{children}</div>
    </details>
  )
}

function Segmented({
  value,
  options,
  onChange,
}: {
  value: string
  options: { value: string; label: string }[]
  onChange: (v: string) => void
}) {
  return (
    <div className="flex gap-1.5 rounded-2xl border border-border bg-card p-1.5">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
            value === o.value ? "text-foreground" : "text-muted-foreground"
          }`}
          style={value === o.value ? { backgroundColor: "var(--selection-color)" } : undefined}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
