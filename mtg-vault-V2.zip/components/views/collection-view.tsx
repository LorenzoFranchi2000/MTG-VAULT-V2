"use client"

import { useMemo, useState } from "react"
import { ChevronRight, LayoutGrid, Layers, List, RefreshCw, Search, TrendingUp } from "lucide-react"
import type { Entry } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { money, signedPct } from "@/lib/format"
import { collectionStats, entryValue } from "@/lib/prices"
import { ACCENTS, gridColsClass } from "@/lib/appearance"
import { backgroundClass, backgroundStyle } from "@/lib/folder-style"
import { CardRow } from "@/components/card-row"
import { CardTile } from "@/components/card-tile"
import { StatsView } from "@/components/views/stats-view"

type Sort = "recent" | "name" | "value"
type ViewMode = "list" | "grid"

export function CollectionView({ onOpen }: { onOpen: (e: Entry) => void }) {
  const { entries, folders, settings, t, refreshPrices, syncing } = useCollection()
  const [q, setQ] = useState("")
  const [folderFilter, setFolderFilter] = useState<string | "all">("all")
  const [sort, setSort] = useState<Sort>("recent")
  const [view, setView] = useState<ViewMode>("list")
  const [statsOpen, setStatsOpen] = useState(false)

  const cur = settings.currency
  const folderMap = useMemo(() => new Map(folders.map((f) => [f.id, f])), [folders])

  const stats = useMemo(() => collectionStats(entries, cur), [entries, cur])

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase()
    let list = entries.filter((e) => {
      if (folderFilter !== "all" && e.folderId !== (folderFilter === "none" ? null : folderFilter))
        return false
      if (!term) return true
      const f = e.folderId ? folderMap.get(e.folderId) : null
      const hay = [
        e.card.name,
        e.card.printedName,
        e.card.setName,
        e.card.colors.join(""),
        f?.name,
        e.position,
      ]
        .join(" ")
        .toLowerCase()
      return hay.includes(term)
    })
    list = [...list].sort((a, b) => {
      if (sort === "name") return (a.card.name || "").localeCompare(b.card.name || "")
      if (sort === "value") return entryValue(b, cur) - entryValue(a, cur)
      return b.addedAt - a.addedAt
    })
    return list
  }, [entries, q, folderFilter, folderMap, sort, cur])

  return (
    <div className="relative mx-auto w-full max-w-3xl px-4 pb-28 pt-4 lg:max-w-7xl lg:px-8">
      {/* User-chosen backdrop for the whole vault view */}
      <div
        className={`pointer-events-none fixed inset-0 -z-10 ${backgroundClass(settings.collectionBackground)}`}
        style={backgroundStyle(settings.collectionBackground, ACCENTS[settings.accent].swatch)}
        aria-hidden="true"
      />
      {/* Large, obvious statistics preview */}
      <button
        onClick={() => setStatsOpen(true)}
        aria-label={`${t("statistics")}: ${money(stats.current, cur)}`}
        className="group relative mb-4 min-h-40 w-full overflow-hidden rounded-3xl border border-border bg-card/95 p-5 text-left shadow-sm transition-transform active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end gap-1 px-5 opacity-20" aria-hidden>
          {[26, 42, 34, 58, 48, 74, 64, 92, 80, 100].map((height, index) => (
            <span key={index} className="flex-1 rounded-t-md bg-primary" style={{ height: `${height}px` }} />
          ))}
        </div>
        <div className="relative flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="min-w-0">
              <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground"><TrendingUp className="size-4 text-primary" /> {t("statistics")}</div>
              <div className="font-mono text-3xl font-bold leading-tight">{money(stats.current, cur)}</div>
              <div className="mt-1 text-sm text-muted-foreground">{stats.copies} {t("cards")} · {t("current")}</div>
            </div>
          </div>
          <span className="grid size-10 shrink-0 place-items-center rounded-full bg-background/80 text-foreground shadow-sm ring-1 ring-border transition-transform group-hover:translate-x-1" aria-hidden><ChevronRight className="size-5" /></span>
        </div>
        <div className="relative mt-5 flex items-center justify-between text-xs">
          <span className="rounded-full bg-background/80 px-3 py-1.5 font-semibold backdrop-blur">Apri report completo</span>
          <span className="rounded-xl border border-border/70 bg-background/65 px-2.5 py-1.5 text-right">
            <span className="block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{t("win")}</span>
            <span className="font-mono text-lg font-bold leading-tight" style={{ color: stats.winPct == null ? undefined : stats.winPct >= 0 ? "oklch(0.72 0.17 150)" : "oklch(0.68 0.2 20)" }}>{signedPct(stats.winPct)}</span>
          </span>
        </div>
      </button>

      {/* Search */}
      <div className="mb-3 flex items-center gap-2 rounded-2xl border border-border bg-card px-3.5 py-3">
        <Search className="size-5 shrink-0 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t("searchPlaceholder")}
          className="w-full bg-transparent py-1 text-base outline-none placeholder:text-muted-foreground"
        />
        <button
          onClick={() => void refreshPrices()}
          disabled={syncing || entries.length === 0}
          className="grid size-11 shrink-0 place-items-center rounded-full text-muted-foreground disabled:opacity-40"
          aria-label={t("refreshPrices")}
        >
          <RefreshCw className={`size-5 ${syncing ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Folder filter + sort */}
      <div className="no-scrollbar mb-4 flex items-center gap-2 overflow-x-auto pb-1">
        <Chip active={folderFilter === "all"} onClick={() => setFolderFilter("all")}>
          {t("allFolders")}
        </Chip>
        {folders.map((f) => (
          <Chip key={f.id} active={folderFilter === f.id} onClick={() => setFolderFilter(f.id)} color={f.color}>
            {f.name}
          </Chip>
        ))}
        <Chip active={folderFilter === "none"} onClick={() => setFolderFilter("none")}>
          {t("noFolder")}
        </Chip>
      </div>

      <div className="mb-3 flex items-center gap-2 text-xs">
        <span className="text-muted-foreground">{t("sortBy")}:</span>
        {(["recent", "name", "value"] as Sort[]).map((s) => (
          <button
            key={s}
            onClick={() => setSort(s)}
            className={`rounded-full px-2.5 py-1 font-medium ${
              sort === s ? "bg-foreground text-background" : "text-muted-foreground"
            }`}
          >
            {t(s === "recent" ? "sortRecent" : s === "name" ? "sortName" : "sortValue")}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1 rounded-full border border-border p-0.5">
          <button
            onClick={() => setView("list")}
            className={`grid size-9 place-items-center rounded-full ${
              view === "list" ? "bg-foreground text-background" : "text-muted-foreground"
            }`}
            aria-label="list view"
            aria-pressed={view === "list"}
          >
            <List className="size-4" />
          </button>
          <button
            onClick={() => setView("grid")}
            className={`grid size-9 place-items-center rounded-full ${
              view === "grid" ? "bg-foreground text-background" : "text-muted-foreground"
            }`}
            aria-label="grid view"
            aria-pressed={view === "grid"}
          >
            <LayoutGrid className="size-4" />
          </button>
        </div>
      </div>

      {/* List */}
      {entries.length === 0 ? (
        <Empty title={t("emptyVault")} sub={t("emptyVaultSub")} />
      ) : filtered.length === 0 ? (
        <Empty title={t("noResults")} />
      ) : view === "grid" ? (
        <div className={`grid ${gridColsClass(settings.density)}`}>
          {filtered.map((e) => (
            <CardTile
              key={e.id}
              entry={e}
              folder={e.folderId ? folderMap.get(e.folderId) : undefined}
              currency={cur}
              onClick={() => onOpen(e)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col gap-2 lg:grid lg:grid-cols-2 xl:grid-cols-3">
          {filtered.map((e) => (
            <CardRow
              key={e.id}
              entry={e}
              folder={e.folderId ? folderMap.get(e.folderId) : undefined}
              currency={cur}
              onClick={() => onOpen(e)}
            />
          ))}
        </div>
      )}

      {statsOpen && <StatsView onClose={() => setStatsOpen(false)} />}
    </div>
  )
}

function Chip({
  children,
  active,
  onClick,
  color,
}: {
  children: React.ReactNode
  active: boolean
  onClick: () => void
  color?: string
}) {
  return (
    <button
      onClick={onClick}
      className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
        active ? "border-foreground bg-foreground text-background" : "border-border bg-card text-foreground"
      }`}
    >
      {color && <span className="size-2.5 rounded-full" style={{ backgroundColor: color }} />}
      {children}
    </button>
  )
}

function Empty({ title, sub }: { title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border py-16 text-center">
      <Layers className="size-8 text-muted-foreground" />
      <div className="font-semibold">{title}</div>
      {sub && <div className="max-w-xs text-sm text-muted-foreground text-pretty">{sub}</div>}
    </div>
  )
}
