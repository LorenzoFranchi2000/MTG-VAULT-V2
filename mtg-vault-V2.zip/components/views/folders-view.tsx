"use client"

import { useMemo, useState } from "react"
import { FolderOpen, Pencil, Plus, Trash2 } from "lucide-react"
import type { Folder } from "@/lib/types"
import { FOLDER_COLORS, useCollection } from "@/lib/collection-context"
import { money } from "@/lib/format"
import { entryValue } from "@/lib/prices"
import {
  DEFAULT_BACKGROUND,
  DEFAULT_FOLDER_ICON,
  backgroundClass,
  backgroundStyle,
  folderIcon,
  withAlpha,
  type BackgroundKey,
  type FolderIconKey,
} from "@/lib/folder-style"
import { Modal } from "@/components/ui/modal"
import { ColorPicker } from "@/components/color-picker"
import { BackgroundPicker, IconPicker } from "@/components/folder-style-picker"
import { FolderPreview } from "@/components/folder-preview"
import { useToast } from "@/components/ui/toast"

export function FoldersView({ onOpenFolder }: { onOpenFolder: (f: Folder) => void }) {
  const { folders, entries, settings, t, addFolder, updateFolder, removeFolder } = useCollection()
  const toast = useToast()
  const [editing, setEditing] = useState<Folder | "new" | null>(null)
  const [name, setName] = useState("")
  const [color, setColor] = useState(FOLDER_COLORS[0])
  const [backgroundColor, setBackgroundColor] = useState(FOLDER_COLORS[1])
  const [icon, setIcon] = useState<FolderIconKey>(DEFAULT_FOLDER_ICON)
  const [background, setBackground] = useState<BackgroundKey>(DEFAULT_BACKGROUND)

  const cur = settings.currency

  const perFolder = useMemo(() => {
    const map = new Map<string, { count: number; value: number }>()
    for (const e of entries) {
      if (!e.folderId) continue
      const cur0 = map.get(e.folderId) ?? { count: 0, value: 0 }
      cur0.count += e.quantity
      cur0.value += entryValue(e, cur)
      map.set(e.folderId, cur0)
    }
    return map
  }, [entries, cur])

  const openNew = () => {
    setEditing("new")
    setName("")
    const nextColor = FOLDER_COLORS[Math.floor(Math.random() * FOLDER_COLORS.length)]
    setColor(nextColor)
    setBackgroundColor(FOLDER_COLORS[1])
    setIcon(DEFAULT_FOLDER_ICON)
    setBackground(DEFAULT_BACKGROUND)
  }
  const openEdit = (f: Folder) => {
    setEditing(f)
    setName(f.name)
    setColor(f.iconColor ?? f.color)
    setBackgroundColor(f.backgroundColor ?? f.color)
    setIcon(f.icon ?? DEFAULT_FOLDER_ICON)
    setBackground(f.background ?? DEFAULT_BACKGROUND)
  }
  const save = async () => {
    const trimmed = name.trim()
    if (!trimmed) return
    if (editing === "new") {
      await addFolder(trimmed, color, { icon, background, iconColor: color, backgroundColor })
    } else if (editing) {
      await updateFolder(editing.id, { name: trimmed, color, icon, background, iconColor: color, backgroundColor })
    }
    setEditing(null)
    toast(t("saved"))
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-4 lg:max-w-6xl lg:px-8">
      <button
        onClick={openNew}
        className="mb-4 flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-base font-semibold text-primary-foreground"
      >
        <Plus className="size-5" />
        {t("newFolder")}
      </button>

      {folders.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border py-16 text-center">
          <FolderOpen className="size-8 text-muted-foreground" />
          <div className="font-semibold">{t("noFolders")}</div>
          <div className="max-w-xs text-sm text-muted-foreground text-pretty">{t("noFoldersSub")}</div>
        </div>
      ) : (
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {folders.map((f) => {
            const s = perFolder.get(f.id) ?? { count: 0, value: 0 }
            const Icon = folderIcon(f.icon)
            return (
              <div
                key={f.id}
                className={`relative overflow-hidden rounded-2xl border border-border bg-card p-4 ${backgroundClass(
                  f.background,
                )}`}
              >
                <span
                  className="pointer-events-none absolute inset-0"
                  style={backgroundStyle(f.background, f.backgroundColor ?? f.color)}
                  aria-hidden="true"
                />
                <span
                  className="absolute inset-y-0 left-0 w-1.5"
                  style={{ backgroundColor: f.color }}
                  aria-hidden="true"
                />
                <div className="relative flex items-start justify-between gap-2 pl-2">
                  <button onClick={() => onOpenFolder(f)} className="flex min-h-12 min-w-0 flex-1 items-center gap-3 text-left">
                    <span
                      className="grid size-11 shrink-0 place-items-center rounded-xl"
                      style={{ backgroundColor: withAlpha(f.color, 0.22), color: f.color }}
                    >
                      <Icon className="size-5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate font-semibold">{f.name}</span>
                      <span className="mt-1 block font-mono text-xs text-muted-foreground">
                        {s.count} {t("cards")} · {money(s.value, cur)}
                      </span>
                    </span>
                  </button>
                  <div className="flex shrink-0 gap-1">
                    <button
                      onClick={() => openEdit(f)}
                      className="grid size-11 place-items-center rounded-full text-muted-foreground hover:bg-muted"
                      aria-label={t("edit")}
                    >
                      <Pencil className="size-5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(t("confirmDeleteFolder"))) {
                          void removeFolder(f.id)
                          toast(t("delete"))
                        }
                      }}
                      className="grid size-11 place-items-center rounded-full text-destructive hover:bg-destructive/10"
                      aria-label={t("delete")}
                    >
                      <Trash2 className="size-5" />
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Modal
        open={editing != null}
        onClose={() => setEditing(null)}
        title={editing === "new" ? t("newFolder") : t("edit")}
      >
        <div className="space-y-5 p-5">
          <div>
            <label className="mb-1.5 block text-sm font-medium">{t("folderName")}</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t("folderName")}
              autoFocus
              className="w-full rounded-xl border border-border bg-background px-3.5 py-3.5 text-base outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">{t("color")}</label>
            <ColorPicker value={color} onChange={setColor} />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">{t("folderIcon")}</label>
            <IconPicker value={icon} color={color} onChange={setIcon} t={t} />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Colore sfondo</label>
            <ColorPicker value={backgroundColor} onChange={setBackgroundColor} />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">{t("folderBackground")}</label>
            <BackgroundPicker value={background} color={color} onChange={setBackground} t={t} />
          </div>
          <div>
            <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {t("livePreview")}
            </div>
            <FolderPreview
              folder={{ name: name || t("folderName"), color, iconColor: color, backgroundColor, icon, background }}
              subtitle={`0 ${t("cards")} · ${money(0, cur)}`}
            />
          </div>
          <button
            onClick={save}
            disabled={!name.trim()}
            className="w-full rounded-full bg-primary py-4 text-base font-semibold text-primary-foreground disabled:opacity-40"
          >
            {editing === "new" ? t("createFolder") : t("edit")}
          </button>
        </div>
      </Modal>
    </div>
  )
}
