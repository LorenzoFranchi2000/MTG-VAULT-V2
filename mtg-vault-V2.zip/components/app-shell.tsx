"use client"

import { useState } from "react"
import { FolderOpen, Layers, Plus, ScanLine, Settings } from "lucide-react"
import type { Entry, Folder } from "@/lib/types"
import { CollectionProvider, useCollection } from "@/lib/collection-context"
import { ToastProvider } from "@/components/ui/toast"
import { CollectionView } from "@/components/views/collection-view"
import { FoldersView } from "@/components/views/folders-view"
import { FolderDetailView } from "@/components/views/folder-detail-view"
import { AddView } from "@/components/views/add-view"
import { ScanTab } from "@/components/views/scan-tab"
import { SettingsView } from "@/components/views/settings-view"
import { CardDetailSheet } from "@/components/card-detail-sheet"
import { BetaBadge } from "@/components/beta-badge"
import { backgroundStyle } from "@/lib/folder-style"
import { ACCENTS } from "@/lib/appearance"

type Tab = "vault" | "folders" | "add" | "scan" | "settings"

function Shell() {
  const { t, ready, entries, folders, settings } = useCollection()
  const [tab, setTab] = useState<Tab>("vault")
  const [detail, setDetail] = useState<Entry | null>(null)
  const [openFolderId, setOpenFolderId] = useState<string | null>(null)

  // Keep the detail entry in sync with store updates.
  const liveDetail = detail ? entries.find((e) => e.id === detail.id) ?? null : null
  // Keep the open folder in sync; auto-close if it was deleted.
  const openFolder: Folder | null = openFolderId
    ? folders.find((f) => f.id === openFolderId) ?? null
    : null

  const nav: { id: Tab; label: string; icon: typeof Layers }[] = [
    { id: "vault", label: t("vault"), icon: Layers },
    { id: "folders", label: t("folders"), icon: FolderOpen },
    { id: "add", label: t("add"), icon: Plus },
    { id: "scan", label: t("scan"), icon: ScanLine },
    { id: "settings", label: t("settings"), icon: Settings },
  ]

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center text-sm text-muted-foreground">
        {t("loading")}
      </div>
    )
  }

  return (
    <div className={tab === "scan" ? "h-dvh overflow-hidden" : "min-h-dvh"} style={tab === "vault" || tab === "folders" ? backgroundStyle(settings.collectionBackground, ACCENTS[settings.accent].swatch) : undefined}>
      {tab !== "scan" && (
      <header className="safe-top sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-2 px-4 py-3 lg:max-w-6xl lg:px-8">
          <div className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground" style={{ background: "var(--accent-gradient)" }}>
            <Layers className="size-4.5" />
          </div>
          <span className="text-base font-bold tracking-tight">MTG Vault</span>
          <span className="ml-auto text-xs font-medium capitalize text-muted-foreground">
            {t(tab)}
          </span>
        </div>
      </header>
      )}

      <main className={tab === "scan" ? "h-dvh overflow-hidden" : "pb-[calc(5.5rem+env(safe-area-inset-bottom))]"}>
        {tab === "vault" && <CollectionView onOpen={setDetail} />}
        {tab === "folders" &&
          (openFolder ? (
            <FolderDetailView
              folder={openFolder}
              onBack={() => setOpenFolderId(null)}
              onOpen={setDetail}
            />
          ) : (
            <FoldersView onOpenFolder={(f) => setOpenFolderId(f.id)} />
          ))}
        {tab === "add" && <AddView onDone={() => setTab("vault")} />}
        {tab === "scan" && <ScanTab onDone={() => setTab("vault")} />}
        {tab === "settings" && <SettingsView />}
      </main>

      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl items-stretch justify-around px-2 lg:max-w-4xl">
          {nav.map(({ id, label, icon: Icon }) => {
            const active = tab === id
            const isAdd = id === "add"
            return (
              <button
                key={id}
                onClick={() => {
                  if (id !== "folders") setOpenFolderId(null)
                  setTab(id)
                }}
                className="flex min-h-[3.75rem] flex-1 flex-col items-center justify-center gap-1 py-2.5"
                aria-current={active ? "page" : undefined}
              >
                <span
                  className={`relative grid place-items-center rounded-full transition-colors ${
                    isAdd
                      ? "size-12 bg-primary text-primary-foreground"
                      : active
                        ? "size-10 bg-accent text-foreground"
                        : "size-10 text-muted-foreground"
                  }`}
                >
                  <Icon className={isAdd ? "size-6" : "size-5"} />
                </span>
                <span
                  className={`flex items-center gap-1 text-[11px] font-medium ${
                    active ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {label}
                  {id === "scan" && <BetaBadge />}
                </span>
              </button>
            )
          })}
        </div>
      </nav>

      <CardDetailSheet entry={liveDetail} onClose={() => setDetail(null)} />
    </div>
  )
}

export function AppShell() {
  return (
    <CollectionProvider>
      <ToastProvider>
        <Shell />
      </ToastProvider>
    </CollectionProvider>
  )
}
