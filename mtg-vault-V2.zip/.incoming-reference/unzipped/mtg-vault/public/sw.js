// Minimal service worker: makes the installed PWA load instantly and keeps
// working offline for anything already visited. Deliberately does NOT touch
// /api/* — /api/store must always hit the network live (it's mutable state,
// see app/api/store/route.ts), and /api/scan/image is a lightweight proxy
// that's fine being re-fetched every time rather than cached.

const CACHE_NAME = "mtg-vault-v1"

self.addEventListener("install", () => {
  self.skipWaiting()
})

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener("fetch", (event) => {
  const { request } = event
  if (request.method !== "GET") return
  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return
  if (url.pathname.startsWith("/api/")) return // never cache live/dynamic endpoints

  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      const cached = await cache.match(request)
      const network = fetch(request)
        .then((res) => {
          if (res.ok) cache.put(request, res.clone())
          return res
        })
        .catch(() => cached)
      // Stale-while-revalidate: instant from cache if we have it, refresh in
      // the background; network-only on a cold cache miss.
      return cached || network
    }),
  )
})
