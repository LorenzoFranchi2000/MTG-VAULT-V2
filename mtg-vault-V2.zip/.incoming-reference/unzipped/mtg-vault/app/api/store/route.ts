// Self-hosted collection storage.
//
// The whole collection (entries + folders) lives in a single JSON file on the
// host machine. Every device on the LAN that opens the app reads and writes the
// same file, so adds/edits made on one device show up on the others. No cloud,
// no database server, works fully offline on the local network.
//
// Concurrency model: last-write-wins on the whole document, with an `updatedAt`
// stamp so clients can tell when the server copy is newer than what they hold.
//
// SAFETY: this endpoint has no auth and no per-user separation — it's designed
// for one person's own devices on their own LAN (via `pnpm run lan`), not for
// multiple people sharing one deployment. If this app is deployed somewhere
// friends install it from, every install would otherwise read and overwrite
// the exact same file — everyone's cards merged into one shared, corruptible
// collection. So this route (and the client calls in lib/sync.ts) only run
// when NEXT_PUBLIC_LAN_SYNC=1 is set, which is intended for your own
// self-hosted instance only, never for a public/shared deployment.

import { NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"

// Never cache — this is live, mutable state.
export const dynamic = "force-dynamic"
export const revalidate = 0

const DATA_DIR = path.join(process.cwd(), "data")
const FILE = path.join(DATA_DIR, "collection.json")
const SYNC_ENABLED = process.env.NEXT_PUBLIC_LAN_SYNC === "1"

interface StoreDoc {
  entries: unknown[]
  folders: unknown[]
  updatedAt: number
}

const EMPTY: StoreDoc = { entries: [], folders: [], updatedAt: 0 }

async function readStore(): Promise<StoreDoc> {
  try {
    const raw = await fs.readFile(FILE, "utf8")
    const parsed = JSON.parse(raw)
    return {
      entries: Array.isArray(parsed.entries) ? parsed.entries : [],
      folders: Array.isArray(parsed.folders) ? parsed.folders : [],
      updatedAt: typeof parsed.updatedAt === "number" ? parsed.updatedAt : 0,
    }
  } catch {
    return EMPTY
  }
}

// Serialize writes within this server process so two quick saves can't interleave
// and corrupt the file.
let writeChain: Promise<unknown> = Promise.resolve()
function queueWrite<T>(fn: () => Promise<T>): Promise<T> {
  const run = writeChain.then(fn, fn)
  writeChain = run.catch(() => {})
  return run
}

export async function GET() {
  if (!SYNC_ENABLED) return NextResponse.json({ error: "lan-sync-disabled" }, { status: 404 })
  const data = await readStore()
  return NextResponse.json(data, {
    headers: { "Cache-Control": "no-store" },
  })
}

export async function PUT(req: Request) {
  if (!SYNC_ENABLED) return NextResponse.json({ error: "lan-sync-disabled" }, { status: 404 })
  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "invalid-json" }, { status: 400 })
  }

  const doc: StoreDoc = {
    entries: Array.isArray(body?.entries) ? body.entries : [],
    folders: Array.isArray(body?.folders) ? body.folders : [],
    updatedAt: Date.now(),
  }

  try {
    await queueWrite(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true })
      // Atomic write: write to a temp file then rename, so a crash mid-write
      // never leaves a truncated collection.json.
      const tmp = FILE + ".tmp"
      await fs.writeFile(tmp, JSON.stringify(doc), "utf8")
      await fs.rename(tmp, FILE)
    })
  } catch (err) {
    return NextResponse.json({ error: "write-failed" }, { status: 500 })
  }

  return NextResponse.json({ ok: true, updatedAt: doc.updatedAt })
}
