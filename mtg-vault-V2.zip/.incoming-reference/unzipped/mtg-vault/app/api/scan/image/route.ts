import { NextResponse } from "next/server"

export const dynamic = "force-dynamic"

const ALLOW = ["https://cards.scryfall.io/", "https://c1.scryfall.com/", "https://api.scryfall.com/"]

export async function GET(req: Request) {
  const url = new URL(req.url).searchParams.get("url") || ""
  if (!ALLOW.some((p) => url.startsWith(p))) {
    return NextResponse.json({ error: "bad-url" }, { status: 400 })
  }
  const res = await fetch(url)
  if (!res.ok || !res.body) {
    return NextResponse.json({ error: "fetch-failed" }, { status: 502 })
  }
  return new NextResponse(res.body, {
    headers: {
      "Content-Type": res.headers.get("content-type") || "image/jpeg",
      "Cache-Control": "public, max-age=86400",
    },
  })
}
