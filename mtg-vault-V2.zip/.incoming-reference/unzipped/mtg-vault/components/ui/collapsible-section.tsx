"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

// Lightweight disclosure ("più info") with a chevron and smooth open state.
export function CollapsibleSection({
  title,
  icon,
  defaultOpen = false,
  onOpenChange,
  children,
}: {
  title: React.ReactNode
  icon?: React.ReactNode
  defaultOpen?: boolean
  onOpenChange?: (open: boolean) => void
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)

  const toggle = () => {
    const next = !open
    setOpen(next)
    onOpenChange?.(next)
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <button
        onClick={toggle}
        className="flex w-full items-center gap-2 px-4 py-3.5 text-left"
        aria-expanded={open}
      >
        {icon}
        <span className="flex-1 text-sm font-semibold">{title}</span>
        <ChevronDown
          className={`size-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && <div className="border-t border-border px-4 py-3.5">{children}</div>}
    </div>
  )
}
