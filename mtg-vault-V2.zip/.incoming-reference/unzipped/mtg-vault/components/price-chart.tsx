"use client"

import { useMemo, useState } from "react"
import type { PricePoint } from "@/lib/types"
import { money } from "@/lib/format"

interface Props {
  history: PricePoint[]
  currency: "eur" | "usd"
}

const W = 320
const H = 120
const PAD = 8

export function PriceChart({ history, currency }: Props) {
  const [hover, setHover] = useState<number | null>(null)

  const data = useMemo(() => {
    return history
      .map((p) => ({ date: p.date, v: currency === "eur" ? p.eur : p.usd, estimated: p.estimated }))
      .filter((p): p is { date: string; v: number; estimated: boolean } => p.v != null)
  }, [history, currency])

  const geom = useMemo(() => {
    if (data.length < 2) return null
    const values = data.map((d) => d.v)
    const min = Math.min(...values)
    const max = Math.max(...values)
    const range = max - min || 1
    const stepX = (W - PAD * 2) / (data.length - 1)
    const pts = data.map((d, i) => {
      const x = PAD + i * stepX
      const y = PAD + (H - PAD * 2) * (1 - (d.v - min) / range)
      return { x, y, ...d }
    })
    const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ")
    const area = `${line} L${pts[pts.length - 1].x.toFixed(1)},${H - PAD} L${pts[0].x.toFixed(1)},${H - PAD} Z`
    // Split into estimated (dashed) vs real (solid) by finding first real index.
    const firstReal = data.findIndex((d) => !d.estimated)
    return { pts, line, area, min, max, firstReal: firstReal < 0 ? data.length : firstReal }
  }, [data])

  if (!geom) {
    return (
      <div className="grid h-[120px] place-items-center rounded-xl bg-muted/50 text-xs text-muted-foreground">
        —
      </div>
    )
  }

  const up = data[data.length - 1].v >= data[0].v
  const stroke = up ? "oklch(0.62 0.15 150)" : "oklch(0.6 0.2 20)"
  const active = hover != null ? geom.pts[hover] : geom.pts[geom.pts.length - 1]

  return (
    <div className="select-none">
      <div className="mb-1 flex items-baseline justify-between">
        <span className="font-mono text-lg font-semibold" style={{ color: stroke }}>
          {money(active.v, currency)}
        </span>
        <span className="text-xs text-muted-foreground">{active.date}</span>
      </div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-[120px] w-full touch-none"
        preserveAspectRatio="none"
        onPointerMove={(e) => {
          const rect = (e.currentTarget as SVGSVGElement).getBoundingClientRect()
          const x = ((e.clientX - rect.left) / rect.width) * W
          const idx = Math.round(((x - PAD) / (W - PAD * 2)) * (geom.pts.length - 1))
          setHover(Math.max(0, Math.min(geom.pts.length - 1, idx)))
        }}
        onPointerLeave={() => setHover(null)}
      >
        <defs>
          <linearGradient id="pcArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={stroke} stopOpacity="0.22" />
            <stop offset="100%" stopColor={stroke} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={geom.area} fill="url(#pcArea)" />
        <path d={geom.line} fill="none" stroke={stroke} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
        <line
          x1={active.x}
          y1={PAD}
          x2={active.x}
          y2={H - PAD}
          stroke="currentColor"
          strokeOpacity={0.25}
          strokeWidth={1}
        />
        <circle cx={active.x} cy={active.y} r={4} fill={stroke} stroke="var(--card)" strokeWidth={2} />
      </svg>
    </div>
  )
}
