"use client"

import type { Entry, Folder } from "@/lib/types"
import { money } from "@/lib/format"
import { entryUnitPrice } from "@/lib/prices"
import { conditionMeta, safeCondition } from "@/lib/condition"

interface Props {
  entry: Entry
  folder?: Folder
  currency: "eur" | "usd"
  onClick: () => void
}

export function CardRow({ entry, folder, currency, onClick }: Props) {
  const card = entry.card
  const unit = entryUnitPrice(entry, currency)
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-2.5 text-left transition-colors active:bg-accent"
    >
      <div className="relative size-14 shrink-0 overflow-hidden rounded-lg bg-muted">
        {card.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={card.image || "/placeholder.svg"}
            alt=""
            loading="lazy"
            className="h-full w-full scale-[1.35] object-cover object-top"
          />
        ) : null}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-sm font-semibold">{card.printedName || card.name}</span>
          {entry.foil && (
            <span className="shrink-0 rounded bg-primary/20 px-1 text-[10px] font-bold text-primary-foreground">
              F
            </span>
          )}
        </div>
        <div className="mt-0.5 truncate text-xs text-muted-foreground">
          {card.setName} · #{card.collectorNumber}
        </div>
        {folder && (
          <div className="mt-1 flex items-center gap-1.5">
            <span className="size-2.5 rounded-full" style={{ backgroundColor: folder.color }} />
            <span className="truncate text-[11px] text-muted-foreground">
              {folder.name}
              {entry.position ? ` · ${entry.position}` : ""}
            </span>
          </div>
        )}
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <div className="font-mono text-sm font-bold">{money(unit, currency)}</div>
        <div className="flex items-center gap-1.5">
          <span
            className="rounded px-1 py-0.5 text-[9px] font-bold text-white"
            style={{ backgroundColor: conditionMeta(entry.condition).color }}
          >
            {safeCondition(entry.condition)}
          </span>
          <span className="text-xs text-muted-foreground">×{entry.quantity}</span>
        </div>
      </div>
    </button>
  )
}
