"use client"

import { useState } from "react"
import { ChevronDown, SlidersHorizontal, X } from "lucide-react"
import type { ColorFilter, FilterState, SortKey } from "@/lib/card-filter"
import { EMPTY_FILTER, isFilterActive } from "@/lib/card-filter"
import type { TFunc } from "@/lib/i18n"

// Swatch metadata for the color toggles (kept local to the control).
const COLORS: { key: ColorFilter; hex: string; text: string }[] = [
  { key: "W", hex: "#f5e7c0", text: "#3a3320" },
  { key: "U", hex: "#2f7fd6", text: "#ffffff" },
  { key: "B", hex: "#3f3a45", text: "#ffffff" },
  { key: "R", hex: "#d6452c", text: "#ffffff" },
  { key: "G", hex: "#2f9e5a", text: "#ffffff" },
  { key: "C", hex: "#a7adb5", text: "#26282c" },
]

// CMC quick-picks. `7` means "7 or more" (upper bound left open).
const CMC_OPTIONS = [0, 1, 2, 3, 4, 5, 6, 7]

const SORTS: SortKey[] = ["name", "nameDesc", "priceAsc", "priceDesc"]

export function CardFilterBar({
  filter,
  sort,
  onFilter,
  onSort,
  resultCount,
  t,
}: {
  filter: FilterState
  sort: SortKey
  onFilter: (f: FilterState) => void
  onSort: (s: SortKey) => void
  resultCount: number
  t: TFunc
}) {
  const [open, setOpen] = useState(false)
  const active = isFilterActive(filter)
  const activeCount = filter.colors.length + (filter.cmcMin != null || filter.cmcMax != null ? 1 : 0)

  const toggleColor = (c: ColorFilter) => {
    const has = filter.colors.includes(c)
    onFilter({ ...filter, colors: has ? filter.colors.filter((x) => x !== c) : [...filter.colors, c] })
  }

  // CMC selection: a single quick-pick maps to a min/max pair (7 = 7+).
  const selectedCmc = (() => {
    if (filter.cmcMin == null && filter.cmcMax == null) return null
    if (filter.cmcMin === 7 && filter.cmcMax == null) return 7
    if (filter.cmcMin === filter.cmcMax) return filter.cmcMin
    return null
  })()

  const setCmc = (v: number | null) => {
    if (v == null) onFilter({ ...filter, cmcMin: null, cmcMax: null })
    else if (v === 7) onFilter({ ...filter, cmcMin: 7, cmcMax: null })
    else onFilter({ ...filter, cmcMin: v, cmcMax: v })
  }

  const sortLabel = (s: SortKey) =>
    s === "name"
      ? t("sortNameAsc")
      : s === "nameDesc"
        ? t("sortNameDesc")
        : s === "priceAsc"
          ? t("sortPriceAsc")
          : t("sortPriceDesc")

  return (
    <div className="mb-4">
      {/* Sort chips (always visible) + filter toggle */}
      <div className="flex items-center gap-2">
        <div className="no-scrollbar flex flex-1 items-center gap-2 overflow-x-auto">
          <span className="shrink-0 text-xs text-muted-foreground">{t("sortBy")}:</span>
          {SORTS.map((s) => (
            <button
              key={s}
              onClick={() => onSort(s)}
              className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-medium transition-colors ${
                sort === s ? "bg-foreground text-background" : "border border-border text-muted-foreground"
              }`}
            >
              {sortLabel(s)}
            </button>
          ))}
        </div>
        <button
          onClick={() => setOpen((o) => !o)}
          className={`relative flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
            active ? "border-primary bg-primary/10 text-primary-foreground" : "border-border"
          }`}
          aria-expanded={open}
        >
          <SlidersHorizontal className="size-3.5" />
          {t("filters")}
          {activeCount > 0 && (
            <span className="grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
              {activeCount}
            </span>
          )}
          <ChevronDown className={`size-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
      </div>

      {/* Expandable filter panel */}
      {open && (
        <div className="mt-2 rounded-2xl border border-border bg-card p-3.5">
          {/* Color identity */}
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-xs font-semibold">{t("colorIdentity")}</span>
            {active && (
              <button
                onClick={() => onFilter(EMPTY_FILTER)}
                className="flex items-center gap-1 text-[11px] font-medium text-muted-foreground"
              >
                <X className="size-3" />
                {t("clear")}
              </button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => {
              const on = filter.colors.includes(c.key)
              return (
                <button
                  key={c.key}
                  onClick={() => toggleColor(c.key)}
                  aria-pressed={on}
                  className={`grid size-9 place-items-center rounded-full font-mono text-sm font-bold transition-all ${
                    on ? "ring-2 ring-primary ring-offset-2 ring-offset-card" : "opacity-70"
                  }`}
                  style={{ backgroundColor: c.hex, color: c.text }}
                >
                  {c.key}
                </button>
              )
            })}
          </div>

          {/* Mana value */}
          <div className="mb-1.5 mt-4 text-xs font-semibold">{t("manaValue")}</div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setCmc(null)}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors ${
                selectedCmc == null ? "bg-foreground text-background" : "border border-border text-muted-foreground"
              }`}
            >
              {t("cmcAny")}
            </button>
            {CMC_OPTIONS.map((v) => (
              <button
                key={v}
                onClick={() => setCmc(v)}
                className={`min-w-9 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  selectedCmc === v ? "bg-foreground text-background" : "border border-border text-muted-foreground"
                }`}
              >
                {v === 7 ? "7+" : v}
              </button>
            ))}
          </div>
        </div>
      )}

      {active && (
        <div className="mt-2 text-[11px] text-muted-foreground">
          {resultCount} {t("showingResults")} · {activeCount} {t("activeFilters")}
        </div>
      )}
    </div>
  )
}
