"use client"

import type { TFunc } from "@/lib/i18n"
import {
  BACKGROUND_KEYS,
  FOLDER_ICON_KEYS,
  FOLDER_ICONS,
  backgroundLabelKey,
  backgroundStyle,
  type BackgroundKey,
  type FolderIconKey,
} from "@/lib/folder-style"

/** Icon pack selector: 40 built-in glyphs (mana, shapes, rarity, objects). */
export function IconPicker({
  value,
  color,
  onChange,
  t,
}: {
  value: FolderIconKey
  color: string
  onChange: (k: FolderIconKey) => void
  t: TFunc
}) {
  return (
    <div
      className="grid max-h-56 grid-cols-6 gap-1.5 overflow-y-auto rounded-xl border border-border bg-background p-2 sm:grid-cols-8 lg:grid-cols-10"
      role="radiogroup"
      aria-label={t("folderIcon")}
    >
      {FOLDER_ICON_KEYS.map((k) => {
        const Icon = FOLDER_ICONS[k].icon
        const on = value === k
        return (
          <button
            key={k}
            type="button"
            role="radio"
            aria-checked={on}
            aria-label={k}
            onClick={() => onChange(k)}
            className={`grid size-11 place-items-center rounded-xl border transition-colors ${
              on ? "border-foreground bg-accent" : "border-transparent hover:bg-muted"
            }`}
            style={on ? { color } : undefined}
          >
            <Icon className="size-5" />
          </button>
        )
      })}
    </div>
  )
}

/** Background pack selector, each swatch rendered with the real texture. */
export function BackgroundPicker({
  value,
  color,
  onChange,
  t,
}: {
  value: BackgroundKey
  color: string
  onChange: (k: BackgroundKey) => void
  t: TFunc
}) {
  return (
    <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6" role="radiogroup" aria-label={t("folderBackground")}>
      {BACKGROUND_KEYS.map((k) => {
        const on = value === k
        return (
          <button
            key={k}
            type="button"
            role="radio"
            aria-checked={on}
            onClick={() => onChange(k)}
            className={`relative h-16 overflow-hidden rounded-xl border bg-card text-[10px] font-medium ${
              on ? "border-foreground ring-2 ring-foreground" : "border-border"
            }`}
          >
            <span className="absolute inset-0" style={backgroundStyle(k, color)} aria-hidden="true" />
            <span className="absolute inset-x-0 bottom-0 bg-background/70 px-1 py-0.5 text-center leading-tight">
              {t(backgroundLabelKey(k))}
            </span>
          </button>
        )
      })}
    </div>
  )
}
