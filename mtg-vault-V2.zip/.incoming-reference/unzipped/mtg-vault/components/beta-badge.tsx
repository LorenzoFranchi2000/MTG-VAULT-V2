/** Small "BETA" pill used to flag the experimental scanner. */
export function BetaBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`rounded-full bg-amber-400/90 px-1.5 py-px text-[9px] font-bold uppercase leading-tight tracking-wide text-black ${className}`}
    >
      BETA
    </span>
  )
}
