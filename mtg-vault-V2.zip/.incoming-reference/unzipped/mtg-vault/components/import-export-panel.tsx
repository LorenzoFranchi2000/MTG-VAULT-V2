"use client"

import { useRef, useState } from "react"
import { Download, FileUp, Loader2 } from "lucide-react"
import { useCollection } from "@/lib/collection-context"
import {
  downloadFile,
  entriesToCsv,
  parseImport,
  resolveRows,
  type ImportRow,
  type ParseResult,
} from "@/lib/import-export"
import { Modal } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"

interface Report {
  imported: number
  total: number
  failed: ImportRow[]
}

const PREVIEW_ROWS = 12

/**
 * CSV/TXT collection import (Dragon Shield, Delver Lens, plain deck lists) with
 * a preview step and a final per-row report, plus CSV export.
 */
export function ImportExportPanel() {
  const { entries, folders, settings, t, addEntries } = useCollection()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)

  const [parsed, setParsed] = useState<ParseResult | null>(null)
  const [fileName, setFileName] = useState("")
  const [dest, setDest] = useState("")
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState(0)
  const [report, setReport] = useState<Report | null>(null)

  const onFile = async (file: File | undefined) => {
    if (!file) return
    try {
      const text = await file.text()
      const result = parseImport(text, file.name)
      setFileName(file.name)
      setDest("")
      if (result.rows.length === 0) {
        toast(t("importNoRows"))
        return
      }
      setParsed(result)
    } catch {
      toast(t("importFailed"))
    }
  }

  const runImport = async () => {
    if (!parsed) return
    setBusy(true)
    setProgress(0)
    try {
      const { resolved, failed } = await resolveRows(parsed.rows, settings.lang, (done, total) =>
        setProgress(total ? Math.round((done / total) * 100) : 100),
      )
      const imported = await addEntries(
        resolved.map(({ row, card }) => ({
          card,
          opts: {
            quantity: row.quantity,
            foil: row.foil,
            condition: row.condition ?? "NM",
            language: row.language,
            purchasePrice: row.purchasePrice,
            folderId: dest || null,
          },
        })),
      )
      setParsed(null)
      setReport({ imported, total: parsed.rows.length, failed })
    } catch {
      setParsed(null)
      toast(t("importFailed"))
    } finally {
      setBusy(false)
    }
  }

  const doExport = () => {
    if (entries.length === 0) {
      toast(t("exportEmpty"))
      return
    }
    const stamp = new Date().toISOString().slice(0, 10)
    downloadFile(entriesToCsv(entries, folders), `mtg-vault-${stamp}.csv`, "text/csv")
    toast(t("exportDone"))
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{t("importExportDesc")}</p>

      <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
        <button
          onClick={() => fileRef.current?.click()}
          className="flex min-h-14 items-center justify-center gap-2 rounded-full bg-primary px-4 text-base font-semibold text-primary-foreground"
        >
          <FileUp className="size-5" />
          {t("importCollection")}
        </button>
        <button
          onClick={doExport}
          className="flex min-h-14 items-center justify-center gap-2 rounded-full border border-border px-4 text-base font-semibold"
        >
          <Download className="size-5" />
          {t("exportCollection")}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept=".csv,.txt,text/csv,text/plain"
          className="hidden"
          onChange={(e) => {
            void onFile(e.target.files?.[0])
            e.target.value = ""
          }}
        />
      </div>

      {/* Preview before touching the collection */}
      <Modal
        open={parsed != null}
        onClose={() => !busy && setParsed(null)}
        title={t("importPreview")}
        className="sm:max-w-2xl"
      >
        {parsed && (
          <div className="space-y-4 p-5">
            <div className="text-sm text-muted-foreground">
              <span className="font-mono">{fileName}</span> · {t(`importFormat_${parsed.format}`)} ·{" "}
              {parsed.rows.length} {t("cards")}
              {parsed.skipped.length > 0 && ` · ${parsed.skipped.length} ${t("importSkippedLines")}`}
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium">{t("destinationFolder")}</label>
              <select
                value={dest}
                onChange={(e) => setDest(e.target.value)}
                className="min-h-12 w-full rounded-xl border border-border bg-background px-3 text-base outline-none"
              >
                <option value="">{t("noFolder")}</option>
                {folders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="overflow-hidden rounded-xl border border-border">
              <table className="w-full text-left text-sm">
                <thead className="bg-muted/60 text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2">{t("quantity")}</th>
                    <th className="px-3 py-2">{t("importColName")}</th>
                    <th className="px-3 py-2">{t("edition")}</th>
                    <th className="px-3 py-2">{t("foil")}</th>
                  </tr>
                </thead>
                <tbody>
                  {parsed.rows.slice(0, PREVIEW_ROWS).map((r, i) => (
                    <tr key={i} className="border-t border-border">
                      <td className="px-3 py-2 font-mono">{r.quantity}</td>
                      <td className="max-w-[14rem] truncate px-3 py-2">{r.name}</td>
                      <td className="px-3 py-2 font-mono uppercase">{r.setCode ?? "—"}</td>
                      <td className="px-3 py-2">{r.foil ? "★" : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {parsed.rows.length > PREVIEW_ROWS && (
                <div className="border-t border-border px-3 py-2 text-xs text-muted-foreground">
                  +{parsed.rows.length - PREVIEW_ROWS} …
                </div>
              )}
            </div>

            <button
              onClick={() => void runImport()}
              disabled={busy}
              className="flex min-h-14 w-full items-center justify-center gap-2 rounded-full bg-primary text-base font-semibold text-primary-foreground disabled:opacity-60"
            >
              {busy ? (
                <>
                  <Loader2 className="size-5 animate-spin" />
                  {progress}%
                </>
              ) : (
                t("importConfirm")
              )}
            </button>
          </div>
        )}
      </Modal>

      {/* Final report */}
      <Modal open={report != null} onClose={() => setReport(null)} title={t("importReport")} className="sm:max-w-lg">
        {report && (
          <div className="space-y-4 p-5">
            <p className="text-base font-semibold">
              {t("importReportLine")
                .replace("{imported}", String(report.imported))
                .replace("{total}", String(report.total))}
            </p>
            {report.failed.length > 0 && (
              <div>
                <div className="mb-2 text-sm text-muted-foreground">
                  {report.failed.length} {t("importNotFound")}
                </div>
                <ul className="max-h-56 space-y-1 overflow-y-auto rounded-xl border border-border p-3 text-sm">
                  {report.failed.map((r, i) => (
                    <li key={i} className="truncate font-mono text-xs text-muted-foreground">
                      {r.quantity}× {r.name}
                      {r.setCode ? ` [${r.setCode.toUpperCase()}]` : ""}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <button
              onClick={() => setReport(null)}
              className="min-h-14 w-full rounded-full bg-primary text-base font-semibold text-primary-foreground"
            >
              {t("close")}
            </button>
          </div>
        )}
      </Modal>
    </div>
  )
}
