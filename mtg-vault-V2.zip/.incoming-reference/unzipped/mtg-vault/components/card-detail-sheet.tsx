"use client"

import { useEffect, useState } from "react"
import {
  BookOpen,
  ChevronRight,
  ExternalLink,
  FileText,
  Gavel,
  Minus,
  Plus,
  Scale,
  Save,
  StickyNote,
  Trash2,
} from "lucide-react"
import type { CardData, Entry } from "@/lib/types"
import { CONDITIONS } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { money, signedPct } from "@/lib/format"
import { entryUnitPrice, seedHistory, trend } from "@/lib/prices"
import { getRulings, type Ruling } from "@/lib/scryfall"
import { CONDITION_META, conditionKey, safeCondition } from "@/lib/condition"
import { CARD_LANGUAGES, flagUrl } from "@/lib/languages"
import { Modal } from "@/components/ui/modal"
import { PriceChart } from "@/components/price-chart"
import { CollapsibleSection } from "@/components/ui/collapsible-section"
import { FoilOverlay } from "@/components/foil-overlay"
import { EditionPicker } from "@/components/edition-picker"
import { useToast } from "@/components/ui/toast"

const FORMATS = [
  "standard",
  "pioneer",
  "modern",
  "legacy",
  "vintage",
  "commander",
  "pauper",
  "brawl",
  "historic",
  "alchemy",
]

function LegalityBadge({ format, status }: { format: string; status: string }) {
  const map: Record<string, { bg: string; fg: string }> = {
    legal: { bg: "oklch(0.62 0.15 150 / 0.16)", fg: "oklch(0.5 0.15 150)" },
    not_legal: { bg: "var(--muted)", fg: "var(--muted-foreground)" },
    banned: { bg: "oklch(0.6 0.2 20 / 0.16)", fg: "oklch(0.55 0.2 20)" },
    restricted: { bg: "oklch(0.74 0.13 78 / 0.2)", fg: "oklch(0.5 0.12 70)" },
  }
  const s = map[status] ?? map.not_legal
  return (
    <div
      className="flex items-center justify-between rounded-lg px-3 py-2 text-sm"
      style={{ backgroundColor: s.bg }}
    >
      <span className="capitalize" style={{ color: "var(--foreground)" }}>
        {format}
      </span>
      <span className="text-xs font-semibold capitalize" style={{ color: s.fg }}>
        {status.replace("_", " ")}
      </span>
    </div>
  )
}

export function CardDetailSheet({ entry, onClose }: { entry: Entry | null; onClose: () => void }) {
  const { settings, folders, updateEntry, removeEntry, t } = useCollection()
  const toast = useToast()
  const [foilView, setFoilView] = useState(false)
  const [rulings, setRulings] = useState<Ruling[] | null>(null)
  const [loadingRulings, setLoadingRulings] = useState(false)
  const [editionOpen, setEditionOpen] = useState(false)
  const [priceDraft, setPriceDraft] = useState("")

  // Reset transient view state whenever a different entry opens.
  useEffect(() => {
    setFoilView(false)
    setRulings(null)
    setEditionOpen(false)
    const value = entry?.purchasePrice
    setPriceDraft(value != null ? value.toFixed(2).replace(".", ",") : "")
  }, [entry?.id])

  if (!entry) return null

  const cur = settings.currency
  const card = entry.card
  const isFoil = foilView || entry.foil
  const unit = entryUnitPrice({ ...entry, foil: isFoil }, cur)
  const change = trend(entry.priceHistory, cur)
  const folder = folders.find((f) => f.id === entry.folderId)
  const legalFormats = FORMATS.filter((f) => card.legalities[f] === "legal")

  const adjustQty = (delta: number) => {
    const q = Math.max(1, entry.quantity + delta)
    void updateEntry(entry.id, { quantity: q })
  }

  const commitPrice = async () => {
    const raw = priceDraft.trim().replace(",", ".")
    if (raw === "") {
      await updateEntry(entry.id, { purchasePrice: undefined })
      return
    }
    const n = Number.parseFloat(raw)
    if (Number.isFinite(n) && n >= 0) await updateEntry(entry.id, { purchasePrice: n })
  }

  const saveAndClose = async () => {
    await commitPrice()
    toast("Modifiche salvate")
    onClose()
  }

  // Switching edition swaps the card data and reseeds the market price history
  // so the chart and current value reflect the newly selected printing.
  const changeEdition = (print: CardData) => {
    void updateEntry(entry.id, { card: print, priceHistory: seedHistory(print) })
  }

  const loadRulings = async (open: boolean) => {
    if (!open || rulings != null || loadingRulings) return
    setLoadingRulings(true)
    const r = await getRulings(card)
    setRulings(r)
    setLoadingRulings(false)
  }

  return (
    <Modal open={!!entry} onClose={onClose} title={card.printedName || card.name}>
      <div className="space-y-4 p-5">
        {/* Header: image + price */}
        <div className="flex gap-4">
          {card.imageLarge || card.image ? (
            <div className="relative h-fit w-32 shrink-0 overflow-hidden rounded-xl shadow-md">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={card.imageLarge || card.image || ""}
                alt={card.name}
                loading="lazy"
                className="h-auto w-full"
              />
              {isFoil && <FoilOverlay />}
            </div>
          ) : null}
          <div className="min-w-0 flex-1 space-y-2">
            <div className="text-sm text-muted-foreground">{card.typeLine}</div>
            <div className="flex flex-wrap gap-1.5">
              <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-medium capitalize">
                {card.rarity}
              </span>
            </div>
            {/* Change edition / set */}
            <button
              onClick={() => setEditionOpen(true)}
              className="flex w-full items-center gap-2 rounded-lg border border-border bg-card px-2.5 py-1.5 text-left"
            >
              <span className="grid size-6 shrink-0 place-items-center rounded bg-muted font-mono text-[10px] font-bold">
                #{card.collectorNumber}
              </span>
              <span className="min-w-0 flex-1 truncate text-xs font-medium">{card.setName}</span>
              <ChevronRight className="size-4 shrink-0 text-muted-foreground" />
            </button>
            <div className="flex items-baseline gap-2 pt-1">
              <span className="font-mono text-2xl font-bold">{money(unit, cur)}</span>
              {change != null && (
                <span
                  className="text-sm font-semibold"
                  style={{ color: change >= 0 ? "oklch(0.55 0.15 150)" : "oklch(0.58 0.2 20)" }}
                >
                  {signedPct(change)}
                </span>
              )}
            </div>
            {(card.eurFoil != null || card.usdFoil != null) && (
              <button
                onClick={() => setFoilView((v) => !v)}
                className="text-xs text-muted-foreground underline underline-offset-2"
              >
                {foilView ? "Normal" : "Foil"}: {money(
                  cur === "eur" ? (foilView ? card.eur : card.eurFoil) : foilView ? card.usd : card.usdFoil,
                  cur,
                )}
              </button>
            )}
          </div>
        </div>

        {/* Price history (always visible) */}
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="mb-2 text-sm font-semibold">{t("priceHistory")}</div>
          <PriceChart history={entry.priceHistory} currency={cur} />
          <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{t("estimatedNote")}</p>
        </div>

        {/* Foil + price paid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5 rounded-2xl border border-border p-3">
            <span className="text-xs text-muted-foreground">{t("foil")}</span>
            <button
              onClick={() => void updateEntry(entry.id, { foil: !entry.foil })}
              role="switch"
              aria-checked={entry.foil}
              className={`h-9 rounded-xl border text-sm font-semibold transition-colors ${
                entry.foil
                  ? "border-transparent bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground"
              }`}
            >
              {entry.foil ? "★ Foil" : "☆ Normal"}
            </button>
          </div>
          <div className="flex flex-col gap-1.5 rounded-2xl border border-border p-3">
            <span className="text-xs text-muted-foreground">{t("pricePaid")}</span>
            <input
              inputMode="decimal"
              value={priceDraft}
              onChange={(e) => setPriceDraft(e.target.value)}
              onBlur={commitPrice}
              placeholder={money(unit, cur)}
              className="h-9 rounded-xl border border-border bg-background px-2.5 text-sm outline-none focus:border-primary"
            />
          </div>
        </div>

        {/* Card language */}
        <div className="rounded-2xl border border-border p-3">
          <div className="mb-2 text-xs text-muted-foreground">{t("cardLanguage")}</div>
          <div className="flex flex-wrap items-center gap-2">
            {CARD_LANGUAGES.map((l) => {
              const active = (entry.language ?? "en") === l.code
              return (
                <button
                  key={l.code}
                  onClick={() => void updateEntry(entry.id, { language: l.code })}
                  className={`flex shrink-0 items-center gap-1.5 rounded-xl border px-2.5 py-1.5 transition-colors ${
                    active ? "border-primary bg-primary/10" : "border-border"
                  }`}
                  aria-pressed={active}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={flagUrl(l.flag) || "/placeholder.svg"}
                    alt=""
                    aria-hidden
                    className="h-4 w-6 rounded-sm object-cover"
                  />
                  <span className={`text-xs font-semibold ${active ? "" : "text-muted-foreground"}`}>{l.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Quantity + condition + folder (always visible controls) */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-border p-3">
            <div className="mb-2 text-xs text-muted-foreground">{t("quantity")}</div>
            <div className="flex items-center justify-between">
              <button
                onClick={() => adjustQty(-1)}
                className="grid size-9 place-items-center rounded-full bg-muted"
                aria-label="minus"
              >
                <Minus className="size-4" />
              </button>
              <span className="font-mono text-xl font-bold">{entry.quantity}</span>
              <button
                onClick={() => adjustQty(1)}
                className="grid size-9 place-items-center rounded-full bg-muted"
                aria-label="plus"
              >
                <Plus className="size-4" />
              </button>
            </div>
          </div>
          <div className="rounded-2xl border border-border p-3">
            <div className="mb-2 text-xs text-muted-foreground">{t("folder")}</div>
            <select
              value={entry.folderId ?? ""}
              onChange={(e) => void updateEntry(entry.id, { folderId: e.target.value || null })}
              className="w-full rounded-lg bg-muted px-2 py-2 text-sm outline-none"
            >
              <option value="">{t("noFolder")}</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
            {folder && (
              <div className="mt-2 flex items-center gap-2 text-xs">
                <span className="size-3 rounded-full" style={{ backgroundColor: folder.color }} />
                <input
                  value={entry.position}
                  onChange={(e) => void updateEntry(entry.id, { position: e.target.value })}
                  placeholder={t("positionPh")}
                  className="w-full rounded bg-muted px-2 py-1 outline-none"
                />
              </div>
            )}
          </div>
        </div>

        {/* Condition editor */}
        <div className="rounded-2xl border border-border p-3">
          <div className="mb-2 flex items-center gap-1.5 text-xs text-muted-foreground">
            <Scale className="size-3.5" />
            {t("condition")}
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {CONDITIONS.map((c) => {
              const active = safeCondition(entry.condition) === c
              return (
                <button
                  key={c}
                  onClick={() => void updateEntry(entry.id, { condition: c })}
                  className="shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors"
                  style={
                    active
                      ? { backgroundColor: CONDITION_META[c].color, color: "#fff", borderColor: "transparent" }
                      : { borderColor: "var(--border)" }
                  }
                >
                  {c}
                </button>
              )
            })}
          </div>
          <div className="mt-1.5 text-[11px] text-muted-foreground">
            {t(conditionKey(safeCondition(entry.condition)) as any)}
          </div>
        </div>

        {/* Notes */}
        <CollapsibleSection
          title={t("notes")}
          icon={<StickyNote className="size-4 text-muted-foreground" />}
          defaultOpen={!!entry.note}
        >
          <textarea
            value={entry.note ?? ""}
            onChange={(e) => void updateEntry(entry.id, { note: e.target.value })}
            placeholder={t("notesPh")}
            rows={3}
            className="w-full resize-none rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
          />
        </CollapsibleSection>

        {/* Collapsible "più info" sections — unobtrusive by default */}
        <div className="space-y-2">
          {card.oracleText && (
            <CollapsibleSection title={t("oracleText")} icon={<FileText className="size-4 text-muted-foreground" />}>
              <p className="whitespace-pre-line text-sm leading-relaxed text-foreground">{card.oracleText}</p>
              {card.flavorText && (
                <p className="mt-3 whitespace-pre-line border-l-2 border-border pl-3 text-sm italic text-muted-foreground">
                  {card.flavorText}
                </p>
              )}
              {card.artist && (
                <p className="mt-3 text-[11px] text-muted-foreground">{card.artist}</p>
              )}
            </CollapsibleSection>
          )}

          <CollapsibleSection
            title={
              <span className="flex items-center gap-2">
                {t("legalWhere")}
                {legalFormats.length > 0 && (
                  <span className="rounded-full bg-primary/15 px-1.5 text-[10px] font-semibold text-primary-foreground">
                    {legalFormats.length}
                  </span>
                )}
              </span>
            }
            icon={<BookOpen className="size-4 text-muted-foreground" />}
          >
            <div className="grid grid-cols-2 gap-2">
              {FORMATS.filter((f) => card.legalities[f]).map((f) => (
                <LegalityBadge key={f} format={f} status={card.legalities[f]} />
              ))}
            </div>
          </CollapsibleSection>

          <CollapsibleSection
            title={t("rulings")}
            icon={<Gavel className="size-4 text-muted-foreground" />}
            onOpenChange={loadRulings}
          >
            {loadingRulings ? (
              <p className="text-sm text-muted-foreground">{t("loadingRulings")}</p>
            ) : rulings && rulings.length > 0 ? (
              <ul className="space-y-3">
                {rulings.map((r, i) => (
                  <li key={i} className="text-sm leading-relaxed">
                    <span className="mr-2 font-mono text-[11px] text-muted-foreground">{r.date}</span>
                    {r.comment}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">{t("noRulings")}</p>
            )}
          </CollapsibleSection>
        </div>

        <button
          type="button"
          onClick={() => void saveAndClose()}
          className="sticky bottom-2 z-10 flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-lg"
        >
          <Save className="size-5" />
          Salva e chiudi
        </button>

        {/* Actions */}
        <div className="flex gap-3 pt-1">
          {card.cardmarketUrl && (
            <a
              href={card.cardmarketUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-1 items-center justify-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
            >
              <ExternalLink className="size-4" />
              {t("viewOnCardmarket")}
            </a>
          )}
          <button
            onClick={() => {
              if (confirm(t("confirmDeleteEntry"))) {
                void removeEntry(entry.id)
                toast(t("delete"))
                onClose()
              }
            }}
            className="grid size-12 shrink-0 place-items-center rounded-full bg-destructive/10 text-destructive"
            aria-label={t("delete")}
          >
            <Trash2 className="size-5" />
          </button>
        </div>
      </div>

      <EditionPicker
        open={editionOpen}
        onClose={() => setEditionOpen(false)}
        card={card}
        selectedId={card.id}
        onSelect={changeEdition}
      />
    </Modal>
  )
}
