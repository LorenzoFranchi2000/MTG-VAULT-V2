// Renders an MTG mana cost string like "{2}{W}{U}" as Scryfall symbol SVGs.

interface Props {
  cost?: string
  size?: number
  className?: string
}

// Scryfall serves each symbol as an SVG, e.g. {W/U} -> WU.svg, {2} -> 2.svg.
function symbolUrl(token: string): string {
  const code = token.replace(/[{}]/g, "").replace(/\//g, "")
  return `https://svgs.scryfall.io/card-symbols/${code}.svg`
}

export function ManaCost({ cost, size = 20, className }: Props) {
  if (!cost) return null
  const tokens = cost.match(/\{[^}]+\}/g)
  if (!tokens || tokens.length === 0) return null
  return (
    <span className={`inline-flex items-center gap-0.5 ${className ?? ""}`}>
      {tokens.map((tok, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          key={`${tok}-${i}`}
          src={symbolUrl(tok) || "/placeholder.svg"}
          alt={tok.replace(/[{}]/g, "")}
          width={size}
          height={size}
          className="drop-shadow-sm"
          style={{ width: size, height: size }}
        />
      ))}
    </span>
  )
}
