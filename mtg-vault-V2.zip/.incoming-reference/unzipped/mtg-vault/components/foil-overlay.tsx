"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

/**
 * Animated rainbow holographic sheen for FOIL cards.
 * Place inside a `relative overflow-hidden` container that wraps the card image.
 * When `interactive`, the highlight follows the pointer (desktop) or the
 * device tilt / gyroscope (mobile) to mimic a real foil reflection.
 */
export function FoilOverlay({
  interactive = true,
  className,
}: {
  interactive?: boolean
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!interactive) return
    const el = ref.current
    const parent = el?.parentElement
    if (!el || !parent) return

    const setPos = (x: number, y: number) => {
      el.style.setProperty("--mx", `${Math.max(0, Math.min(100, x))}%`)
      el.style.setProperty("--my", `${Math.max(0, Math.min(100, y))}%`)
    }

    const onMove = (e: PointerEvent) => {
      const r = parent.getBoundingClientRect()
      setPos(((e.clientX - r.left) / r.width) * 100, ((e.clientY - r.top) / r.height) * 100)
    }
    const onLeave = () => setPos(50, 40)
    const onOrient = (e: DeviceOrientationEvent) => {
      // gamma: left/right (-90..90), beta: front/back (-180..180)
      setPos(50 + (e.gamma ?? 0), 50 + (e.beta ?? 0) / 2)
    }

    parent.addEventListener("pointermove", onMove)
    parent.addEventListener("pointerleave", onLeave)
    window.addEventListener("deviceorientation", onOrient)
    return () => {
      parent.removeEventListener("pointermove", onMove)
      parent.removeEventListener("pointerleave", onLeave)
      window.removeEventListener("deviceorientation", onOrient)
    }
  }, [interactive])

  return <div ref={ref} className={cn("foil-overlay pointer-events-none absolute inset-0", className)} aria-hidden />
}
