"use client"

import { useEffect } from "react"

// Registers public/sw.js so the installed PWA works offline and reloads
// instantly. Skipped outside production so dev's hot-reload never fights a
// stale cached bundle.
export function RegisterServiceWorker() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) return
    if (process.env.NODE_ENV !== "production") return
    navigator.serviceWorker.register("/sw.js").catch(() => {})
  }, [])
  return null
}
