"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { Check, Loader2, Search } from "lucide-react"
import type { CardData } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { getPrints } from "@/lib/scryfall"
import { money } from "@/lib/format"
import { Modal } from "@/components/ui/modal"

export function EditionPicker({
  open,
  onClose,
  card,
  selectedId,
  onSelect,
}: {
  open: boolean
  onClose: () => void
  /** The card whose reprints we list (any print of it). */
  card: CardData
  selectedId: string
  onSelect: (print: CardData) => void
}) {
  const { settings, t } = useCollection()
  const [prints, setPrints] = useState<CardData[]>([])
  const [loading, setLoading] = useState(false)
  const [filter, setFilter] = useState("")
  const cacheKey = useRef<string>("")

  // Fetch prints once per card (by oracle id) when the picker opens.
  useEffect(() => {
    if (!open) return
    const key = card.oracleId || card.name
    if (cacheKey.current === key && prints.length) return
    setLoading(true)
    getPrints(card, settings.lang).then((res) => {
      cacheKey.current = key
      setPrints(res)
      setLoading(false)
    })
  }, [open, card, settings.lang, prints.length])

  const filtered = useMemo(() => {
    const f = filter.trim().toLowerCase()
    if (!f) return prints
    return prints.filter(
      (p) =>
        p.setName.toLowerCase().includes(f) ||
        p.set.toLowerCase().includes(f) ||
        (p.collectorNumber ?? "").toLowerCase().includes(f),
    )
  }, [prints, filter])

  return (
    <Modal open={open} onClose={onClose} title={t("chooseEdition")}>
      <div className="flex flex-col">
        {/* Filter by set name / number */}
        <div className="sticky top-0 z-10 border-b border-border bg-card px-4 py-3">
          <div className="flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2.5">
            <Search className="size-4 shrink-0 text-muted-foreground" />
            <input
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder={t("searchEditionPh")}
              inputMode="search"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
          {!loading && (
            <div className="mt-2 text-xs text-muted-foreground">
              {filtered.length} {t("printsCount")}
            </div>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> …
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-sm text-muted-foreground">{t("noEditions")}</div>
        ) : (
          <ul className="divide-y divide-border pb-[env(safe-area-inset-bottom)]">
            {filtered.map((p) => {
              const active = p.id === selectedId
              return (
                <li key={p.id}>
                  <button
                    onClick={() => {
                      onSelect(p)
                      onClose()
                    }}
                    className="flex w-full items-center gap-3 px-4 py-3 text-left"
                  >
                    {p.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={p.image || "/placeholder.svg"}
                        alt=""
                        loading="lazy"
                        className="h-14 w-auto shrink-0 rounded-md"
                      />
                    ) : (
                      <div className="h-14 w-10 shrink-0 rounded-md bg-muted" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold">{p.setName}</div>
                      <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="rounded bg-muted px-1.5 py-0.5 font-mono">
                          #{p.collectorNumber}
                        </span>
                        <span className="uppercase">{p.set}</span>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="font-mono text-sm font-bold">{money(p.eur, "eur")}</div>
                      {p.eurFoil != null && (
                        <div className="text-[10px] text-muted-foreground">
                          {t("foil")} {money(p.eurFoil, "eur")}
                        </div>
                      )}
                    </div>
                    {active && (
                      <span className="ml-1 grid size-5 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                        <Check className="size-3.5" />
                      </span>
                    )}
                  </button>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </Modal>
  )
}
