"use client"

import type { Entry, Folder } from "@/lib/types"
import { money } from "@/lib/format"
import { entryUnitPrice } from "@/lib/prices"
import { conditionMeta, safeCondition } from "@/lib/condition"
import { FoilOverlay } from "@/components/foil-overlay"

interface Props {
  entry: Entry
  folder?: Folder
  currency: "eur" | "usd"
  onClick: () => void
}

// Image-first grid tile (Dragon Shield style) used in the vault and folders.
export function CardTile({ entry, folder, currency, onClick }: Props) {
  const card = entry.card
  const unit = entryUnitPrice(entry, currency)
  const cond = conditionMeta(entry.condition)
  return (
    <button
      onClick={onClick}
      className="group relative overflow-hidden rounded-xl border border-border bg-muted text-left transition-transform active:scale-[0.98]"
    >
      <div className="relative aspect-[63/88] w-full">
        {card.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={card.image || "/placeholder.svg"}
            alt={card.printedName || card.name}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="grid h-full place-items-center p-2 text-center text-[11px] text-muted-foreground">
            {card.name}
          </div>
        )}

        {/* Foil holographic sheen (non-interactive in grid for performance) */}
        {entry.foil && <FoilOverlay interactive={false} />}

        {/* Quantity badge */}
        {entry.quantity > 1 && (
          <span className="absolute left-1.5 top-1.5 rounded-md bg-black/70 px-1.5 py-0.5 font-mono text-[11px] font-bold text-white">
            ×{entry.quantity}
          </span>
        )}
        {/* Foil badge */}
        {entry.foil && (
          <span className="absolute right-1.5 top-1.5 rounded-md bg-primary px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">
            FOIL
          </span>
        )}

        {/* Price + condition footer */}
        <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-1 bg-gradient-to-t from-black/85 to-transparent px-1.5 pb-1.5 pt-4">
          <span className="font-mono text-xs font-bold text-white">{money(unit, currency)}</span>
          <span
            className="rounded px-1 py-0.5 text-[9px] font-bold text-white"
            style={{ backgroundColor: cond.color }}
          >
            {cond.short}
          </span>
        </div>
      </div>

      {folder && (
        <span
          className="absolute inset-x-0 top-0 h-1"
          style={{ backgroundColor: folder.color }}
          aria-hidden="true"
        />
      )}
    </button>
  )
}
