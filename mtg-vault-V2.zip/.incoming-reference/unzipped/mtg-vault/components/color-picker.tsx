"use client"

import { Check } from "lucide-react"
import { FOLDER_COLORS } from "@/lib/collection-context"
import { contrastText } from "@/lib/format"

export function ColorPicker({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {FOLDER_COLORS.map((c) => {
        const active = value.toLowerCase() === c.toLowerCase()
        return (
          <button
            key={c}
            type="button"
            onClick={() => onChange(c)}
            className={`grid size-9 place-items-center rounded-full border-2 transition-transform ${
              active ? "scale-110 border-foreground" : "border-transparent"
            }`}
            style={{ backgroundColor: c }}
            aria-label={c}
          >
            {active && <Check className="size-4" style={{ color: contrastText(c) }} />}
          </button>
        )
      })}
      <label
        className="grid size-9 cursor-pointer place-items-center overflow-hidden rounded-full border-2 border-dashed border-muted-foreground text-xs"
        title="Custom"
      >
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="size-10 cursor-pointer opacity-0"
        />
        <span className="pointer-events-none absolute" style={{ color: "var(--muted-foreground)" }}>
          +
        </span>
      </label>
    </div>
  )
}
