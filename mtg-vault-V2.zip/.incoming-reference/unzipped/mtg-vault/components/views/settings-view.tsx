"use client"

import { useRef } from "react"
import { Download, HardDrive, Upload } from "lucide-react"
import type { AccentKey, DensityKey, LangCode, Settings, ShapeKey } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { ACCENTS, DENSITIES, SHAPES } from "@/lib/appearance"
import type { BackgroundKey } from "@/lib/folder-style"
import { BackgroundPicker } from "@/components/folder-style-picker"
import { ImportExportPanel } from "@/components/import-export-panel"
import { useToast } from "@/components/ui/toast"

export function SettingsView() {
  const { settings, setSettings, t, exportData, importData } = useCollection()
  const toast = useToast()
  const fileRef = useRef<HTMLInputElement>(null)

  const doExport = () => {
    const blob = new Blob([exportData()], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `mtg-vault-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const doImport = async (file: File) => {
    const text = await file.text()
    const ok = await importData(text)
    toast(ok ? t("importDone") : t("importErr"))
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-4 lg:max-w-5xl lg:px-8">
      <Section title={t("language")}>
        <Segmented
          value={settings.lang}
          options={[
            { value: "it", label: "Italiano" },
            { value: "en", label: "English" },
          ]}
          onChange={(v) => void setSettings({ lang: v as LangCode })}
        />
      </Section>

      <Section title={t("theme")}>
        <Segmented
          value={settings.theme}
          options={[
            { value: "light", label: t("themeLight") },
            { value: "dark", label: t("themeDark") },
            { value: "system", label: t("themeSystem") },
          ]}
          onChange={(v) => void setSettings({ theme: v as Settings["theme"] })}
        />
      </Section>

      <Section title={t("currency")}>
        <Segmented
          value={settings.currency}
          options={[
            { value: "eur", label: "EUR € (Cardmarket)" },
            { value: "usd", label: "USD $" },
          ]}
          onChange={(v) => void setSettings({ currency: v as Settings["currency"] })}
        />
      </Section>

      <Section title={t("appearance")}>
        <div className="rounded-2xl border border-border bg-card p-4">
          {/* Accent color */}
          <div className="mb-2 text-xs font-medium text-muted-foreground">{t("accentColor")}</div>
          <div className="flex flex-wrap gap-2.5">
            {(Object.keys(ACCENTS) as AccentKey[]).map((k) => {
              const on = settings.accent === k
              return (
                <button
                  key={k}
                  onClick={() => void setSettings({ accent: k })}
                  aria-pressed={on}
                  aria-label={t(ACCENTS[k].labelKey)}
                  className={`size-9 rounded-full transition-all ${
                    on ? "ring-2 ring-foreground ring-offset-2 ring-offset-card" : "opacity-80"
                  }`}
                  style={{ backgroundColor: ACCENTS[k].swatch }}
                />
              )
            })}
          </div>

          {/* Corner shape */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("shape")}</div>
          <Segmented
            value={settings.shape}
            options={(Object.keys(SHAPES) as ShapeKey[]).map((k) => ({ value: k, label: t(SHAPES[k].labelKey) }))}
            onChange={(v) => void setSettings({ shape: v as ShapeKey })}
          />

          {/* Grid density */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("layoutDensity")}</div>
          <Segmented
            value={settings.density}
            options={(Object.keys(DENSITIES) as DensityKey[]).map((k) => ({
              value: k,
              label: t(DENSITIES[k].labelKey),
            }))}
            onChange={(v) => void setSettings({ density: v as DensityKey })}
          />

          {/* Backdrop for the collection / folder views */}
          <div className="mb-2 mt-5 text-xs font-medium text-muted-foreground">{t("collectionBackground")}</div>
          <BackgroundPicker
            value={settings.collectionBackground}
            color={ACCENTS[settings.accent].swatch}
            onChange={(v: BackgroundKey) => void setSettings({ collectionBackground: v })}
            t={t}
          />
        </div>
      </Section>

      <Section title={t("dataManagement")}>
        <ImportExportPanel />
      </Section>

      <Section title={t("storage")}>
        <div className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-start gap-3">
            <HardDrive className="mt-0.5 size-5 shrink-0 text-muted-foreground" />
            <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{t("storageDesc")}</p>
          </div>
          <div className="mt-4 flex gap-2.5">
            <button
              onClick={doExport}
              className="flex flex-1 items-center justify-center gap-2 rounded-full border border-border py-3 text-sm font-semibold"
            >
              <Download className="size-4" />
              {t("exportData")}
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="flex flex-1 items-center justify-center gap-2 rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground"
            >
              <Upload className="size-4" />
              {t("importData")}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) void doImport(f)
                e.target.value = ""
              }}
            />
          </div>
        </div>
      </Section>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        MTG Vault · Magic: The Gathering collection manager · data by Scryfall
      </p>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h3>
      {children}
    </div>
  )
}

function Segmented({
  value,
  options,
  onChange,
}: {
  value: string
  options: { value: string; label: string }[]
  onChange: (v: string) => void
}) {
  return (
    <div className="flex gap-1.5 rounded-2xl border border-border bg-card p-1.5">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
            value === o.value ? "bg-foreground text-background" : "text-muted-foreground"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
