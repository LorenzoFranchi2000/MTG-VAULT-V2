"use client"

import { ScanView } from "@/components/views/scan-view"

/** Single scanner engine. The experimental recognition pipeline is flagged BETA. */
export function ScanTab({
  onDone,
  lockedFolderId,
}: {
  onDone: () => void
  lockedFolderId?: string
}) {
  return <ScanView onDone={onDone} lockedFolderId={lockedFolderId} />
}
