"use client"

import { useMemo, useState } from "react"
import { ChevronLeft, Layers, Plus, ScanLine } from "lucide-react"
import type { Entry, Folder } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { money } from "@/lib/format"
import { entryValue } from "@/lib/prices"
import { applyFilterSort, EMPTY_FILTER, type FilterState, type SortKey } from "@/lib/card-filter"
import { gridColsClass } from "@/lib/appearance"
import { backgroundClass, backgroundStyle, folderIcon, withAlpha } from "@/lib/folder-style"
import { CardTile } from "@/components/card-tile"
import { CardFilterBar } from "@/components/card-filter-bar"
import { AddView } from "@/components/views/add-view"
import { ScanTab } from "@/components/views/scan-tab"

type Mode = "grid" | "add" | "scan"

export function FolderDetailView({
  folder,
  onBack,
  onOpen,
}: {
  folder: Folder
  onBack: () => void
  onOpen: (e: Entry) => void
}) {
  const { entries, settings, t } = useCollection()
  const [mode, setMode] = useState<Mode>("grid")
  const [filter, setFilter] = useState<FilterState>(EMPTY_FILTER)
  const [sort, setSort] = useState<SortKey>("name")
  const cur = settings.currency

  // All cards in this folder (unfiltered) — drives the header totals.
  const folderCards = useMemo(
    () => entries.filter((e) => e.folderId === folder.id),
    [entries, folder.id],
  )
  // Filter + sort applied together in a single pass for the grid.
  const cards = useMemo(
    () => applyFilterSort(folderCards, filter, sort, cur),
    [folderCards, filter, sort, cur],
  )
  const stats = useMemo(() => {
    const copies = folderCards.reduce((s, e) => s + e.quantity, 0)
    const value = folderCards.reduce((s, e) => s + entryValue(e, cur), 0)
    return { copies, value }
  }, [folderCards, cur])

  if (mode === "add") {
    return (
      <SubScreen title={t("addHere")} folder={folder} onBack={() => setMode("grid")} t={t}>
        <AddView lockedFolderId={folder.id} onDone={() => setMode("grid")} />
      </SubScreen>
    )
  }
  if (mode === "scan") {
    return (
      <SubScreen title={t("scanHere")} folder={folder} onBack={() => setMode("grid")} t={t}>
        <ScanTab lockedFolderId={folder.id} onDone={() => setMode("grid")} />
      </SubScreen>
    )
  }

  return (
    <div className="relative mx-auto w-full max-w-3xl px-4 pb-28 pt-4 lg:max-w-7xl lg:px-8">
      {/* Folder backdrop */}
      <div
        className={`pointer-events-none fixed inset-0 -z-10 ${backgroundClass(folder.background)}`}
        style={backgroundStyle(folder.background, folder.color)}
        aria-hidden="true"
      />
      <button
        onClick={onBack}
        className="mb-3 flex min-h-11 items-center gap-1 text-sm font-medium text-muted-foreground"
      >
        <ChevronLeft className="size-5" />
        {t("folders")}
      </button>

      {/* Folder header */}
      <div
        className={`relative mb-4 flex items-center gap-3 overflow-hidden rounded-2xl border border-border bg-card p-4 ${backgroundClass(
          folder.background,
        )}`}
      >
        <span
          className="pointer-events-none absolute inset-0"
          style={backgroundStyle(folder.background, folder.color)}
          aria-hidden="true"
        />
        <span
          className="relative grid size-12 shrink-0 place-items-center rounded-xl"
          style={{ backgroundColor: withAlpha(folder.color, 0.22), color: folder.color }}
        >
          {(() => {
            const Icon = folderIcon(folder.icon)
            return <Icon className="size-6" />
          })()}
        </span>
        <div className="relative min-w-0 flex-1">
          <div className="truncate text-lg font-bold">{folder.name}</div>
          <div className="font-mono text-xs text-muted-foreground">
            {stats.copies} {t("cards")} · {money(stats.value, cur)}
          </div>
        </div>
      </div>

      {/* Add / Scan into this folder */}
      <div className="mb-4 grid grid-cols-2 gap-2.5">
        <button
          onClick={() => setMode("add")}
          className="flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-base font-semibold text-primary-foreground"
        >
          <Plus className="size-5" />
          {t("addHere")}
        </button>
        <button
          onClick={() => setMode("scan")}
          className="flex min-h-14 items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3.5 text-base font-semibold"
        >
          <ScanLine className="size-5" />
          {t("scanHere")}
        </button>
      </div>

      {folderCards.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border py-16 text-center">
          <Layers className="size-8 text-muted-foreground" />
          <div className="font-semibold">{t("noCardsInFolder")}</div>
          <div className="max-w-xs text-sm text-muted-foreground text-pretty">{t("noCardsInFolderSub")}</div>
        </div>
      ) : (
        <>
          <CardFilterBar
            filter={filter}
            sort={sort}
            onFilter={setFilter}
            onSort={setSort}
            resultCount={cards.length}
            t={t}
          />
          {cards.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border py-16 text-center">
              <Layers className="size-8 text-muted-foreground" />
              <div className="font-semibold">{t("noResults")}</div>
            </div>
          ) : (
            <div className={`grid ${gridColsClass(settings.density)}`}>
              {cards.map((e) => (
                <CardTile key={e.id} entry={e} currency={cur} onClick={() => onOpen(e)} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}

function SubScreen({
  title,
  folder,
  onBack,
  t,
  children,
}: {
  title: string
  folder: Folder
  onBack: () => void
  t: (k: any) => string
  children: React.ReactNode
}) {
  return (
    <div>
      <div className="mx-auto w-full max-w-3xl px-4 pt-4 lg:max-w-6xl lg:px-8">
        <button onClick={onBack} className="mb-2 flex items-center gap-1 text-sm font-medium text-muted-foreground">
          <ChevronLeft className="size-4" />
          {folder.name}
        </button>
        <div className="mb-1 flex items-center gap-2">
          <span className="size-4 rounded-full" style={{ backgroundColor: folder.color }} />
          <span className="text-lg font-bold">{title}</span>
        </div>
        <p className="mb-1 text-xs text-muted-foreground">{t("scanIntoFolder")}</p>
      </div>
      {children}
    </div>
  )
}
