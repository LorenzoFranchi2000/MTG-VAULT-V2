"use client"

import { useEffect, useRef, useState } from "react"
import { ChevronLeft, ChevronRight, Loader2, Minus, Plus, Search, Sparkles } from "lucide-react"
import type { CardData, Condition } from "@/lib/types"
import { CONDITIONS } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { money } from "@/lib/format"
import { searchCards } from "@/lib/scryfall"
import { CONDITION_META, conditionKey } from "@/lib/condition"
import { CARD_LANGUAGES, flagUrl } from "@/lib/languages"
import { ManaCost } from "@/components/mana-cost"
import { EditionPicker } from "@/components/edition-picker"
import { FoilOverlay } from "@/components/foil-overlay"
import { useToast } from "@/components/ui/toast"

function dateToInput(ts: number): string {
  const d = new Date(ts)
  const off = d.getTimezoneOffset()
  return new Date(ts - off * 60000).toISOString().slice(0, 10)
}

export function AddView({
  onDone,
  initialQuery = "",
  lockedFolderId,
}: {
  onDone: () => void
  initialQuery?: string
  /** When set, all adds go into this folder and the picker is hidden. */
  lockedFolderId?: string
}) {
  const { folders, settings, addEntry, t } = useCollection()
  const toast = useToast()
  const [q, setQ] = useState(initialQuery)
  const [results, setResults] = useState<CardData[]>([])
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState<CardData | null>(null)
  const [editionOpen, setEditionOpen] = useState(false)
  const [folderId, setFolderId] = useState<string>(lockedFolderId ?? "")
  const [position, setPosition] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [foil, setFoil] = useState(false)
  const [condition, setCondition] = useState<Condition>("NM")
  const [language, setLanguage] = useState<string>(settings.lang === "it" ? "it" : "en")
  const [priceInput, setPriceInput] = useState("")
  const [dateBought, setDateBought] = useState(dateToInput(Date.now()))
  const reqId = useRef(0)

  const cur = settings.currency

  // Debounced search-as-you-type — one result per distinct card.
  useEffect(() => {
    const term = q.trim()
    if (term.length < 2) {
      setResults([])
      setLoading(false)
      return
    }
    setLoading(true)
    const id = ++reqId.current
    const timer = setTimeout(async () => {
      const res = await searchCards(term, settings.lang)
      if (id === reqId.current) {
        setResults(res)
        setLoading(false)
      }
    }, 350)
    return () => clearTimeout(timer)
  }, [q, settings.lang])

  const unitPrice = foil ? selected?.eurFoil ?? selected?.eur : selected?.eur
  const currentUnit =
    (cur === "eur" ? (foil ? selected?.eurFoil ?? selected?.eur : selected?.eur) : foil ? selected?.usdFoil ?? selected?.usd : selected?.usd) ?? null

  const chooseCard = (c: CardData) => {
    setSelected(c)
    setQuantity(1)
    setFoil(false)
    setCondition("NM")
    setPosition("")
    setLanguage(settings.lang === "it" ? "it" : "en")
    setPriceInput("") // empty = use current average
    setDateBought(dateToInput(Date.now()))
  }

  const resetForm = () => {
    setSelected(null)
    setPosition("")
    setQuantity(1)
    setFoil(false)
    setCondition("NM")
    setPriceInput("")
  }

  const submit = async () => {
    if (!selected) return
    const parsed = Number.parseFloat(priceInput.replace(",", "."))
    const purchasePrice = Number.isFinite(parsed) ? parsed : currentUnit ?? undefined
    await addEntry(selected, {
      folderId: folderId || null,
      position,
      quantity,
      foil,
      condition,
      language,
      purchasePrice,
      addedAt: new Date(dateBought + "T12:00:00").getTime(),
    })
    toast(t("saved"))
    resetForm()
    onDone()
  }

  // ---- Full-screen add panel (after a card is chosen) ----
  if (selected) {
    const art = selected.artCrop || selected.imageLarge || selected.image
    return (
      <>
        <div className="mx-auto w-full max-w-3xl pb-28">
          {/* Artwork hero */}
          <div className="relative">
            {art && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={art || "/placeholder.svg"}
                alt=""
                aria-hidden
                className="h-52 w-full object-cover"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/10" />
            <button
              onClick={resetForm}
              className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-background/70 py-1.5 pl-2 pr-3 text-sm font-medium backdrop-blur"
            >
              <ChevronLeft className="size-4" />
              {t("back")}
            </button>

            {/* Card identity overlaid on the art */}
            <div className="absolute inset-x-0 bottom-0 flex items-end gap-3 px-4 pb-3">
              {selected.image && (
                <div className="relative h-32 shrink-0 overflow-hidden rounded-lg shadow-lg ring-1 ring-black/10">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={selected.image || "/placeholder.svg"} alt={selected.name} className="h-32 w-auto" />
                  {foil && <FoilOverlay />}
                </div>
              )}
              <div className="min-w-0 flex-1 pb-1">
                <ManaCost cost={selected.manaCost} size={18} className="mb-1" />
                <h2 className="text-xl font-bold leading-tight text-balance">
                  {selected.printedName || selected.name}
                </h2>
                <p className="mt-0.5 text-sm text-muted-foreground">{selected.typeLine}</p>
              </div>
            </div>
          </div>

          <div className="px-4">
            {/* Edition / reprint picker */}
            <div className="mt-4">
              <div className="mb-1.5 text-xs font-medium text-muted-foreground">{t("edition")}</div>
              <button
                onClick={() => setEditionOpen(true)}
                className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3 text-left"
              >
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-muted font-mono text-xs font-bold">
                  #{selected.collectorNumber}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{selected.setName}</span>
                  <span className="block text-xs uppercase text-muted-foreground">{selected.set}</span>
                </span>
                <span className="shrink-0 font-mono text-sm font-bold">{money(unitPrice, cur)}</span>
                <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
              </button>
            </div>

            {/* Folder + position */}
            <div className="mt-4 grid grid-cols-2 gap-2">
              {!lockedFolderId && (
                <label className="flex flex-col gap-1.5">
                  <span className="text-xs font-medium text-muted-foreground">{t("folders")}</span>
                  <select
                    value={folderId}
                    onChange={(e) => setFolderId(e.target.value)}
                    className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none"
                  >
                    <option value="">{t("noFolder")}</option>
                    {folders.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              <label className={`flex flex-col gap-1.5 ${lockedFolderId ? "col-span-2" : ""}`}>
                <span className="text-xs font-medium text-muted-foreground">{t("position")}</span>
                <input
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  placeholder={t("positionPh")}
                  className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none"
                />
              </label>
            </div>

            {/* Quantity + Foil */}
            <div className="mt-4 flex items-end gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-xs font-medium text-muted-foreground">{t("quantity")}</span>
                <div className="flex items-center gap-2 rounded-xl border border-border px-2 py-1.5">
                  <button
                    onClick={() => setQuantity((n) => Math.max(1, n - 1))}
                    className="grid size-8 place-items-center rounded-full bg-muted"
                    aria-label="-"
                  >
                    <Minus className="size-4" />
                  </button>
                  <span className="w-8 text-center font-mono text-base font-bold">{quantity}</span>
                  <button
                    onClick={() => setQuantity((n) => n + 1)}
                    className="grid size-8 place-items-center rounded-full bg-muted"
                    aria-label="+"
                  >
                    <Plus className="size-4" />
                  </button>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-1.5">
                <span className="text-xs font-medium text-muted-foreground">{t("foil")}</span>
                <button
                  onClick={() => setFoil((v) => !v)}
                  role="switch"
                  aria-checked={foil}
                  className={`h-[42px] rounded-xl border px-4 text-sm font-semibold transition-colors ${
                    foil
                      ? "border-transparent bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground"
                  }`}
                >
                  {foil ? "★" : "☆"} {t("foil")}
                </button>
              </div>
            </div>

            {/* Date bought + Price paid */}
            <div className="mt-4 grid grid-cols-2 gap-2">
              <label className="flex flex-col gap-1.5">
                <span className="text-xs font-medium text-muted-foreground">{t("dateBought")}</span>
                <input
                  type="date"
                  value={dateBought}
                  onChange={(e) => setDateBought(e.target.value)}
                  className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none"
                />
              </label>
              <label className="flex flex-col gap-1.5">
                <span className="text-xs font-medium text-muted-foreground">{t("pricePaid")}</span>
                <input
                  inputMode="decimal"
                  value={priceInput}
                  onChange={(e) => setPriceInput(e.target.value)}
                  placeholder={currentUnit != null ? money(currentUnit, cur) : "0.00"}
                  className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none"
                />
              </label>
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">{t("pricePaidHint")}</div>

            {/* Language */}
            <div className="mt-4">
              <div className="mb-1.5 text-xs font-medium text-muted-foreground">{t("language")}</div>
              <div className="flex flex-wrap items-center gap-2">
                {CARD_LANGUAGES.map((l) => {
                  const active = language === l.code
                  return (
                    <button
                      key={l.code}
                      onClick={() => setLanguage(l.code)}
                      className={`flex shrink-0 items-center gap-1.5 rounded-xl border px-2.5 py-1.5 transition-colors ${
                        active ? "border-primary bg-primary/10" : "border-border"
                      }`}
                      aria-pressed={active}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={flagUrl(l.flag) || "/placeholder.svg"}
                        alt=""
                        aria-hidden
                        className="h-4 w-6 rounded-sm object-cover"
                      />
                      <span className={`text-xs font-semibold ${active ? "" : "text-muted-foreground"}`}>
                        {l.label}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Condition */}
            <div className="mt-4">
              <div className="mb-1.5 text-xs font-medium text-muted-foreground">{t("condition")}</div>
              <div className="flex items-center gap-2">
                {CONDITIONS.map((c) => {
                  const active = condition === c
                  return (
                    <button
                      key={c}
                      onClick={() => setCondition(c)}
                      className="flex flex-1 flex-col items-center gap-1 rounded-xl border py-2 transition-colors"
                      style={
                        active
                          ? {
                              backgroundColor: CONDITION_META[c].color,
                              color: "#fff",
                              borderColor: "transparent",
                            }
                          : { borderColor: "var(--border)" }
                      }
                      title={t(conditionKey(c) as any)}
                    >
                      <span className="text-sm font-bold">{c}</span>
                    </button>
                  )
                })}
              </div>
              <div className="mt-1.5 text-center text-[11px] text-muted-foreground">
                {t(conditionKey(condition) as any)}
              </div>
            </div>
          </div>
        </div>

        {/* Sticky save bar */}
        <div className="safe-bottom fixed inset-x-0 bottom-[68px] z-20 border-t border-border bg-card/95 px-4 py-3 backdrop-blur">
          <div className="mx-auto max-w-3xl">
            <button
              onClick={submit}
              className="w-full rounded-full bg-primary py-3.5 text-base font-bold text-primary-foreground"
            >
              {t("addToVault")}
            </button>
          </div>
        </div>

        <EditionPicker
          open={editionOpen}
          onClose={() => setEditionOpen(false)}
          card={selected}
          selectedId={selected.id}
          onSelect={(print) => setSelected(print)}
        />
      </>
    )
  }

  // ---- Search step (one result per distinct card) ----
  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-4">
      <div className="mb-3 flex items-center gap-2 rounded-2xl border border-border bg-card px-3.5 py-3">
        <Search className="size-5 shrink-0 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t("searchScryfall")}
          autoFocus
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
        {loading && <Loader2 className="size-4 shrink-0 animate-spin text-muted-foreground" />}
      </div>

      {q.trim().length < 2 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-3xl border border-dashed border-border py-16 text-center">
          <Sparkles className="size-8 text-muted-foreground" />
          <div className="max-w-xs text-sm text-muted-foreground text-pretty">{t("typeToSearch")}</div>
        </div>
      ) : (
        <ul className="flex flex-col gap-2">
          {results.map((c) => (
            <li key={c.id}>
              <button
                onClick={() => chooseCard(c)}
                className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-2.5 text-left"
              >
                {c.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={c.image || "/placeholder.svg"}
                    alt={c.name}
                    loading="lazy"
                    className="h-16 w-auto shrink-0 rounded-md"
                  />
                ) : (
                  <div className="h-16 w-12 shrink-0 rounded-md bg-muted" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{c.printedName || c.name}</div>
                  <div className="mt-0.5 flex items-center gap-2">
                    <ManaCost cost={c.manaCost} size={14} />
                    <span className="truncate text-xs text-muted-foreground">{c.typeLine}</span>
                  </div>
                  <div className="mt-1 font-mono text-xs font-bold">{money(c.eur, cur)}</div>
                </div>
                <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
