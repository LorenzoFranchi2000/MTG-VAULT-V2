"use client"

import { useMemo } from "react"
import { X } from "lucide-react"
import { useCollection } from "@/lib/collection-context"
import { money, signedPct } from "@/lib/format"
import {
  collectionComposition,
  collectionSeries,
  collectionStats,
  entryValue,
  type ColorKey,
  type RarityKey,
} from "@/lib/prices"
import { PriceChart } from "@/components/price-chart"

// Swatch + label metadata for the five MTG colors plus colorless.
const COLOR_META: Record<ColorKey, { hex: string; text: string; key: string }> = {
  W: { hex: "#f5e7c0", text: "#3a3320", key: "colorWhite" },
  U: { hex: "#2f7fd6", text: "#ffffff", key: "colorBlue" },
  B: { hex: "#3f3a45", text: "#ffffff", key: "colorBlack" },
  R: { hex: "#d6452c", text: "#ffffff", key: "colorRed" },
  G: { hex: "#2f9e5a", text: "#ffffff", key: "colorGreen" },
  C: { hex: "#a7adb5", text: "#26282c", key: "colorColorless" },
}

const RARITY_META: Record<RarityKey, { hex: string; key: string }> = {
  mythic: { hex: "#e2662b", key: "mythic" },
  rare: { hex: "#c9a227", key: "rare" },
  uncommon: { hex: "#8a9ba8", key: "uncommon" },
  common: { hex: "#4b4f57", key: "common" },
}

export function StatsView({ onClose }: { onClose: () => void }) {
  const { entries, folders, settings, t } = useCollection()
  const cur = settings.currency

  const total = useMemo(() => collectionStats(entries, cur), [entries, cur])
  const series = useMemo(() => collectionSeries(entries, cur), [entries, cur])
  const comp = useMemo(() => collectionComposition(entries), [entries])

  // Use the most valuable card's art as the hero background.
  const heroArt = useMemo(() => {
    if (entries.length === 0) return null
    const top = [...entries].sort((a, b) => entryValue(b, cur) - entryValue(a, cur))[0]
    return top.card.artCrop || top.card.imageLarge || top.card.image
  }, [entries, cur])

  // Per-folder breakdown (plus an "unfiled" bucket).
  const breakdown = useMemo(() => {
    const rows = folders.map((f) => {
      const es = entries.filter((e) => e.folderId === f.id)
      const s = collectionStats(es, cur)
      return { id: f.id, name: f.name, color: f.color, ...s }
    })
    const unfiled = entries.filter((e) => !e.folderId)
    if (unfiled.length) {
      rows.push({ id: "none", name: t("noFolder"), color: "#8b8b8b", ...collectionStats(unfiled, cur) })
    }
    return rows.filter((r) => r.copies > 0).sort((a, b) => b.current - a.current)
  }, [folders, entries, cur, t])

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-background">
      {/* Hero */}
      <div className="relative">
        {heroArt && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={heroArt || "/placeholder.svg"} alt="" aria-hidden className="h-56 w-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/20" />
        <div className="safe-top absolute inset-x-0 top-0 flex items-center justify-between px-4 py-3">
          <span className="text-sm font-semibold">{t("statistics")}</span>
          <button
            onClick={onClose}
            className="grid size-9 place-items-center rounded-full bg-background/70 backdrop-blur"
            aria-label={t("close")}
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="absolute inset-x-0 bottom-0 px-4 pb-4">
          <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {t("allMyCards")}
          </div>
          <div className="mt-2 flex items-end gap-4">
            <HeroStat label={t("invested")} value={money(total.invested, cur)} />
            <HeroStat label={t("current")} value={money(total.current, cur)} big />
            <HeroStat
              label={t("win")}
              value={signedPct(total.winPct)}
              color={total.winPct == null ? undefined : total.winPct >= 0 ? "up" : "down"}
            />
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 pb-16">
        {entries.length === 0 ? (
          <div className="mt-10 rounded-3xl border border-dashed border-border py-16 text-center text-sm text-muted-foreground">
            {t("noStatsYet")}
          </div>
        ) : (
          <>
            {/* Dashboard: counts + est. value */}
            <div className="mt-5 grid grid-cols-3 gap-2.5">
              <div className="rounded-2xl border border-border bg-card p-3">
                <div className="font-mono text-lg font-bold">{total.copies}</div>
                <div className="text-[11px] text-muted-foreground">{t("totalCards")}</div>
              </div>
              <div className="rounded-2xl border border-border bg-card p-3">
                <div className="font-mono text-lg font-bold">{total.unique}</div>
                <div className="text-[11px] text-muted-foreground">{t("uniqueCards")}</div>
              </div>
              <div className="rounded-2xl border border-primary/40 bg-primary/10 p-3">
                <div className="font-mono text-lg font-bold text-primary-foreground">
                  {money(total.current, cur)}
                </div>
                <div className="text-[11px] text-muted-foreground">{t("totalValue")}</div>
              </div>
            </div>

            {/* Composition: rarity breakdown + most prominent color */}
            <div className="mt-4 rounded-2xl border border-border bg-card p-4">
              <div className="mb-3 text-sm font-semibold">{t("composition")}</div>

              <div className="mb-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                {t("rarityBreakdown")}
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(Object.keys(RARITY_META) as RarityKey[]).map((r) => (
                  <div key={r} className="flex flex-col items-center gap-1 rounded-xl bg-muted/50 py-2">
                    <span className="size-3 rounded-full" style={{ backgroundColor: RARITY_META[r].hex }} />
                    <span className="font-mono text-base font-bold leading-none">{comp.rarity[r]}</span>
                    <span className="text-[10px] text-muted-foreground">{t(RARITY_META[r].key)}</span>
                  </div>
                ))}
              </div>

              <div className="mb-2 mt-4 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                {t("dominantColor")}
              </div>
              {comp.dominantColor ? (
                <div className="flex items-center gap-3">
                  <span
                    className="grid size-9 shrink-0 place-items-center rounded-full font-mono text-sm font-bold"
                    style={{
                      backgroundColor: COLOR_META[comp.dominantColor].hex,
                      color: COLOR_META[comp.dominantColor].text,
                    }}
                    aria-hidden
                  >
                    {comp.dominantColor}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold">{t(COLOR_META[comp.dominantColor].key)}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {comp.colors[comp.dominantColor]} {t("cards")}
                    </div>
                  </div>
                  {/* Mini distribution bar across all colors */}
                  <div className="flex h-2.5 w-28 overflow-hidden rounded-full bg-muted">
                    {(Object.keys(COLOR_META) as ColorKey[]).map((c) =>
                      comp.colors[c] > 0 ? (
                        <span
                          key={c}
                          style={{ backgroundColor: COLOR_META[c].hex, flexGrow: comp.colors[c] }}
                          title={`${t(COLOR_META[c].key)}: ${comp.colors[c]}`}
                        />
                      ) : null,
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">—</div>
              )}
            </div>

            {/* Collection trend */}
            <div className="mt-4 rounded-2xl border border-border bg-card p-4">
              <div className="mb-2 text-sm font-semibold">{t("collectionTrend")}</div>
              <PriceChart history={series} currency={cur} />
              <div className="mt-2 text-[11px] text-muted-foreground text-pretty">{t("estimatedNote")}</div>
            </div>

            {/* Per-folder breakdown */}
            {breakdown.length > 0 && (
              <div className="mt-4">
                <div className="mb-2 text-sm font-semibold">{t("byFolder")}</div>
                <div className="flex flex-col gap-2">
                  {breakdown.map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3"
                    >
                      <span className="size-3 shrink-0 rounded-full" style={{ backgroundColor: r.color }} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-semibold">{r.name}</div>
                        <div className="text-[11px] text-muted-foreground">
                          {r.copies} {t("cards")} · {money(r.invested, cur)} → {money(r.current, cur)}
                        </div>
                      </div>
                      <span
                        className="shrink-0 font-mono text-sm font-bold"
                        style={{
                          color:
                            r.winPct == null
                              ? undefined
                              : r.winPct >= 0
                                ? "oklch(0.62 0.15 150)"
                                : "oklch(0.6 0.2 20)",
                        }}
                      >
                        {signedPct(r.winPct)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function HeroStat({
  label,
  value,
  big,
  color,
}: {
  label: string
  value: string
  big?: boolean
  color?: "up" | "down"
}) {
  const c = color === "up" ? "oklch(0.62 0.15 150)" : color === "down" ? "oklch(0.6 0.2 20)" : undefined
  return (
    <div className="min-w-0">
      <div className="text-[11px] font-medium text-muted-foreground">{label}</div>
      <div
        className={`font-mono font-bold leading-tight ${big ? "text-2xl" : "text-lg"}`}
        style={{ color: c }}
      >
        {value}
      </div>
    </div>
  )
}
