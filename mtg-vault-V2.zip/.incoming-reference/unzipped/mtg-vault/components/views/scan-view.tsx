"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { Check, Loader2, Pencil, Search, X } from "lucide-react"
import { BetaBadge } from "@/components/beta-badge"
import type { CardData } from "@/lib/types"
import { useCollection } from "@/lib/collection-context"
import { money } from "@/lib/format"
import { beep, primeAudio } from "@/lib/sound"
import { AddView } from "@/components/views/add-view"
import { cropFromGuide, sliceBand } from "@/lib/scan/crop-guide"
import { readTitle } from "@/lib/scan/ocr"
import { loadCatalog, bestNameFromTexts } from "@/lib/scan/match-name"
import { namedExact, namedFuzzy, getById, getPrints } from "@/lib/scryfall"
import { looksLikeCard, extractArtBox } from "@/lib/scan/hash"
import { calculateEnhancedPHash, calculateHammingDistance } from "@/lib/scan/phash"
import { hashDB, initializeHashDatabase, type HashEntry } from "@/lib/scan/hash-db"

const DEDUPE_MS = 5000
const OCR_LANGS = "eng+ita"
const MIN_CONFIDENCE = 0.82
const HAMMING_THRESHOLD = 10 // Strict threshold for pHash matching

export function ScanView({
  onDone,
  lockedFolderId,
}: {
  onDone: () => void
  lockedFolderId?: string
}) {
  const { folders, settings, addEntry, t } = useCollection()
  const videoRef = useRef<HTMLVideoElement>(null)
  const stageRef = useRef<HTMLDivElement>(null)
  const guideRef = useRef<HTMLDivElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const workerRef = useRef<any>(null)
  const loopRef = useRef<number | null>(null)
  const busyRef = useRef(false)
  const lastHitRef = useRef<{ name: string; at: number } | null>(null)
  const candidateRef = useRef<CardData | null>(null)
  const pauseRef = useRef(false)
  const mountedRef = useRef(true)
  // Reprints per oracle id, so the edition refinement does not hit Scryfall on
  // every frame.
  const printsCache = useRef(new Map<string, CardData[]>())

  const [error, setError] = useState<null | "camera" | "insecure" | "denied">(null)
  const [live, setLive] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [manualQuery, setManualQuery] = useState("")
  const [dest, setDest] = useState<string>(lockedFolderId ?? "")
  const [candidate, setCandidate] = useState<CardData | null>(null)
  const [editQuery, setEditQuery] = useState<string | null>(null)
  const [hint, setHint] = useState("")
  const [detectedName, setDetectedName] = useState<string>("")

  const cur = settings.currency
  candidateRef.current = candidate
  pauseRef.current = !!(candidate || editQuery || searchOpen)
  const secure =
    typeof window !== "undefined" &&
    window.isSecureContext &&
    !!navigator.mediaDevices?.getUserMedia

  // State updates coming out of the async pipeline must be dropped once the
  // view is gone, otherwise React warns and the loop keeps the worker alive.
  const show = useCallback(<T,>(setter: (v: T) => void, value: T) => {
    if (mountedRef.current) setter(value)
  }, [])

  const stopLoop = () => {
    if (loopRef.current) {
      clearTimeout(loopRef.current)
      loopRef.current = null
    }
  }

  const stopCamera = useCallback(() => {
    stopLoop()
    streamRef.current?.getTracks().forEach((tr) => tr.stop())
    streamRef.current = null
    if (videoRef.current) videoRef.current.srcObject = null
    setLive(false)
  }, [])

  useEffect(() => {
    mountedRef.current = true
    document.documentElement.classList.add("scan-lock")
    void initializeHashDatabase().catch(() => undefined)
    return () => {
      mountedRef.current = false
      document.documentElement.classList.remove("scan-lock")
      stopCamera()
      workerRef.current?.terminate?.()
      workerRef.current = null
    }
  }, [stopCamera])

  const ensureWorker = useCallback(async () => {
    if (workerRef.current) return workerRef.current
    const { createWorker } = await import("tesseract.js")
    const worker = await createWorker(OCR_LANGS)
    workerRef.current = worker
    return worker
  }, [])

  const grabCard = useCallback((): HTMLCanvasElement | null => {
    const video = videoRef.current
    const stage = stageRef.current
    const guide = guideRef.current
    if (!video || !stage || !guide || video.videoWidth === 0) return null
    return cropFromGuide(video, stage, guide)
  }, [])

  // Visual (pHash) refinement of the edition. Never throws: a failure here only
  // means we keep the OCR match.
  const refineEdition = useCallback(
    async (frame: HTMLCanvasElement, match: CardData): Promise<CardData> => {
      try {
        const phash = calculateEnhancedPHash(extractArtBox(frame)).hash
        let prints = printsCache.current.get(match.oracleId)
        if (!prints) {
          prints = await getPrints(match, settings.lang)
          printsCache.current.set(match.oracleId, prints)
        }
        let best = match
        let bestDistance = HAMMING_THRESHOLD + 1
        for (const print of prints) {
          const known = await hashDB.getEntry(print.id).catch(() => null)
          if (!known) continue
          const distance = calculateHammingDistance(phash, known.phash)
          if (distance < bestDistance) {
            bestDistance = distance
            best = print
          }
        }
        await hashDB
          .addEntry({
            scryfallId: best.id,
            phash,
            set: best.set,
            name: best.name,
            collectorNumber: best.collectorNumber,
            lastUpdated: Date.now(),
          })
          .catch(() => undefined)
        return best
      } catch {
        return match
      }
    },
    [settings.lang],
  )

  const identifyCanvas = useCallback(
    async (frame: HTMLCanvasElement): Promise<CardData | null> => {
      if (!looksLikeCard(frame)) {
        show(setHint, "")
        show(setDetectedName, "")
        return null
      }

      // OCR of the title band is the primary signal.
      let ocrText = ""
      try {
        const worker = await ensureWorker()
        const title = await readTitle(worker, sliceBand(frame, 0.035, 0.135, 0.07))
        ocrText = title.text || ""
      } catch {
        // OCR engine hiccup: fall through to the visual matcher.
      }
      show(setDetectedName, ocrText)
      show(setHint, ocrText)

      if (ocrText.length >= 3) {
        const fuzzy = await namedFuzzy(ocrText, settings.lang).catch(() => null)
        if (fuzzy) {
          show(setHint, `${fuzzy.name} (${fuzzy.set})`)
          return refineEdition(frame, fuzzy)
        }
      }

      // Fallback: purely visual match against the local hash database.
      try {
        const phash = calculateEnhancedPHash(extractArtBox(frame)).hash
        const closest = await hashDB.findClosestMatch(phash, HAMMING_THRESHOLD)
        if (closest) {
          show(setHint, `${closest.name} (${closest.set})`)
          const card = await getById(closest.scryfallId, settings.lang).catch(() => null)
          if (card) return card
        }
      } catch {
        // Visual matching unavailable: fall through to the catalog matcher.
      }

      // Last resort: offline catalog name matching.
      if (ocrText.length >= 3) {
        const local = await bestNameFromTexts([ocrText], settings.lang).catch(() => null)
        if (local && local.score >= MIN_CONFIDENCE) {
          return namedExact(local.name, settings.lang).catch(() => null)
        }
      }

      return null
    },
    [ensureWorker, refineEdition, settings.lang],
  )

  const identifyLive = useCallback(async () => {
    const frame = grabCard()
    if (!frame) return null
    return identifyCanvas(frame)
  }, [grabCard, identifyCanvas])

  const accept = useCallback(
    (card: CardData) => {
      const now = Date.now()
      const last = lastHitRef.current
      if (last && last.name === card.name && now - last.at < DEDUPE_MS) return
      lastHitRef.current = { name: card.name, at: now }
      beep()
      show(setCandidate, card)
      show(setDetectedName, card.printedName || card.name)
      show(setError, null)
    },
    [show],
  )

  const tick = useCallback(async () => {
    if (!mountedRef.current) return
    if (busyRef.current || pauseRef.current || document.hidden) {
      loopRef.current = window.setTimeout(tick, 400)
      return
    }
    busyRef.current = true
    show(setAnalyzing, true)
    try {
      const card = await identifyLive()
      if (card) accept(card)
    } catch {
      // A failed frame is never fatal: keep looping.
    } finally {
      show(setAnalyzing, false)
      busyRef.current = false
      if (mountedRef.current) loopRef.current = window.setTimeout(tick, 850)
    }
  }, [identifyLive, accept, show])

  const startCamera = useCallback(async () => {
    setError(null)
    if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) {
      setError("insecure")
      return
    }
    primeAudio()
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setLive(true)
      void loadCatalog()
      void ensureWorker()
      loopRef.current = window.setTimeout(tick, 650)
    } catch (err: any) {
      const name = err?.name || ""
      setError(name === "NotAllowedError" || name === "SecurityError" ? "denied" : "camera")
    }
  }, [ensureWorker, tick])

  useEffect(() => {
    if (secure) void startCamera()
    else setError("insecure")
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const quickAdd = async (card: CardData) => {
    await addEntry(card, {
      folderId: dest || null,
      quantity: 1,
      foil: false,
      condition: "NM",
      language: settings.lang === "it" ? "it" : "en",
    })
    setCandidate(null)
    setDetectedName("") // Reset detected name after adding
  }

  const openEditor = (card: CardData) => {
    setCandidate(null)
    setDetectedName("") // Reset detected name when opening editor
    stopCamera()
    setEditQuery(card.printedName || card.name)
  }

  if (editQuery) {
    return (
      <div className="fixed inset-0 z-40 overflow-y-auto bg-background pb-[calc(5.5rem+env(safe-area-inset-bottom))]">
        <div className="px-4 pt-[calc(0.75rem+env(safe-area-inset-top))]">
          <button
            onClick={() => {
              setEditQuery(null)
              void startCamera()
            }}
            className="mb-2 text-sm font-medium text-muted-foreground"
          >
            ← {t("scan")}
          </button>
        </div>
        <AddView
          key={editQuery}
          initialQuery={editQuery}
          lockedFolderId={dest || lockedFolderId}
          onDone={() => {
            setEditQuery(null)
            void startCamera()
          }}
        />
      </div>
    )
  }

  const status =
    error === "denied"
      ? t("cameraDenied")
      : error === "camera"
        ? t("scanFail")
        : error === "insecure"
          ? t("cameraInsecure")
          : analyzing
            ? t("scanning")
            : t("waitingForCard")

  return (
    <div className="fixed inset-x-0 top-0 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-20 bg-black">
      <div ref={stageRef} className="relative h-full w-full overflow-hidden">
        <video ref={videoRef} playsInline muted autoPlay className="absolute inset-0 h-full w-full object-cover" />

        <div className="pointer-events-none absolute inset-0">
          <div
            ref={guideRef}
            className="absolute left-1/2 top-[9%] w-[76%] max-w-[360px] -translate-x-1/2 rounded-[18px] border-2 border-primary shadow-[0_0_0_9999px_rgba(0,0,0,0.58)]"
            style={{ aspectRatio: "63 / 88" }}
          />
        </div>

        <div className="absolute left-3 right-3 top-[calc(0.6rem+env(safe-area-inset-top))] z-10 flex items-center gap-2">
          {lockedFolderId ? (
            <button
              onClick={() => {
                stopCamera()
                onDone()
              }}
              className="grid size-10 place-items-center rounded-full bg-black/55 text-white"
              aria-label={t("back")}
            >
              <X className="size-5" />
            </button>
          ) : null}
          <select
            value={dest}
            onChange={(e) => setDest(e.target.value)}
            className="max-w-[55%] truncate rounded-full bg-black/55 px-3 py-2 text-xs font-medium text-white outline-none"
          >
            <option value="">{t("noFolder")}</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
          <span className="flex items-center gap-1.5 rounded-full bg-black/55 px-3 py-2 text-xs font-semibold text-white">
            {t("scan")}
            <BetaBadge />
          </span>
          <button
            onClick={() => setSearchOpen((v) => !v)}
            className="ml-auto grid size-12 place-items-center rounded-full bg-black/55 text-white"
            aria-label={t("search")}
          >
            <Search className="size-5" />
          </button>
        </div>

        {searchOpen && (
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const term = manualQuery.trim()
              if (term.length >= 2) {
                stopCamera()
                setSearchOpen(false)
                setEditQuery(term)
              }
            }}
            className="absolute inset-x-3 top-[calc(3.6rem+env(safe-area-inset-top))] z-10 flex gap-2"
          >
            <input
              autoFocus
              value={manualQuery}
              onChange={(e) => setManualQuery(e.target.value)}
              placeholder={t("searchScryfall")}
              className="w-full rounded-full bg-black/70 px-4 py-2.5 text-sm text-white outline-none placeholder:text-white/50"
            />
            <button type="submit" className="rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground">
              {t("search")}
            </button>
          </form>
        )}

        <div className="absolute inset-x-0 bottom-0 z-10 flex flex-col items-center gap-3 px-4 pb-14 pt-8 bg-gradient-to-t from-black/80 to-transparent">
          <p className="min-h-10 max-w-[92%] text-center text-xs leading-snug text-white/90">
            {status}
            {detectedName && live && !candidate ? (
              <span className="mt-1 block truncate font-mono text-[10px] text-primary/80">
                OCR: "{detectedName}"
              </span>
            ) : null}
            {hint && live && !candidate && hint !== detectedName ? (
              <span className="mt-1 block truncate font-mono text-[10px] text-white/45">{hint}</span>
            ) : null}
          </p>
          <div className="flex items-center justify-center">
            <button
              onClick={() => void (live ? identifyLive().then((card) => card && accept(card)) : startCamera())}
              disabled={analyzing}
              className="grid size-[4.25rem] place-items-center rounded-full border-4 border-white bg-white/15 disabled:opacity-60"
              aria-label={t("capture")}
            >
              {analyzing ? <Loader2 className="size-7 animate-spin text-white" /> : <span className="size-14 rounded-full bg-white" />}
            </button>
          </div>
        </div>

        {candidate && (
          <div className="absolute inset-x-0 bottom-0 z-20 rounded-t-3xl border-t border-border bg-card p-4">
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-primary">{t("cardFound")}</div>
            <div className="flex items-center gap-3">
              {candidate.image && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={candidate.image} alt={candidate.name} className="h-16 w-auto rounded-md" />
              )}
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold">{candidate.printedName || candidate.name}</div>
                <div className="truncate text-xs text-muted-foreground">
                  {candidate.setName} · #{candidate.collectorNumber}
                </div>
                <div className="mt-0.5 font-mono text-xs font-bold">{money(candidate.eur, cur)}</div>
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => void quickAdd(candidate)}
                className="flex flex-[2] items-center justify-center gap-1.5 rounded-full bg-primary py-2.5 text-sm font-semibold text-primary-foreground"
              >
                <Check className="size-4" />
                {t("quickAdd")}
              </button>
              <button
                onClick={() => openEditor(candidate)}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-border py-2.5 text-sm font-semibold"
              >
                <Pencil className="size-4" />
                {t("editDetails")}
              </button>
              <button
                onClick={() => {
                  setCandidate(null)
                  setDetectedName("") // Reset detected name when dismissing
                }}
                aria-label={t("ignore")}
                className="grid size-10 shrink-0 place-items-center rounded-full border border-border"
              >
                <X className="size-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
