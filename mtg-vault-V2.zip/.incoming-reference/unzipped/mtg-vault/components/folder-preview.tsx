"use client"

import type { Folder } from "@/lib/types"
import {
  backgroundClass,
  backgroundStyle,
  folderIcon,
  withAlpha,
} from "@/lib/folder-style"

/**
 * Styled folder card. Shared by the folders grid and by the live preview inside
 * the folder editor, so what the user configures is exactly what they get.
 */
export function FolderPreview({
  folder,
  subtitle,
  className = "",
}: {
  folder: Pick<Folder, "name" | "color" | "icon" | "background">
  subtitle?: string
  className?: string
}) {
  const Icon = folderIcon(folder.icon)
  return (
    <div
      className={`relative flex items-center gap-3 overflow-hidden rounded-2xl border border-border bg-card p-4 ${backgroundClass(
        folder.background,
      )} ${className}`}
    >
      <div
        className="pointer-events-none absolute inset-0"
        style={backgroundStyle(folder.background, folder.color)}
        aria-hidden="true"
      />
      <span
        className="relative grid size-12 shrink-0 place-items-center rounded-xl"
        style={{ backgroundColor: withAlpha(folder.color, 0.22), color: folder.color }}
      >
        <Icon className="size-6" />
      </span>
      <div className="relative min-w-0 flex-1">
        <div className="truncate text-base font-semibold">{folder.name}</div>
        {subtitle && <div className="mt-0.5 truncate font-mono text-xs text-muted-foreground">{subtitle}</div>}
      </div>
    </div>
  )
}
