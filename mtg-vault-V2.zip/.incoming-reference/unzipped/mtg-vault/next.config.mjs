/** @type {import('next').NextConfig} */
import os from "node:os"

function lanHosts() {
  const hosts = ["localhost", "127.0.0.1"]
  for (const addrs of Object.values(os.networkInterfaces())) {
    for (const a of addrs || []) {
      const v4 = a.family === "IPv4" || a.family === 4
      if (v4 && !a.internal) hosts.push(a.address)
    }
  }
  return [...new Set(hosts)]
}

const nextConfig = {
      devIndicators: false,
      allowedDevOrigins: lanHosts(),
  images: {
    unoptimized: true,
  },
}

export default nextConfig
