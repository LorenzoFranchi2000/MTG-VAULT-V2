/**
 * Local-network HTTPS for the collection app.
 *
 * Browsers block the camera on http://192.168.x.x (not a "secure context").
 * localhost is fine over HTTP; phones on Wi-Fi need HTTPS with the LAN IP
 * in the certificate SAN. This script mints a cert and starts Next on 0.0.0.0.
 *
 * Phone: open the printed https:// URL, accept the certificate warning once,
 * then the camera works. No public HTTPS / tunnel required.
 */
import { spawn } from "node:child_process"
import fs from "node:fs"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import selfsigned from "selfsigned"

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
const certDir = path.join(root, ".certs")
const keyPath = path.join(certDir, "key.pem")
const certPath = path.join(certDir, "cert.pem")
const port = Number(process.env.PORT || 3000)
const prod = process.argv.includes("--prod")

function lanIPv4() {
  const out = []
  for (const addrs of Object.values(os.networkInterfaces())) {
    for (const a of addrs || []) {
      const v4 = a.family === "IPv4" || a.family === 4
      if (v4 && !a.internal) out.push(a.address)
    }
  }
  return [...new Set(out)]
}

function ensureCert(hosts) {
  fs.mkdirSync(certDir, { recursive: true })
  const stamp = path.join(certDir, "sans.json")
  const prev = fs.existsSync(stamp) ? fs.readFileSync(stamp, "utf8") : ""
  if (fs.existsSync(keyPath) && fs.existsSync(certPath) && prev === JSON.stringify(hosts)) {
    return
  }
  const attrs = [{ name: "commonName", value: hosts[0] || "localhost" }]
  const pems = selfsigned.generate(attrs, {
    keySize: 2048,
    days: 365,
    algorithm: "sha256",
    extensions: [
      { name: "basicConstraints", cA: true },
      {
        name: "subjectAltName",
        altNames: hosts.flatMap((h) =>
          /^\d+\.\d+\.\d+\.\d+$/.test(h)
            ? [{ type: 7, ip: h }]
            : [{ type: 2, value: h }],
        ),
      },
    ],
  })
  fs.writeFileSync(keyPath, pems.private)
  fs.writeFileSync(certPath, pems.cert)
  fs.writeFileSync(stamp, JSON.stringify(hosts))
}

const ips = lanIPv4()
const hosts = ["localhost", "127.0.0.1", ...ips]
ensureCert(hosts)

console.log("\n  Collezione — HTTPS locale (fotocamera ok su telefono)\n")
console.log(`  PC:      https://localhost:${port}`)
for (const ip of ips) console.log(`  Telefono: https://${ip}:${port}`)
console.log("\n  Al primo accesso sul telefono: Avanzate → procedi comunque (certificato locale).\n")

const nextBin = path.join(root, "node_modules", "next", "dist", "bin", "next")
const args = prod
  ? ["start", "--hostname", "0.0.0.0", "--port", String(port)]
  : [
      "dev",
      "--hostname",
      "0.0.0.0",
      "--port",
      String(port),
      "--experimental-https",
      "--experimental-https-key",
      keyPath,
      "--experimental-https-cert",
      certPath,
    ]

if (prod) {
  // `next start` has no --experimental-https. Serve the built app over HTTPS.
  const { createServer } = await import("node:https")
  const { parse } = await import("node:url")
  const next = (await import("next")).default
  const app = next({ dev: false, hostname: "0.0.0.0", port, dir: root })
  const handle = app.getRequestHandler()
  await app.prepare()
  const key = fs.readFileSync(keyPath)
  const cert = fs.readFileSync(certPath)
  createServer({ key, cert }, (req, res) => {
    handle(req, res, parse(req.url || "/", true))
  }).listen(port, "0.0.0.0")
} else {
  const child = spawn(process.execPath, [nextBin, ...args], {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, PORT: String(port), NEXT_PUBLIC_LAN_SYNC: "1" },
  })
  child.on("exit", (code) => process.exit(code ?? 0))
}
