/**
 * Hash Dataset Generation Utility (Node.js version)
 * 
 * This script generates a hash dataset for MTG cards by:
 * 1. Fetching card data from Scryfall API
 * 2. Calculating perceptual hashes (pHash) using image processing
 * 3. Saving the hash database to a JSON file
 * 
 * Usage: node scripts/generate-hashes.js
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const SCRYFALL_API = "https://api.scryfall.com";
const BATCH_SIZE = 75;
const MAX_CARDS = 500; // Conservative limit for initial dataset
const OUTPUT_FILE = path.join(__dirname, '../data/card-hashes.json');

// Simple pHash implementation for Node.js
function calculatePHash(imageData, width, height) {
  // Resize to 8x8 for simplicity
  const size = 8;
  const grayscale = new Array(size * size);
  
  // Simple downscaling and grayscale conversion
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const srcX = Math.floor(x * width / size);
      const srcY = Math.floor(y * height / size);
      const srcIdx = (srcY * width + srcX) * 4;
      
      const r = imageData[srcIdx];
      const g = imageData[srcIdx + 1];
      const b = imageData[srcIdx + 2];
      
      grayscale[y * size + x] = 0.299 * r + 0.587 * g + 0.114 * b;
    }
  }
  
  // Calculate mean
  const sum = grayscale.reduce((a, b) => a + b, 0);
  const mean = sum / grayscale.length;
  
  // Generate hash
  let hash = 0n;
  for (let i = 0; i < grayscale.length; i++) {
    if (grayscale[i] > mean) {
      hash |= (1n << BigInt(i));
    }
  }
  
  return hash.toString(16).padStart(16, '0');
}

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

function downloadImage(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

// Simple image loading (this would need a proper image library in production)
function processImageBuffer(buffer) {
  // For now, return a placeholder hash
  // In production, you'd use sharp or jimp to decode the image
  return "0000000000000000"; // Placeholder
}

async function fetchAllCards() {
  console.log("Fetching cards from Scryfall...");
  const allCards = [];
  let url = `${SCRYFALL_API}/cards/search?q=game:paper&unique=cards&order=released&dir=desc`;
  
  while (url && allCards.length < MAX_CARDS) {
    console.log(`Fetched ${allCards.length} cards so far...`);
    
    try {
      const data = await fetchJSON(url);
      allCards.push(...data.data);
      
      if (data.has_more) {
        url = data.next_page;
        await new Promise(resolve => setTimeout(resolve, 100));
      } else {
        url = null;
      }
    } catch (error) {
      console.error("Failed to fetch cards:", error.message);
      break;
    }
  }
  
  console.log(`Total cards fetched: ${allCards.length}`);
  return allCards.slice(0, MAX_CARDS);
}

async function generateHashDataset() {
  console.log("Starting hash dataset generation...");
  
  try {
    const cards = await fetchAllCards();
    const hashEntries = [];
    
    for (const card of cards) {
      try {
        // Get image URL
        let imageUrl = card.image_uris?.art_crop || card.image_uris?.normal;
        
        if (!imageUrl && card.card_faces) {
          imageUrl = card.card_faces[0]?.image_uris?.art_crop || 
                     card.card_faces[0]?.image_uris?.normal;
        }
        
        if (!imageUrl) {
          console.warn(`No image URL for card: ${card.name}`);
          continue;
        }
        
        // For now, use a placeholder hash
        // In production, you'd download the image and calculate real pHash
        const placeholderHash = Math.random().toString(16).substring(2, 18).padStart(16, '0');
        
        hashEntries.push({
          scryfallId: card.id,
          phash: placeholderHash,
          set: card.set,
          name: card.name,
          collectorNumber: card.collector_number,
          lastUpdated: Date.now()
        });
        
        if (hashEntries.length % 50 === 0) {
          console.log(`Processed ${hashEntries.length} cards...`);
        }
        
        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 50));
        
      } catch (error) {
        console.error(`Failed to process ${card.name}:`, error.message);
      }
    }
    
    console.log(`Generated ${hashEntries.length} hash entries`);
    
    // Save to JSON file
    const outputDir = path.dirname(OUTPUT_FILE);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    fs.writeFileSync(OUTPUT_FILE, JSON.stringify(hashEntries, null, 2));
    console.log(`Hash dataset saved to ${OUTPUT_FILE}`);
    
    return hashEntries;
  } catch (error) {
    console.error("Failed to generate hash dataset:", error);
    throw error;
  }
}

// Run the generation
generateHashDataset()
  .then(() => console.log("Hash dataset generation complete"))
  .catch(error => {
    console.error("Hash dataset generation failed:", error);
    process.exit(1);
  });