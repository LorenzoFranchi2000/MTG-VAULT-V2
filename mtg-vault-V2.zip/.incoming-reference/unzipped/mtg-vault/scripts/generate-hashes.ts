/**
 * Hash Dataset Generation Utility
 * 
 * This script generates a hash dataset for MTG cards by:
 * 1. Fetching card data from Scryfall API
 * 2. Downloading card art images
 * 3. Calculating perceptual hashes (pHash)
 * 4. Saving the hash database to a JSON file
 * 
 * Usage: node scripts/generate-hashes.ts
 */

import { calculateEnhancedPHash } from "../lib/scan/phash"
import { hashDB, type HashEntry } from "../lib/scan/hash-db"
import { searchCards } from "../lib/scryfall"

const SCRYFALL_API = "https://api.scryfall.com"
const BATCH_SIZE = 75 // Scryfall rate limit
const MAX_CARDS = 1000 // Limit for initial dataset

interface ScryfallCard {
  id: string
  name: string
  set: string
  collector_number: string
  image_uris?: {
    art_crop?: string
    normal?: string
    large?: string
  }
  card_faces?: Array<{
    image_uris?: {
      art_crop?: string
      normal?: string
      large?: string
    }
  }>
}

async function fetchAllCards(): Promise<ScryfallCard[]> {
  console.log("Fetching cards from Scryfall...")
  const allCards: ScryfallCard[] = []
  let url: string | null = `${SCRYFALL_API}/cards/search?q=game:paper&unique=cards&order=released&dir=desc`
  
  while (url && allCards.length < MAX_CARDS) {
    console.log(`Fetched ${allCards.length} cards so far...`)
    const response: Response = await fetch(url)
    if (!response.ok) {
      console.error("Failed to fetch cards:", response.statusText)
      break
    }
    
    const data = (await response.json()) as {
      data: ScryfallCard[]
      has_more?: boolean
      next_page?: string
    }
    allCards.push(...data.data)
    
    if (data.has_more) {
      url = data.next_page ?? null
      // Rate limiting: wait 100ms between requests
      await new Promise(resolve => setTimeout(resolve, 100))
    } else {
      url = null
    }
  }
  
  console.log(`Total cards fetched: ${allCards.length}`)
  return allCards.slice(0, MAX_CARDS)
}

async function downloadImage(url: string): Promise<Blob> {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error(`Failed to download image: ${response.statusText}`)
  }
  return response.blob()
}

async function blobToCanvas(blob: Blob): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const canvas = document.createElement("canvas")
      canvas.width = img.naturalWidth
      canvas.height = img.naturalHeight
      const ctx = canvas.getContext("2d")!
      ctx.drawImage(img, 0, 0)
      resolve(canvas)
    }
    img.onerror = () => reject(new Error("Failed to load image"))
    img.src = URL.createObjectURL(blob)
  })
}

async function generateHashEntry(card: ScryfallCard): Promise<HashEntry | null> {
  try {
    // Get image URL (prefer art_crop for hash generation)
    let imageUrl = card.image_uris?.art_crop || card.image_uris?.normal || card.image_uris?.large
    
    // Handle double-faced cards
    if (!imageUrl && card.card_faces) {
      imageUrl = card.card_faces[0]?.image_uris?.art_crop || 
                 card.card_faces[0]?.image_uris?.normal ||
                 card.card_faces[0]?.image_uris?.large
    }
    
    if (!imageUrl) {
      console.warn(`No image URL for card: ${card.name}`)
      return null
    }
    
    // Download and process image
    const blob = await downloadImage(imageUrl)
    const canvas = await blobToCanvas(blob)
    
    // Calculate pHash
    const phashResult = calculateEnhancedPHash(canvas)
    
    return {
      scryfallId: card.id,
      phash: phashResult.hash,
      set: card.set,
      name: card.name,
      collectorNumber: card.collector_number,
      lastUpdated: Date.now()
    }
  } catch (error) {
    console.error(`Failed to generate hash for ${card.name}:`, error)
    return null
  }
}

async function generateHashDataset() {
  console.log("Starting hash dataset generation...")
  
  try {
    // Initialize hash database
    await hashDB.init()
    await hashDB.clear()
    
    // Fetch cards from Scryfall
    const cards = await fetchAllCards()
    
    // Process cards in batches
    const hashEntries: HashEntry[] = []
    for (let i = 0; i < cards.length; i += BATCH_SIZE) {
      const batch = cards.slice(i, i + BATCH_SIZE)
      console.log(`Processing batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(cards.length / BATCH_SIZE)}...`)
      
      const batchPromises = batch.map(card => generateHashEntry(card))
      const batchResults = await Promise.all(batchPromises)
      
      for (const result of batchResults) {
        if (result) {
          hashEntries.push(result)
        }
      }
      
      // Add batch to database
      await hashDB.addEntries(hashEntries.slice(-batchResults.filter(r => r !== null).length))
      
      // Rate limiting
      await new Promise(resolve => setTimeout(resolve, 200))
    }
    
    console.log(`Generated ${hashEntries.length} hash entries`)
    
    // Export to JSON for backup
    const jsonExport = await hashDB.exportToJSON()
    console.log("Hash database exported to JSON")
    
    return hashEntries
  } catch (error) {
    console.error("Failed to generate hash dataset:", error)
    throw error
  }
}

// Run the generation if this is executed directly
if (typeof window === 'undefined') {
  generateHashDataset()
    .then(() => console.log("Hash dataset generation complete"))
    .catch(error => console.error("Hash dataset generation failed:", error))
}

export { generateHashDataset }