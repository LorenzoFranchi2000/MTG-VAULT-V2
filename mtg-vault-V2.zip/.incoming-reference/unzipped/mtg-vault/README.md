# MTG Vault

MTG collection manager: scan cards (OCR + offline image matching), track
prices, organize into folders. Runs entirely client-side (IndexedDB) with an
optional self-hosted sync layer for your own devices.

## Two ways to run this

### 1. Personal use, multiple devices, one shared collection (LAN sync)

This is `scripts/lan.mjs`: it mints a local HTTPS certificate (so the phone's
camera works over Wi-Fi — browsers refuse camera access on plain `http://`
except on `localhost`) and starts the app with a `/api/store` endpoint that
keeps every device on your network reading/writing the same collection file.

```bash
pnpm install
pnpm run lan          # dev mode, live-reload
# or, for a faster/prebuilt run:
pnpm run build:lan && pnpm run start:lan
```

Open the printed `https://<your-lan-ip>:3000` on your phone, accept the
certificate warning once (it's self-signed, generated locally — no public CA
or internet needed), and you're in.

**Important:** `build:lan` sets `NEXT_PUBLIC_LAN_SYNC=1` *at build time*
(Next.js inlines `NEXT_PUBLIC_*` vars into the client bundle when it's built,
not read at server-start time) — so if you ever rebuild, use `build:lan`
again, not plain `build`, or sync will silently stop working client-side even
though the server-side route still runs.

### 2. Distributing to other people (public deploy, no shared data)

`/api/store` has **no authentication and no per-user separation** — it's one
JSON file, shared by whoever hits it. Deploying the LAN-sync build somewhere
public would mean every friend who installs the app reads and overwrites the
*same* collection: everyone's cards merged into one file, and anyone's save
can clobber anyone else's.

So the public build ships with sync **off by default** (`NEXT_PUBLIC_LAN_SYNC`
unset) — every install is fully isolated, using only its own browser's
IndexedDB. Nothing is shared, nothing is exposed beyond a stateless,
allowlisted Scryfall image proxy (`/api/scan/image`, read-only, no user data).

To share it:

1. Push this repo to GitHub (your own account/repo — hosting and code are
   separate; nothing here ties you to any specific host).
2. Import it on [netlify.com](https://netlify.com) (free, no credit card,
   doesn't sleep/cold-start the way some other free tiers do): "Add new site"
   → "Import an existing project" → pick the GitHub repo. Netlify detects
   Next.js automatically; no config needed, and leave `NEXT_PUBLIC_LAN_SYNC`
   unset.
   - Alternative: **Cloudflare Pages** if you want literally unlimited free
     bandwidth — Next.js support there has historically needed an adapter
     (`@cloudflare/next-on-pages` or the newer OpenNext adapter) and has a
     few compatibility rough edges, but this app's server side is light (just
     the stateless image proxy) so it should work fine.
   - Skipping: Render's free tier sleeps after 15 min idle (30-60s to wake up
     on the next request — the opposite of "always reachable instantly");
     Railway/Fly.io's free tiers are a small monthly credit, not free-forever,
     and a 24/7 service burns through it in days.
3. Send friends (or just yourself, from outside your home network) the
   `https://your-site.netlify.app` URL. On iPhone: Safari → Share → "Add to
   Home Screen". On Android: Chrome offers to install it, or Menu → "Add to
   Home screen". Real HTTPS from Netlify means the camera works immediately —
   no certificate warning to click through, and it's reachable from anywhere
   with internet, not just your home Wi-Fi.

Each install gets its own private, local collection. If you and a friend
later want to actually share a collection, that needs real per-user auth on
`/api/store` (not just the flag) — a bigger change, worth doing separately if
you actually need it.
