/** IndexedDB-based hash database for MTG card art matching.
 * Stores lightweight hash entries for fast local card recognition.
 */

export interface HashEntry {
  scryfallId: string
  phash: string
  set: string
  name: string
  collectorNumber: string
  lastUpdated: number
}

const DB_NAME = "mtg-card-hashes"
const DB_VERSION = 1
const STORE_NAME = "hashes"

class HashDatabase {
  private db: IDBDatabase | null = null

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION)

      request.onerror = () => reject(request.error)
      request.onsuccess = () => {
        this.db = request.result
        resolve()
      }

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: "scryfallId" })
          store.createIndex("phash", "phash", { unique: false })
          store.createIndex("set", "set", { unique: false })
        }
      }
    })
  }

  async addEntry(entry: HashEntry): Promise<void> {
    if (!this.db) await this.init()
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readwrite")
      const store = transaction.objectStore(STORE_NAME)
      const request = store.put(entry)
      
      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  async addEntries(entries: HashEntry[]): Promise<void> {
    if (!this.db) await this.init()
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readwrite")
      const store = transaction.objectStore(STORE_NAME)
      
      let completed = 0
      const total = entries.length
      
      entries.forEach(entry => {
        const request = store.put(entry)
        request.onsuccess = () => {
          completed++
          if (completed === total) resolve()
        }
        request.onerror = () => reject(request.error)
      })
    })
  }

  async getEntry(scryfallId: string): Promise<HashEntry | null> {
    if (!this.db) await this.init()
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readonly")
      const store = transaction.objectStore(STORE_NAME)
      const request = store.get(scryfallId)
      
      request.onsuccess = () => resolve(request.result || null)
      request.onerror = () => reject(request.error)
    })
  }

  async getAllEntries(): Promise<HashEntry[]> {
    if (!this.db) await this.init()
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readonly")
      const store = transaction.objectStore(STORE_NAME)
      const request = store.getAll()
      
      request.onsuccess = () => resolve(request.result || [])
      request.onerror = () => reject(request.error)
    })
  }

  async clear(): Promise<void> {
    if (!this.db) await this.init()
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readwrite")
      const store = transaction.objectStore(STORE_NAME)
      const request = store.clear()
      
      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  async getApproximateSize(): Promise<number> {
    const entries = await this.getAllEntries()
    return entries.length
  }

  async findClosestMatch(targetHash: string, maxDistance: number = 10): Promise<HashEntry | null> {
    const entries = await this.getAllEntries()
    let bestMatch: HashEntry | null = null
    let bestDistance = Infinity

    for (const entry of entries) {
      const distance = this.calculateHammingDistance(targetHash, entry.phash)
      if (distance < bestDistance && distance <= maxDistance) {
        bestDistance = distance
        bestMatch = entry
      }
    }

    return bestMatch
  }

  private calculateHammingDistance(hash1: string, hash2: string): number {
    const n1 = BigInt('0x' + hash1.padStart(16, '0'))
    const n2 = BigInt('0x' + hash2.padStart(16, '0'))
    const xor = n1 ^ n2
    
    let distance = 0
    let x = xor
    while (x > 0n) {
      distance += Number(x & 1n)
      x >>= 1n
    }
    
    return distance
  }

  async exportToJSON(): Promise<string> {
    const entries = await this.getAllEntries()
    return JSON.stringify(entries, null, 2)
  }

  async importFromJSON(jsonString: string): Promise<void> {
    const entries = JSON.parse(jsonString) as HashEntry[]
    await this.clear()
    await this.addEntries(entries)
  }
}

// Singleton instance
export const hashDB = new HashDatabase()

/**
 * Initialize the hash database with a fallback dataset.
 * This can be called during app initialization to ensure basic functionality.
 */
export async function initializeHashDatabase(): Promise<void> {
  try {
    await hashDB.init()
    const size = await hashDB.getApproximateSize()
    
    if (size === 0) {
      console.log("Hash database is empty. Loading sample dataset...")
      try {
        // Try to load sample hashes from the public folder
        const response = await fetch('/sample-hashes.json')
        if (response.ok) {
          const sampleData = await response.json()
          await hashDB.addEntries(sampleData)
          console.log(`Loaded ${sampleData.length} sample hash entries`)
        } else {
          console.log("No sample dataset available. Database will be populated as cards are scanned.")
        }
      } catch (error) {
        console.log("Could not load sample dataset. Database will be populated as cards are scanned.")
      }
    }
  } catch (error) {
    console.error("Failed to initialize hash database:", error)
  }
}