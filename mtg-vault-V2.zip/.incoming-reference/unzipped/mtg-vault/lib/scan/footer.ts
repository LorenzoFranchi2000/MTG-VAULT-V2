/** Parse set code + collector number + language from the card footer OCR. */

const LANGS = new Set([
  "EN",
  "ENG",
  "IT",
  "ITA",
  "DE",
  "DEU",
  "GER",
  "FR",
  "FRA",
  "ES",
  "ESP",
  "SPA",
  "PT",
  "POR",
  "JA",
  "JP",
  "JPN",
  "KO",
  "KOR",
  "RU",
  "RUS",
  "PH",
  "ZHS",
  "CS",
])
const SKIP = new Set(["THE", "AND", "FOR", "NOT", "TM", "WOTC", "NFC"])

export interface FooterIds {
  set?: string
  cn?: string
  lang?: string
}

export function parseFooter(text: string): FooterIds {
  const raw = (text || "").toUpperCase().replace(/[^A-Z0-9\/\s]/g, " ")
  const tokens = raw.split(/[\s\/]+/).filter(Boolean)
  const out: FooterIds = {}
  for (const t of tokens) {
    if (LANGS.has(t) && !out.lang) out.lang = t.toLowerCase()
  }
  // Collector number: digits, optional trailing letter (102, 102a, 7).
  for (const t of tokens) {
    if (/^\d{1,4}[A-Z]?$/.test(t) && Number(t) > 0) {
      out.cn = t.toLowerCase()
      break
    }
  }
  // Set code: 3–5 letters, not a language tag.
  for (const t of tokens) {
    if (LANGS.has(t) || SKIP.has(t)) continue
    if (/^[A-Z0-9]{3,5}$/.test(t) && /[A-Z]/.test(t) && !/^\d+$/.test(t)) {
      out.set = t.toLowerCase()
      break
    }
  }
  return out
}
