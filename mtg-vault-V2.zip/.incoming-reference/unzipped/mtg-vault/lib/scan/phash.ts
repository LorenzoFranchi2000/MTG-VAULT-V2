/** Perceptual Hash (pHash) calculation for MTG card art matching.
 * Uses a simplified DCT-like approach optimized for browser performance.
 */

export interface PHashResult {
  hash: string // 64-bit hex string
  confidence: number
}

/**
 * Calculate perceptual hash from canvas using simplified DCT approach.
 * Returns a 64-bit hash as hex string.
 */
export function calculatePHash(source: HTMLCanvasElement): PHashResult {
  const size = 8 // 8x8 grid = 64 bits
  const canvas = document.createElement("canvas")
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, size, size)
  
  const imageData = ctx.getImageData(0, 0, size, size)
  const data = imageData.data
  
  // Convert to grayscale and calculate average
  const grayscale = new Float32Array(size * size)
  let sum = 0
  for (let i = 0; i < size * size; i++) {
    const r = data[i * 4]
    const g = data[i * 4 + 1]
    const b = data[i * 4 + 2]
    const gray = 0.299 * r + 0.587 * g + 0.114 * b
    grayscale[i] = gray
    sum += gray
  }
  const mean = sum / (size * size)
  
  // Generate hash bits based on comparison to mean
  let hash = 0n
  for (let i = 0; i < size * size; i++) {
    if (grayscale[i] > mean) {
      hash |= (1n << BigInt(i))
    }
  }
  
  return {
    hash: hash.toString(16).padStart(16, '0'),
    confidence: 1.0
  }
}

/**
 * Calculate Hamming distance between two 64-bit hashes (hex strings).
 * Returns the number of differing bits.
 */
export function calculateHammingDistance(hash1: string, hash2: string): number {
  const n1 = BigInt('0x' + hash1.padStart(16, '0'))
  const n2 = BigInt('0x' + hash2.padStart(16, '0'))
  const xor = n1 ^ n2
  
  let distance = 0
  let x = xor
  while (x > 0n) {
    distance += Number(x & 1n)
    x >>= 1n
  }
  
  return distance
}

/**
 * Enhanced pHash using discrete cosine transform approximation.
 * More robust for image matching than simple mean comparison.
 */
export function calculateEnhancedPHash(source: HTMLCanvasElement): PHashResult {
  const size = 32 // Use larger size for better accuracy
  const canvas = document.createElement("canvas")
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, size, size)
  
  const imageData = ctx.getImageData(0, 0, size, size)
  const data = imageData.data
  
  // Convert to grayscale
  const grayscale = new Float32Array(size * size)
  for (let i = 0; i < size * size; i++) {
    const r = data[i * 4]
    const g = data[i * 4 + 1]
    const b = data[i * 4 + 2]
    grayscale[i] = 0.299 * r + 0.587 * g + 0.114 * b
  }
  
  // Apply simplified DCT (focus on low-frequency components)
  const dct = simpleDCT(grayscale, size)
  
  // Extract 8x8 low-frequency components
  const lowFreq = new Float32Array(64)
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      lowFreq[y * 8 + x] = dct[y * size + x]
    }
  }
  
  // Calculate median of low-frequency components
  const sorted = [...lowFreq].sort((a, b) => a - b)
  const median = sorted[32]
  
  // Generate hash bits
  let hash = 0n
  for (let i = 0; i < 64; i++) {
    if (lowFreq[i] > median) {
      hash |= (1n << BigInt(i))
    }
  }
  
  return {
    hash: hash.toString(16).padStart(16, '0'),
    confidence: 1.0
  }
}

/**
 * Simplified 2D DCT implementation.
 */
function simpleDCT(input: Float32Array, size: number): Float32Array {
  const output = new Float32Array(size * size)
  
  for (let u = 0; u < size; u++) {
    for (let v = 0; v < size; v++) {
      let sum = 0
      for (let x = 0; x < size; x++) {
        for (let y = 0; y < size; y++) {
          const cosX = Math.cos((Math.PI * u * (2 * x + 1)) / (2 * size))
          const cosY = Math.cos((Math.PI * v * (2 * y + 1)) / (2 * size))
          sum += input[y * size + x] * cosX * cosY
        }
      }
      const alphaU = u === 0 ? 1 / Math.sqrt(2) : 1
      const alphaV = v === 0 ? 1 / Math.sqrt(2) : 1
      output[v * size + u] = (2 / size) * alphaU * alphaV * sum
    }
  }
  
  return output
}