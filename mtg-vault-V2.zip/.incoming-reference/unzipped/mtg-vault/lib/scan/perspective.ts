/** Straighten a (roughly) card-shaped crop to a canonical 63×88 canvas. */

export type Point = { x: number; y: number }

const OUT_W = 488
const OUT_H = 680

function grayAt(data: Uint8ClampedArray, i: number): number {
  return data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
}

function extremeQuad(source: HTMLCanvasElement): Point[] | null {
  const maxW = 220
  const scale = Math.min(1, maxW / source.width)
  const w = Math.max(24, Math.round(source.width * scale))
  const h = Math.max(24, Math.round(source.height * scale))
  const small = document.createElement("canvas")
  small.width = w
  small.height = h
  const ctx = small.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, w, h)
  const img = ctx.getImageData(0, 0, w, h)
  const mag = new Float32Array(w * h)
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = (y * w + x) * 4
      const gx =
        grayAt(img.data, i + 4) - grayAt(img.data, i - 4) +
        0.5 * (grayAt(img.data, ((y - 1) * w + x + 1) * 4) - grayAt(img.data, ((y - 1) * w + x - 1) * 4)) +
        0.5 * (grayAt(img.data, ((y + 1) * w + x + 1) * 4) - grayAt(img.data, ((y + 1) * w + x - 1) * 4))
      const gy =
        grayAt(img.data, ((y + 1) * w + x) * 4) - grayAt(img.data, ((y - 1) * w + x) * 4)
      mag[y * w + x] = Math.abs(gx) + Math.abs(gy)
    }
  }
  const vals = Array.from(mag).sort((a, b) => a - b)
  const thresh = vals[Math.floor(vals.length * 0.82)] || 40
  let minX = w
  let minY = h
  let maxX = 0
  let maxY = 0
  let count = 0
  for (let y = 2; y < h - 2; y++) {
    for (let x = 2; x < w - 2; x++) {
      if (mag[y * w + x] < thresh) continue
      count++
      if (x < minX) minX = x
      if (y < minY) minY = y
      if (x > maxX) maxX = x
      if (y > maxY) maxY = y
    }
  }
  if (count < 40 || maxX - minX < w * 0.35 || maxY - minY < h * 0.35) return null
  const inv = 1 / scale
  const pad = 2 * inv
  return [
    { x: Math.max(0, minX * inv - pad), y: Math.max(0, minY * inv - pad) },
    { x: Math.min(source.width, maxX * inv + pad), y: Math.max(0, minY * inv - pad) },
    { x: Math.max(0, minX * inv - pad), y: Math.min(source.height, maxY * inv + pad) },
    { x: Math.min(source.width, maxX * inv + pad), y: Math.min(source.height, maxY * inv + pad) },
  ]
}

function sample(src: ImageData, x: number, y: number): [number, number, number] {
  const sx = Math.max(0, Math.min(src.width - 1, x))
  const sy = Math.max(0, Math.min(src.height - 1, y))
  const x0 = Math.floor(sx)
  const y0 = Math.floor(sy)
  const x1 = Math.min(src.width - 1, x0 + 1)
  const y1 = Math.min(src.height - 1, y0 + 1)
  const fx = sx - x0
  const fy = sy - y0
  const at = (xx: number, yy: number) => {
    const i = (yy * src.width + xx) * 4
    return [src.data[i], src.data[i + 1], src.data[i + 2]] as const
  }
  const a = at(x0, y0)
  const b = at(x1, y0)
  const c = at(x0, y1)
  const d = at(x1, y1)
  const mix = (k: 0 | 1 | 2) => {
    const top = a[k] * (1 - fx) + b[k] * fx
    const bot = c[k] * (1 - fx) + d[k] * fx
    return top * (1 - fy) + bot * fy
  }
  return [mix(0), mix(1), mix(2)]
}

function warpQuad(source: HTMLCanvasElement, quad: Point[]): HTMLCanvasElement {
  const [tl, tr, bl, br] = quad
  const canvas = document.createElement("canvas")
  canvas.width = OUT_W
  canvas.height = OUT_H
  const ctx = canvas.getContext("2d")!
  const srcCtx = source.getContext("2d", { willReadFrequently: true })!
  const src = srcCtx.getImageData(0, 0, source.width, source.height)
  const out = ctx.createImageData(OUT_W, OUT_H)
  for (let y = 0; y < OUT_H; y++) {
    const v = y / (OUT_H - 1)
    for (let x = 0; x < OUT_W; x++) {
      const u = x / (OUT_W - 1)
      const sx =
        tl.x * (1 - u) * (1 - v) + tr.x * u * (1 - v) + bl.x * (1 - u) * v + br.x * u * v
      const sy =
        tl.y * (1 - u) * (1 - v) + tr.y * u * (1 - v) + bl.y * (1 - u) * v + br.y * u * v
      const [r, g, b] = sample(src, sx, sy)
      const i = (y * OUT_W + x) * 4
      out.data[i] = r
      out.data[i + 1] = g
      out.data[i + 2] = b
      out.data[i + 3] = 255
    }
  }
  ctx.putImageData(out, 0, 0)
  return canvas
}

export function straightenCard(source: HTMLCanvasElement): HTMLCanvasElement {
  const quad = extremeQuad(source)
  if (quad) return warpQuad(source, quad)
  const canvas = document.createElement("canvas")
  canvas.width = OUT_W
  canvas.height = OUT_H
  const ctx = canvas.getContext("2d")!
  ctx.imageSmoothingEnabled = true
  ctx.drawImage(source, 0, 0, OUT_W, OUT_H)
  return canvas
}
