import type { CardData, LangCode } from "@/lib/types"
import { namedExact, namedFuzzy, searchCards } from "@/lib/scryfall"

const STORAGE_KEY = "mtg-card-names-v1"

let catalog: string[] | null = null
const trigrams = new Map<string, number[]>()

function normalize(s: string): string {
  return s
    .toLocaleLowerCase("en")
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0
  if (!a.length) return b.length
  if (!b.length) return a.length
  if (Math.abs(a.length - b.length) > 8) return 99
  const row = new Int16Array(b.length + 1)
  for (let j = 0; j <= b.length; j++) row[j] = j
  for (let i = 1; i <= a.length; i++) {
    let prev = row[0]
    row[0] = i
    for (let j = 1; j <= b.length; j++) {
      const tmp = row[j]
      const cost = a[i - 1] === b[j - 1] ? 0 : 1
      row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + cost)
      prev = tmp
    }
  }
  return row[b.length]
}

function addTrigrams(nameIndex: number, n: string) {
  const compact = n.replace(/ /g, "")
  for (let i = 0; i <= compact.length - 3; i++) {
    const g = compact.slice(i, i + 3)
    const list = trigrams.get(g)
    if (list) list.push(nameIndex)
    else trigrams.set(g, [nameIndex])
  }
}

function buildIndex(names: string[]) {
  trigrams.clear()
  names.forEach((name, i) => addTrigrams(i, normalize(name)))
}

export async function loadCatalog(): Promise<string[]> {
  if (catalog) return catalog
  try {
    const cached = localStorage.getItem(STORAGE_KEY)
    if (cached) {
      const parsed = JSON.parse(cached)
      if (Array.isArray(parsed) && parsed.length > 1000) {
        const names = parsed as string[]
        catalog = names
        buildIndex(names)
        return names
      }
    }
  } catch {
    // ignore
  }
  const res = await fetch("https://api.scryfall.com/catalog/card-names")
  if (!res.ok) {
    const empty: string[] = catalog ?? []
    catalog = empty
    return empty
  }
  const data = await res.json()
  const names: string[] = Array.isArray(data.data) ? data.data : []
  catalog = names
  buildIndex(names)
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(names))
  } catch {
    // ignore quota
  }
  return names
}

export function bestLocalName(raw: string, names: string[]): { name: string; score: number } | null {
  const q = normalize(raw)
  if (q.length < 3) return null
  const compact = q.replace(/ /g, "")
  const votes = new Map<number, number>()
  for (let i = 0; i <= compact.length - 3; i++) {
    const hits = trigrams.get(compact.slice(i, i + 3))
    if (!hits) continue
    for (const idx of hits) votes.set(idx, (votes.get(idx) || 0) + 1)
  }
  const ranked = [...votes.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 60)

  let best: { name: string; score: number } | null = null
  const consider = ranked.length ? ranked.map(([i]) => names[i]) : names.slice(0, 0)
  for (const name of consider) {
    const n = normalize(name)
    const d = levenshtein(q, n)
    const ratio = 1 - d / Math.max(q.length, n.length)
    const contains = n.includes(q) || (q.length >= 5 && q.includes(n))
    let score = ratio
    if (contains && Math.min(q.length, n.length) >= 4) score = Math.max(score, 0.88)
    if (!best || score > best.score) best = { name, score }
  }
  if (!best || best.score < 0.74) return null
  return best
}

export async function bestNameFromTexts(
  inputs: string[],
  _lang: LangCode,
): Promise<{ name: string; score: number } | null> {
  const phrases = [...new Set(inputs.flatMap((t) => phrasesFrom(t)))]
    .filter((p) => !NOISE.has(p.toLocaleLowerCase()))
    .sort((a, b) => b.length - a.length)
  if (!phrases.length) return null
  const names = await loadCatalog()
  let best: { name: string; score: number } | null = null
  for (const p of phrases.slice(0, 24)) {
    const hit = bestLocalName(p, names)
    if (hit && (!best || hit.score > best.score)) best = hit
    if (best && best.score > 0.95) break
  }
  return best
}

const NOISE = new Set([
  "creature",
  "instant",
  "sorcery",
  "enchantment",
  "artifact",
  "legendary",
  "planeswalker",
  "battle",
  "land",
  "basic",
  "token",
  "the",
  "creatura",
  "istantaneo",
  "stregoneria",
  "incantesimo",
  "artefatto",
  "terra",
  "leggendario",
])

function phrasesFrom(text: string): string[] {
  const words = cleanWords(text)
  const out: string[] = []
  for (let i = 0; i < words.length; i++) {
    for (let len = Math.min(5, words.length - i); len >= 1; len--) {
      const p = words.slice(i, i + len).join(" ")
      if (p.replace(/[^a-zA-ZÀ-ÿ]/g, "").length >= 4) out.push(p)
    }
  }
  return out
}

function cleanWords(text: string): string[] {
  return text
    .replace(/[^\p{L}0-9 ,'-]/gu, " ")
    .split(/\s+/)
    .map((w) => w.trim())
    .filter((w) => w.length > 1)
}

export async function resolveScanText(
  raw: string,
  lang: LangCode,
): Promise<{ card: CardData; via: string } | null> {
  return resolveScanTexts([raw], lang)
}

export async function resolveScanTexts(
  inputs: string[],
  lang: LangCode,
): Promise<{ card: CardData; via: string } | null> {
  const phrases = [...new Set(inputs.flatMap((t) => phrasesFrom(t)))]
    .filter((p) => !NOISE.has(p.toLocaleLowerCase()))
    .sort((a, b) => b.length - a.length)
  if (!phrases.length) return null

  const names = await loadCatalog()
  let best: { name: string; score: number } | null = null
  for (const p of phrases.slice(0, 24)) {
    const hit = bestLocalName(p, names)
    if (hit && (!best || hit.score > best.score)) best = hit
    if (best && best.score > 0.95) break
  }
  if (best && best.score >= 0.82) {
    const exact = await namedExact(best.name, lang)
    if (exact) return { card: exact, via: best.name }
  }

  const fuzzySrc = phrases[0]
  const fuzzy = await namedFuzzy(fuzzySrc, lang)
  if (fuzzy) {
    const q = normalize(fuzzySrc)
    const hit = normalize(fuzzy.name)
    const printed = normalize(fuzzy.printedName || "")
    const d = Math.min(levenshtein(q, hit), printed ? levenshtein(q, printed) : 99)
    const ok = d <= 5 || hit.includes(q) || q.includes(hit) || (printed && (printed.includes(q) || q.includes(printed)))
    if (ok) return { card: fuzzy, via: fuzzy.name }
  }

  if (best) {
    const exact = await namedExact(best.name, lang)
    if (exact) return { card: exact, via: best.name }
  }

  const results = await searchCards(fuzzySrc, lang)
  if (results[0]) return { card: results[0], via: results[0].name }
  return null
}
