/** Map the on-screen card guide onto the camera bitmap (object-cover). */

export function cropFromGuide(
  video: HTMLVideoElement,
  displayEl: HTMLElement,
  guideEl: HTMLElement,
): HTMLCanvasElement | null {
  const vw = video.videoWidth
  const vh = video.videoHeight
  if (!vw || !vh) return null
  const vr = displayEl.getBoundingClientRect()
  const gr = guideEl.getBoundingClientRect()
  if (vr.width < 8 || vr.height < 8 || gr.width < 8 || gr.height < 8) return null

  const scale = Math.max(vr.width / vw, vr.height / vh)
  const drawnW = vw * scale
  const drawnH = vh * scale
  const originX = vr.left + (vr.width - drawnW) / 2
  const originY = vr.top + (vr.height - drawnH) / 2

  let sx = (gr.left - originX) / scale
  let sy = (gr.top - originY) / scale
  let sw = gr.width / scale
  let sh = gr.height / scale
  if (sx < 0) {
    sw += sx
    sx = 0
  }
  if (sy < 0) {
    sh += sy
    sy = 0
  }
  if (sx + sw > vw) sw = vw - sx
  if (sy + sh > vh) sh = vh - sy
  if (sw < 24 || sh < 24) return null

  const canvas = document.createElement("canvas")
  canvas.width = Math.round(sw)
  canvas.height = Math.round(sh)
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(video, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height)
  flattenGlare(ctx, canvas.width, canvas.height)
  return canvas
}

export function sliceBand(
  card: HTMLCanvasElement,
  top: number,
  bottom: number,
  inset = 0.05,
): HTMLCanvasElement {
  const y = Math.round(card.height * top)
  const h = Math.max(12, Math.round(card.height * (bottom - top)))
  const x = Math.round(card.width * inset)
  const w = Math.round(card.width * (1 - inset * 2))
  const canvas = document.createElement("canvas")
  canvas.width = w
  canvas.height = h
  const ctx = canvas.getContext("2d")!
  ctx.drawImage(card, x, y, w, h, 0, 0, w, h)
  return canvas
}

function flattenGlare(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const img = ctx.getImageData(0, 0, w, h)
  const d = img.data
  for (let i = 0; i < d.length; i += 4) {
    const max = Math.max(d[i], d[i + 1], d[i + 2])
    const min = Math.min(d[i], d[i + 1], d[i + 2])
    if (max > 245 && min > 190) {
      d[i] = 210
      d[i + 1] = 200
      d[i + 2] = 175
    }
  }
  ctx.putImageData(img, 0, 0)
}
