/** Title-strip OCR: adaptive contrast, both polarities, single-line Tesseract. */

export function cleanLine(s: string): string {
  return (s || "")
    .replace(/[^\p{L}0-9 ,'-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim()
}

function adaptiveBinary(source: HTMLCanvasElement, invert: boolean): HTMLCanvasElement {
  const scale = Math.max(2, Math.ceil(90 / Math.max(1, source.height)))
  const canvas = document.createElement("canvas")
  canvas.width = source.width * scale
  canvas.height = source.height * scale
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!
  ctx.imageSmoothingEnabled = true
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height)
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height)
  const { width: w, height: h, data } = img
  const gray = new Float32Array(w * h)
  for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
    gray[p] = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
  }
  const win = Math.max(15, ((Math.min(w, h) / 6) | 1))
  const half = (win / 2) | 0
  const integral = new Float64Array((w + 1) * (h + 1))
  for (let y = 1; y <= h; y++) {
    let row = 0
    for (let x = 1; x <= w; x++) {
      row += gray[(y - 1) * w + (x - 1)]
      integral[y * (w + 1) + x] = integral[(y - 1) * (w + 1) + x] + row
    }
  }
  const areaOf = (x0: number, y0: number, x1: number, y1: number) => {
    return (
      integral[y1 * (w + 1) + x1] -
      integral[y0 * (w + 1) + x1] -
      integral[y1 * (w + 1) + x0] +
      integral[y0 * (w + 1) + x0]
    )
  }
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - half)
    const y1 = Math.min(h, y + half + 1)
    for (let x = 0; x < w; x++) {
      const x0 = Math.max(0, x - half)
      const x1 = Math.min(w, x + half + 1)
      const count = (x1 - x0) * (y1 - y0)
      const mean = areaOf(x0, y0, x1, y1) / count
      const g = gray[y * w + x]
      const dark = g < mean * 0.92
      const on = invert ? !dark : dark
      const v = on ? 0 : 255
      const i = (y * w + x) * 4
      data[i] = v
      data[i + 1] = v
      data[i + 2] = v
      data[i + 3] = 255
    }
  }
  ctx.putImageData(img, 0, 0)
  return canvas
}

export async function readBlock(
  worker: any,
  band: HTMLCanvasElement,
): Promise<{ text: string; confidence: number; lines: string[] }> {
  await worker.setParameters({
    tessedit_pageseg_mode: "6",
    preserve_interword_spaces: "1",
    tessedit_char_whitelist:
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÀÁÂÄÈÉÊËÌÍÎÏÒÓÔÖÙÚÛÜàáâäèéêëìíîïòóôöùúûüÑñÇç'- ",
  })
  const pre = adaptiveBinary(band, false)
  const { data } = await worker.recognize(pre)
  const lines = (data.text || "")
    .split("\n")
    .map((l: string) => cleanLine(l))
    .filter((l: string) => l.replace(/[^a-zA-ZÀ-ÿ]/g, "").length >= 3)
  return {
    text: cleanLine(data.text || ""),
    confidence: Number(data.confidence) || 0,
    lines,
  }
}

export async function readTitle(
  worker: any,
  band: HTMLCanvasElement,
): Promise<{ text: string; confidence: number }> {
  await worker.setParameters({
    tessedit_pageseg_mode: "7",
    preserve_interword_spaces: "1",
    tessedit_char_whitelist:
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÀÁÂÄÈÉÊËÌÍÎÏÒÓÔÖÙÚÛÜàáâäèéêëìíîïòóôöùúûüÑñÇç'- ",
  })
  let best = { text: "", confidence: 0 }
  for (const invert of [false, true]) {
    const pre = adaptiveBinary(band, invert)
    const { data } = await worker.recognize(pre)
    const line = cleanLine(
      (data.text || "")
        .split("\n")
        .map((l: string) => l.trim())
        .sort((a: string, b: string) => b.length - a.length)[0] || "",
    )
    const confidence = Number(data.confidence) || 0
    if (line.length > best.text.length || (line.length === best.text.length && confidence > best.confidence)) {
      best = { text: line, confidence }
    }
  }
  return best
}
