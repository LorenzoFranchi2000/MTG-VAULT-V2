/** Find a Magic card in a camera frame and warp it to a canonical portrait. */

export type Rect = { x: number; y: number; w: number; h: number }

export type Quad = { x: number; y: number }[]

const CARD_RATIO = 63 / 88

export function drawToCanvas(
  source: CanvasImageSource,
  sw: number,
  sh: number,
): HTMLCanvasElement {
  const canvas = document.createElement("canvas")
  canvas.width = sw
  canvas.height = sh
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, sw, sh)
  return canvas
}

function grayAt(data: Uint8ClampedArray, i: number): number {
  return data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
}

function otsu(hist: Int32Array, total: number): number {
  let sum = 0
  for (let i = 0; i < 256; i++) sum += i * hist[i]
  let sumB = 0
  let wB = 0
  let max = 0
  let threshold = 128
  for (let t = 0; t < 256; t++) {
    wB += hist[t]
    if (wB === 0) continue
    const wF = total - wB
    if (wF === 0) break
    sumB += t * hist[t]
    const mB = sumB / wB
    const mF = (sum - sumB) / wF
    const between = wB * wF * (mB - mF) * (mB - mF)
    if (between > max) {
      max = between
      threshold = t
    }
  }
  return threshold
}

function blobBounds(
  binary: Uint8Array,
  w: number,
  h: number,
  wantOn: number,
): Rect | null {
  const seen = new Uint8Array(w * h)
  let best: Rect | null = null
  let bestArea = 0
  const stack = new Int32Array(w * h)
  const minArea = (w * h) * 0.08
  const maxArea = (w * h) * 0.92

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const start = y * w + x
      if (seen[start] || binary[start] !== wantOn) continue
      let top = 0
      stack[top++] = start
      seen[start] = 1
      let minX = x
      let maxX = x
      let minY = y
      let maxY = y
      let area = 0
      while (top > 0) {
        const i = stack[--top]
        area++
        const cx = i % w
        const cy = (i / w) | 0
        if (cx < minX) minX = cx
        if (cx > maxX) maxX = cx
        if (cy < minY) minY = cy
        if (cy > maxY) maxY = cy
        const neighbors = [i - 1, i + 1, i - w, i + w]
        for (const n of neighbors) {
          if (n < 0 || n >= w * h || seen[n] || binary[n] !== wantOn) continue
          const nx = n % w
          const ny = (n / w) | 0
          if (Math.abs(nx - cx) + Math.abs(ny - cy) !== 1) continue
          seen[n] = 1
          stack[top++] = n
        }
      }
      if (area < minArea || area > maxArea) continue
      const bw = maxX - minX + 1
      const bh = maxY - minY + 1
      const ratio = bw / bh
      const portrait = ratio > 0.52 && ratio < 0.92
      const landscape = ratio > 1.08 && ratio < 1.92
      if (!portrait && !landscape) continue
      if (area > bestArea) {
        bestArea = area
        best = { x: minX, y: minY, w: bw, h: bh }
      }
    }
  }
  return best
}

/** Locate the card in `source`. Coordinates are in source pixels. */
export function detectCardRect(
  source: HTMLCanvasElement,
): { rect: Rect; portrait: boolean } | null {
  const maxW = 280
  const scale = Math.min(1, maxW / source.width)
  const w = Math.max(32, Math.round(source.width * scale))
  const h = Math.max(32, Math.round(source.height * scale))
  const small = document.createElement("canvas")
  small.width = w
  small.height = h
  const ctx = small.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, w, h)
  const img = ctx.getImageData(0, 0, w, h)
  const hist = new Int32Array(256)
  const gray = new Uint8Array(w * h)
  for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
    const g = grayAt(img.data, i) | 0
    gray[p] = g
    hist[g]++
  }
  const t = otsu(hist, w * h)
  const binary = new Uint8Array(w * h)
  for (let i = 0; i < gray.length; i++) binary[i] = gray[i] > t ? 1 : 0

  const light = blobBounds(binary, w, h, 1)
  const dark = blobBounds(binary, w, h, 0)
  const pick =
    light && dark
      ? light.w * light.h >= dark.w * dark.h
        ? light
        : dark
      : light || dark
  if (!pick) return null

  const inv = 1 / scale
  const pad = 2 * inv
  const rect: Rect = {
    x: Math.max(0, pick.x * inv - pad),
    y: Math.max(0, pick.y * inv - pad),
    w: Math.min(source.width - pick.x * inv, pick.w * inv + pad * 2),
    h: Math.min(source.height - pick.y * inv, pick.h * inv + pad * 2),
  }
  return { rect, portrait: rect.w / rect.h < 1 }
}

export function cropRect(source: HTMLCanvasElement, rect: Rect): HTMLCanvasElement {
  const canvas = document.createElement("canvas")
  canvas.width = Math.max(1, Math.round(rect.w))
  canvas.height = Math.max(1, Math.round(rect.h))
  const ctx = canvas.getContext("2d")!
  ctx.drawImage(
    source,
    rect.x,
    rect.y,
    rect.w,
    rect.h,
    0,
    0,
    canvas.width,
    canvas.height,
  )
  return canvas
}

/** Force a landscape crop into portrait (phone rotated, or card sideways). */
export function asPortrait(card: HTMLCanvasElement): HTMLCanvasElement {
  if (card.height >= card.width * 0.95) return card
  const canvas = document.createElement("canvas")
  canvas.width = card.height
  canvas.height = card.width
  const ctx = canvas.getContext("2d")!
  ctx.translate(0, canvas.height)
  ctx.rotate(-Math.PI / 2)
  ctx.drawImage(card, 0, 0)
  return canvas
}

export function titleBand(card: HTMLCanvasElement): HTMLCanvasElement {
  // Name box on a standard MTG frame sits roughly 4–13% from the top.
  const y = Math.round(card.height * 0.035)
  const h = Math.max(12, Math.round(card.height * 0.11))
  const x = Math.round(card.width * 0.06)
  const w = Math.round(card.width * 0.88)
  return cropRect(card, { x, y, w, h })
}

export function fallbackCardRect(source: HTMLCanvasElement): Rect {
  // Centered portrait window — used when the table/background fools the blob finder.
  const targetH = source.height * 0.88
  const targetW = targetH * CARD_RATIO
  if (targetW <= source.width * 0.92) {
    return {
      x: (source.width - targetW) / 2,
      y: source.height * 0.06,
      w: targetW,
      h: targetH,
    }
  }
  const w = source.width * 0.86
  const h = w / CARD_RATIO
  return {
    x: source.width * 0.07,
    y: Math.max(0, (source.height - h) / 2),
    w,
    h: Math.min(h, source.height),
  }
}

export function isolateCard(source: HTMLCanvasElement): {
  card: HTMLCanvasElement
  rect: Rect
} {
  const found = detectCardRect(source)
  const rect = found?.rect ?? fallbackCardRect(source)
  return { card: asPortrait(cropRect(source, rect)), rect }
}
