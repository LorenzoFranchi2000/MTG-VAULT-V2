/** Difference hash of a bitmap, used to verify a candidate against Scryfall art. */

/**
 * Extract the Art Box (illustration region) from a Magic card.
 * MTG card art typically occupies the central portion of the card.
 * For standard portrait cards, the art box is roughly 15-75% from top, 10-90% from left.
 */
export function extractArtBox(card: HTMLCanvasElement): HTMLCanvasElement {
  const w = card.width
  const h = card.height
  
  // Determine orientation
  const isPortrait = h > w
  
  if (isPortrait) {
    // Standard MTG card art box dimensions (portrait orientation)
    const artY = Math.round(h * 0.15) // Start at 15% from top
    const artH = Math.round(h * 0.60) // Height is 60% of card
    const artX = Math.round(w * 0.10) // Start at 10% from left
    const artW = Math.round(w * 0.80) // Width is 80% of card
    
    const canvas = document.createElement("canvas")
    canvas.width = artW
    canvas.height = artH
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!
    
    ctx.drawImage(
      card,
      artX, artY, artW, artH, // Source rectangle
      0, 0, artW, artH       // Destination rectangle
    )
    
    return canvas
  } else {
    // Landscape card (transform cards, etc.)
    const artX = Math.round(w * 0.15) // Start at 15% from left
    const artW = Math.round(w * 0.70) // Width is 70% of card
    const artY = Math.round(h * 0.10) // Start at 10% from top
    const artH = Math.round(h * 0.80) // Height is 80% of card
    
    const canvas = document.createElement("canvas")
    canvas.width = artW
    canvas.height = artH
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!
    
    ctx.drawImage(
      card,
      artX, artY, artW, artH, // Source rectangle
      0, 0, artW, artH       // Destination rectangle
    )
    
    return canvas
  }
}

export function dHash(source: HTMLCanvasElement, size = 16): Uint8Array {
  const w = size + 1
  const h = size
  const tmp = document.createElement("canvas")
  tmp.width = w
  tmp.height = h
  const ctx = tmp.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, w, h)
  const { data } = ctx.getImageData(0, 0, w, h)
  const bits = new Uint8Array(size * size)
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * w + x) * 4
      const j = (y * w + x + 1) * 4
      const left = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
      const right = data[j] * 0.299 + data[j + 1] * 0.587 + data[j + 2] * 0.114
      bits[y * size + x] = left > right ? 1 : 0
    }
  }
  return bits
}

export function hashSimilarity(a: Uint8Array, b: Uint8Array): number {
  const n = Math.min(a.length, b.length)
  if (!n) return 0
  let same = 0
  for (let i = 0; i < n; i++) if (a[i] === b[i]) same++
  return same / n
}

export function looksLikeCard(source: HTMLCanvasElement): boolean {
  const w = 48
  const h = 64
  const tmp = document.createElement("canvas")
  tmp.width = w
  tmp.height = h
  const ctx = tmp.getContext("2d", { willReadFrequently: true })!
  ctx.drawImage(source, 0, 0, w, h)
  const { data } = ctx.getImageData(0, 0, w, h)
  let sum = 0
  const gray = new Float32Array(w * h)
  for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
    const g = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114
    gray[p] = g
    sum += g
  }
  const mean = sum / gray.length
  let varSum = 0
  let edges = 0
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const g = gray[y * w + x]
      varSum += (g - mean) * (g - mean)
      const dx = gray[y * w + x + 1] - gray[y * w + x - 1]
      const dy = gray[(y + 1) * w + x] - gray[(y - 1) * w + x]
      if (dx * dx + dy * dy > 900) edges++
    }
  }
  const std = Math.sqrt(varSum / gray.length)
  const edgeRatio = edges / ((w - 2) * (h - 2))
  // Empty table / wall: low variance and almost no edges.
  // Stricter thresholds to reduce false positives on background/noise
  return std > 28 && edgeRatio > 0.06
}

export async function loadImage(url: string): Promise<HTMLImageElement> {
  const img = new Image()
  img.crossOrigin = "anonymous"
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve()
    img.onerror = () => reject(new Error("img"))
    img.src = url
  })
  return img
}

export function canvasFromImage(img: HTMLImageElement): HTMLCanvasElement {
  const canvas = document.createElement("canvas")
  canvas.width = img.naturalWidth || img.width
  canvas.height = img.naturalHeight || img.height
  canvas.getContext("2d")!.drawImage(img, 0, 0)
  return canvas
}

const hashCache = new Map<string, Uint8Array>()

export async function officialArtHash(imageUrl: string): Promise<Uint8Array | null> {
  const cached = hashCache.get(imageUrl)
  if (cached) return cached
  try {
    const proxied = `/api/scan/image?url=${encodeURIComponent(imageUrl)}`
    const img = await loadImage(proxied)
    const hash = dHash(canvasFromImage(img))
    hashCache.set(imageUrl, hash)
    return hash
  } catch {
    return null
  }
}

export async function verifyAgainstOfficial(
  capturedArt: HTMLCanvasElement,
  imageUrl: string | null | undefined,
): Promise<number | null> {
  if (!imageUrl) return null
  const official = await officialArtHash(imageUrl)
  if (!official) return null
  return hashSimilarity(dHash(capturedArt), official)
}
