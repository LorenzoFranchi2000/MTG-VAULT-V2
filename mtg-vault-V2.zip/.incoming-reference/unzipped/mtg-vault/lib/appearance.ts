// Appearance presets applied as inline CSS custom properties on <html>, so they
// override the :root / .dark tokens defined in globals.css for both schemes.

import type { AccentKey, ShapeKey, DensityKey } from "./types"

// Each accent overrides --primary/--ring plus a readable --primary-foreground.
export const ACCENTS: Record<AccentKey, { primary: string; foreground: string; labelKey: string; swatch: string }> = {
  gold: {
    primary: "oklch(0.74 0.13 78)",
    foreground: "oklch(0.24 0.03 70)",
    labelKey: "accentGold",
    swatch: "#e7c86b",
  },
  blue: {
    primary: "oklch(0.62 0.15 245)",
    foreground: "oklch(0.98 0.01 245)",
    labelKey: "accentBlue",
    swatch: "#3f8ae0",
  },
  green: {
    primary: "oklch(0.64 0.15 150)",
    foreground: "oklch(0.99 0.01 150)",
    labelKey: "accentGreen",
    swatch: "#3fae74",
  },
  crimson: {
    primary: "oklch(0.58 0.21 20)",
    foreground: "oklch(0.99 0.01 20)",
    labelKey: "accentCrimson",
    swatch: "#d63c3c",
  },
  violet: {
    primary: "oklch(0.57 0.19 300)",
    foreground: "oklch(0.99 0.01 300)",
    labelKey: "accentViolet",
    swatch: "#a964d6",
  },
}

// Corner radius base value driving all --radius-* derivations.
export const SHAPES: Record<ShapeKey, { radius: string; labelKey: string }> = {
  sharp: { radius: "0.35rem", labelKey: "shapeSharp" },
  default: { radius: "0.9rem", labelKey: "shapeDefault" },
  round: { radius: "1.4rem", labelKey: "shapeRound" },
}

export const DENSITIES: Record<DensityKey, { labelKey: string }> = {
  comfortable: { labelKey: "densityComfortable" },
  compact: { labelKey: "densityCompact" },
}

// Number of grid columns used by tile grids for each density.
export function gridColsClass(density: DensityKey): string {
  // Extra breakpoints keep tablet landscape (iPad 10"+) filled with well sized
  // tiles instead of stretching five columns across the whole width.
  return density === "compact"
    ? "grid-cols-4 gap-2 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-9"
    : "grid-cols-3 gap-2.5 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7"
}

// Push accent + shape onto the document root as inline styles.
export function applyAppearance(accent: AccentKey, shape: ShapeKey): void {
  if (typeof document === "undefined") return
  const root = document.documentElement
  const a = ACCENTS[accent] ?? ACCENTS.gold
  const s = SHAPES[shape] ?? SHAPES.default
  root.style.setProperty("--primary", a.primary)
  root.style.setProperty("--ring", a.primary)
  root.style.setProperty("--primary-foreground", a.foreground)
  root.style.setProperty("--radius", s.radius)
}
