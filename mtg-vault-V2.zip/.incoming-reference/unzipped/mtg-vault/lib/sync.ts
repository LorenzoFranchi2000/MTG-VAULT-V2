// Client helpers for the self-hosted collection store (/api/store).
//
// These talk to the host machine so the collection is shared across every
// device on the network. All functions fail soft: if the server is unreachable
// (offline, dev server down) they resolve to null / false and the caller falls
// back to the local IndexedDB cache.
//
// Gated behind NEXT_PUBLIC_LAN_SYNC=1 — see app/api/store/route.ts for why:
// this is for your own devices on your own LAN, not a shared/public build
// that other people install. With the flag unset (the default, and what a
// public deployment should ship with), these never even hit the network —
// every install just keeps its own local IndexedDB collection.

import type { Entry, Folder } from "./types"

const SYNC_ENABLED = process.env.NEXT_PUBLIC_LAN_SYNC === "1"

export interface RemoteDoc {
  entries: Entry[]
  folders: Folder[]
  updatedAt: number
}

export async function remoteGet(): Promise<RemoteDoc | null> {
  if (!SYNC_ENABLED) return null
  try {
    const res = await fetch("/api/store", { cache: "no-store" })
    if (!res.ok) return null
    const data = await res.json()
    return {
      entries: Array.isArray(data.entries) ? data.entries : [],
      folders: Array.isArray(data.folders) ? data.folders : [],
      updatedAt: typeof data.updatedAt === "number" ? data.updatedAt : 0,
    }
  } catch {
    return null
  }
}

export async function remotePut(entries: Entry[], folders: Folder[]): Promise<number | null> {
  if (!SYNC_ENABLED) return null
  try {
    const res = await fetch("/api/store", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ entries, folders }),
    })
    if (!res.ok) return null
    const data = await res.json()
    return typeof data.updatedAt === "number" ? data.updatedAt : Date.now()
  } catch {
    return null
  }
}
