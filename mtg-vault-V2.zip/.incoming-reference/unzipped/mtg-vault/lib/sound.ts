// Lightweight WebAudio blip used for scanner feedback. No assets to load —
// the tone is synthesized on the fly, so it works offline and adds no weight.

let ctx: AudioContext | null = null

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext
      if (!AC) return null
      ctx = new AC()
    }
    // Browsers may suspend the context until a user gesture resumes it.
    if (ctx.state === "suspended") void ctx.resume()
    return ctx
  } catch {
    return null
  }
}

/**
 * Unlock/warm up the audio context from within a user gesture (e.g. the
 * "Start camera" tap) so later programmatic beeps are allowed to play.
 */
export function primeAudio(): void {
  getCtx()
}

/**
 * Play a short, clean two-tone "beep" — a quick confirmation cue for a
 * successful scan. Safe to call rapidly; failures are swallowed silently.
 */
export function beep(): void {
  const audio = getCtx()
  if (!audio) return
  try {
    const now = audio.currentTime
    const gain = audio.createGain()
    gain.connect(audio.destination)
    // Fast attack, short decay — crisp and unobtrusive.
    gain.gain.setValueAtTime(0.0001, now)
    gain.gain.exponentialRampToValueAtTime(0.15, now + 0.01)
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.18)

    const osc = audio.createOscillator()
    osc.type = "sine"
    osc.frequency.setValueAtTime(880, now) // A5
    osc.frequency.setValueAtTime(1320, now + 0.09) // E6 — rising "ding"
    osc.connect(gain)
    osc.start(now)
    osc.stop(now + 0.2)
  } catch {
    // Ignore — audio is a non-critical enhancement.
  }
}
