// Core domain types for the MTG collection vault.

import type { BackgroundKey, FolderIconKey } from "./folder-style"

export type LangCode = "it" | "en"

// Card condition grades (Dragon Shield style).
export type Condition = "NM" | "LP" | "MP" | "HP" | "DMG"
export const CONDITIONS: Condition[] = ["NM", "LP", "MP", "HP", "DMG"]

export interface Folder {
  id: string
  name: string
  color: string // hex, user-customizable
  createdAt: number
  icon?: FolderIconKey
  background?: BackgroundKey
}

export interface PricePoint {
  date: string // YYYY-MM-DD
  eur: number | null
  usd: number | null
  estimated: boolean
}

export interface CardData {
  id: string // scryfall id
  oracleId: string
  name: string
  printedName?: string
  setName: string
  set: string
  collectorNumber: string
  rarity: string
  image: string | null
  imageLarge: string | null
  artCrop?: string | null
  manaCost?: string
  cmc?: number // converted mana cost / mana value
  typeLine?: string
  oracleText?: string
  flavorText?: string
  artist?: string
  rulingsUri?: string
  colors: string[]
  colorIdentity: string[]
  legalities: Record<string, string>
  eur: number | null
  eurFoil: number | null
  usd: number | null
  usdFoil: number | null
  cardmarketUrl?: string
  scryfallUrl?: string
}

export interface Entry {
  id: string // local uuid
  card: CardData
  quantity: number
  foil: boolean
  condition: Condition
  language?: string // MTG language code: en, it, fr, de, es, pt, ja, ko, ru, zhs, zht
  purchasePrice?: number // price paid per card, in the app's currency at time of add
  folderId: string | null
  position: string // page/slot within the folder, e.g. "12-A"
  note?: string
  addedAt: number
  priceHistory: PricePoint[]
  lastPriceSync?: string // YYYY-MM-DD
}

export type AccentKey = "gold" | "blue" | "green" | "crimson" | "violet"
export type ShapeKey = "sharp" | "default" | "round"
export type DensityKey = "comfortable" | "compact"

export interface Settings {
  lang: LangCode
  theme: "light" | "dark" | "system"
  currency: "eur" | "usd"
  accent: AccentKey
  shape: ShapeKey
  density: DensityKey
  // Backdrop applied behind the collection / folder views.
  collectionBackground: BackgroundKey
}
