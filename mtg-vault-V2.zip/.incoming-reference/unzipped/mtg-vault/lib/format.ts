export function money(value: number | null | undefined, currency: "eur" | "usd"): string {
  if (value == null) return currency === "eur" ? "—" : "—"
  const symbol = currency === "eur" ? "€" : "$"
  return `${symbol}${value.toFixed(2)}`
}

export function signedPct(value: number | null | undefined): string {
  if (value == null) return "—"
  const s = value >= 0 ? "+" : ""
  return `${s}${value.toFixed(1)}%`
}

// Readable contrast color (black/white) for a given hex background.
export function contrastText(hex: string): string {
  const h = hex.replace("#", "")
  if (h.length < 6) return "#000"
  const r = parseInt(h.slice(0, 2), 16)
  const g = parseInt(h.slice(2, 4), 16)
  const b = parseInt(h.slice(4, 6), 16)
  const l = (0.299 * r + 0.587 * g + 0.114 * b) / 255
  return l > 0.6 ? "#1a1a24" : "#ffffff"
}
