// Tiny promise-based IndexedDB key/value wrapper.
// Works fully offline on low-end tablets, with a localStorage fallback.

const DB_NAME = "helavault-db"
const STORE = "kv"
const VERSION = 1

let dbPromise: Promise<IDBDatabase> | null = null

function open(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("no-idb"))
      return
    }
    const req = indexedDB.open(DB_NAME, VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE)
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
  return dbPromise
}

export async function idbGet<T>(key: string): Promise<T | null> {
  try {
    const db = await open()
    return await new Promise<T | null>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly")
      const req = tx.objectStore(STORE).get(key)
      req.onsuccess = () => resolve((req.result as T) ?? null)
      req.onerror = () => reject(req.error)
    })
  } catch {
    try {
      const v = localStorage.getItem(DB_NAME + ":" + key)
      return v ? (JSON.parse(v) as T) : null
    } catch {
      return null
    }
  }
}

export async function idbSet<T>(key: string, value: T): Promise<void> {
  try {
    const db = await open()
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite")
      tx.objectStore(STORE).put(value, key)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
  } catch {
    try {
      localStorage.setItem(DB_NAME + ":" + key, JSON.stringify(value))
    } catch {
      /* ignore quota errors */
    }
  }
}
