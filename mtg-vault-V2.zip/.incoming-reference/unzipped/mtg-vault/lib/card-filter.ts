// Pure filter + sort logic for card entries. Kept framework-agnostic so the
// same rules power both folder and collection views, and so filtering and
// sorting compose cleanly: filter narrows the set, sort orders whatever remains.

import type { Entry } from "./types"
import { entryUnitPrice } from "./prices"

export type ColorFilter = "W" | "U" | "B" | "R" | "G" | "C"
export type SortKey = "name" | "nameDesc" | "priceAsc" | "priceDesc"

// Derive the mana value from a mana-cost string like "{2}{B}{B}" when the
// explicit `cmc` field is missing (e.g. cards stored before it was tracked).
// Generic numbers add their value; X/Y/Z add 0; every other symbol adds 1.
export function manaValueFromCost(cost?: string): number {
  if (!cost) return 0
  let total = 0
  const symbols = cost.match(/\{([^}]+)\}/g) ?? []
  for (const s of symbols) {
    const inner = s.slice(1, -1)
    const n = Number.parseInt(inner, 10)
    if (Number.isFinite(n)) total += n
    else if (/^[xyz]$/i.test(inner)) total += 0
    else total += 1
  }
  return total
}

// Extract WUBRG colors present in a mana-cost string, as a fallback for cards
// whose colorIdentity/colors arrays weren't stored.
export function colorsFromCost(cost?: string): ColorFilter[] {
  if (!cost) return []
  const set = new Set<ColorFilter>()
  for (const ch of cost.toUpperCase()) {
    if (ch === "W" || ch === "U" || ch === "B" || ch === "R" || ch === "G") set.add(ch)
  }
  return [...set]
}

export interface FilterState {
  // Selected colors; empty = all. A card matches if it shares ANY selected color
  // (or is colorless when "C" is selected).
  colors: ColorFilter[]
  // Converted mana cost bounds (inclusive). null = unbounded on that side.
  cmcMin: number | null
  cmcMax: number | null
}

export const EMPTY_FILTER: FilterState = { colors: [], cmcMin: null, cmcMax: null }

export function isFilterActive(f: FilterState): boolean {
  return f.colors.length > 0 || f.cmcMin != null || f.cmcMax != null
}

function entryColors(e: Entry): ColorFilter[] {
  const id = e.card.colorIdentity?.length ? e.card.colorIdentity : e.card.colors
  const explicit = (id ?? []).filter((c): c is ColorFilter => ["W", "U", "B", "R", "G"].includes(c))
  if (explicit.length > 0) return explicit
  // Fall back to parsing the mana cost for older entries missing color arrays.
  const fromCost = colorsFromCost(e.card.manaCost)
  return fromCost.length > 0 ? fromCost : ["C"]
}

function entryCmc(e: Entry): number {
  return typeof e.card.cmc === "number" ? e.card.cmc : manaValueFromCost(e.card.manaCost)
}

function matchesFilter(e: Entry, f: FilterState): boolean {
  // Color: match if the card shares at least one selected color.
  if (f.colors.length > 0) {
    const cols = entryColors(e)
    if (!f.colors.some((c) => cols.includes(c))) return false
  }
  // CMC range.
  const cmc = entryCmc(e)
  if (f.cmcMin != null && cmc < f.cmcMin) return false
  if (f.cmcMax != null && cmc > f.cmcMax) return false
  return true
}

/**
 * Apply filtering, then sorting, in one deterministic pass. Sorting always uses
 * the English card name (`card.name`) as the primary alphabetical reference,
 * with name as a stable tiebreaker for price sorts.
 */
export function applyFilterSort(
  entries: Entry[],
  filter: FilterState,
  sort: SortKey,
  currency: "eur" | "usd",
): Entry[] {
  const filtered = entries.filter((e) => matchesFilter(e, filter))
  const byName = (a: Entry, b: Entry) =>
    (a.card.name || "").localeCompare(b.card.name || "", "en", { sensitivity: "base" })

  const sorted = [...filtered].sort((a, b) => {
    if (sort === "name") return byName(a, b)
    if (sort === "nameDesc") return byName(b, a)
    const pa = entryUnitPrice(a, currency)
    const pb = entryUnitPrice(b, currency)
    if (pa !== pb) return sort === "priceAsc" ? pa - pb : pb - pa
    return byName(a, b)
  })
  return sorted
}
