// MTG card languages supported by Scryfall, with flag images and display labels.

export interface CardLang {
  code: string // Scryfall language code
  label: string // native short label
  flag: string // ISO country code for flagcdn
}

export const CARD_LANGUAGES: CardLang[] = [
  { code: "en", label: "EN", flag: "gb" },
  { code: "it", label: "IT", flag: "it" },
  { code: "fr", label: "FR", flag: "fr" },
  { code: "de", label: "DE", flag: "de" },
  { code: "es", label: "ES", flag: "es" },
  { code: "pt", label: "PT", flag: "pt" },
  { code: "ja", label: "JA", flag: "jp" },
  { code: "ko", label: "KO", flag: "kr" },
  { code: "ru", label: "RU", flag: "ru" },
  { code: "zhs", label: "ZH", flag: "cn" },
  { code: "zht", label: "ZH-T", flag: "tw" },
]

const BY_CODE = new Map(CARD_LANGUAGES.map((l) => [l.code, l]))

export function cardLang(code: string | undefined | null): CardLang {
  return (code && BY_CODE.get(code)) || CARD_LANGUAGES[0]
}

// 40px-wide PNG flag from flagcdn (crisp on cheap tablets, tiny payload).
export function flagUrl(iso: string): string {
  return `https://flagcdn.com/w40/${iso}.png`
}
