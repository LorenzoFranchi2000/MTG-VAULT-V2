// Collection import/export.
//
// Import understands the two CSV dialects users actually have (Dragon Shield
// MTG Card Manager and Delver Lens) plus the plain "1x Card Name [SET]" deck
// list format. Parsing never throws: unparseable lines are reported back to the
// caller so the UI can show a per-row report instead of crashing.

import type { CardData, Condition, Entry, Folder, LangCode } from "./types"
import { CONDITIONS } from "./types"
import { collectionByIdentifiers, type CardIdentifier } from "./scryfall"

export interface ImportRow {
  name: string
  setCode?: string
  collectorNumber?: string
  quantity: number
  foil: boolean
  condition?: Condition
  language?: string
  folderName?: string
  purchasePrice?: number
  /** Original line/record, echoed back in the failure report. */
  source: string
}

export interface ParseResult {
  rows: ImportRow[]
  /** Lines that could not be understood at all. */
  skipped: string[]
  format: "dragonshield" | "delver" | "csv" | "txt" | "unknown"
}

export interface ResolvedRow {
  row: ImportRow
  card: CardData
}

export interface ResolveResult {
  resolved: ResolvedRow[]
  failed: ImportRow[]
}

// ---------------------------------------------------------------- CSV parsing

/** RFC4180-ish splitter: handles quoted fields, escaped quotes and CRLF. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = []
  let field = ""
  let row: string[] = []
  let quoted = false
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"'
          i++
        } else quoted = false
      } else field += ch
      continue
    }
    if (ch === '"') quoted = true
    else if (ch === "," || ch === ";" || ch === "\t") {
      row.push(field)
      field = ""
    } else if (ch === "\n") {
      row.push(field)
      rows.push(row)
      row = []
      field = ""
    } else if (ch !== "\r") field += ch
  }
  row.push(field)
  rows.push(row)
  return rows.filter((r) => r.some((c) => c.trim() !== ""))
}

function normHeader(h: string): string {
  return h.toLowerCase().replace(/[^a-z0-9]/g, "")
}

// Header aliases across the supported exports.
const H = {
  name: ["cardname", "name", "card", "englishname"],
  set: ["setcode", "set", "edition", "editioncode", "expansion", "setid"],
  setName: ["setname", "expansionname"],
  number: ["cardnumber", "collectornumber", "number", "cardnum", "no"],
  quantity: ["quantity", "count", "qty", "amount", "cardcount"],
  foil: ["foil", "printing", "isfoil", "finish", "foiling"],
  condition: ["condition", "cond", "grade"],
  language: ["language", "lang"],
  folder: ["foldername", "folder", "binder", "list", "collection"],
  price: ["pricebought", "purchaseprice", "price", "paid"],
} as const

function indexOfHeader(headers: string[], aliases: readonly string[]): number {
  return headers.findIndex((h) => aliases.includes(h))
}

function toQuantity(raw: string | undefined): number {
  const n = Number.parseInt((raw ?? "").replace(/[^\d-]/g, ""), 10)
  return Number.isFinite(n) && n > 0 ? n : 1
}

function toFoil(raw: string | undefined): boolean {
  const v = (raw ?? "").trim().toLowerCase()
  if (!v) return false
  return (
    v === "foil" ||
    v === "yes" ||
    v === "true" ||
    v === "1" ||
    v === "y" ||
    v.includes("foil") // "Foil", "Etched Foil", "*F*"
  )
}

function toCondition(raw: string | undefined): Condition | undefined {
  const v = (raw ?? "").trim().toLowerCase().replace(/[^a-z]/g, "")
  if (!v) return undefined
  const direct = CONDITIONS.find((c) => c.toLowerCase() === v)
  if (direct) return direct
  const map: Record<string, Condition> = {
    mint: "NM",
    nearmint: "NM",
    excellent: "LP",
    lightplayed: "LP",
    lightlyplayed: "LP",
    good: "LP",
    played: "MP",
    moderatelyplayed: "MP",
    heavilyplayed: "HP",
    poor: "DMG",
    damaged: "DMG",
  }
  return map[v]
}

// Long language names used by Dragon Shield/Delver → MTG language codes.
const LANGUAGES: Record<string, string> = {
  english: "en",
  italian: "it",
  italiano: "it",
  french: "fr",
  german: "de",
  deutsch: "de",
  spanish: "es",
  portuguese: "pt",
  japanese: "ja",
  korean: "ko",
  russian: "ru",
  chinesesimplified: "zhs",
  chinesetraditional: "zht",
}

function toLanguage(raw: string | undefined): string | undefined {
  const v = (raw ?? "").trim().toLowerCase().replace(/[^a-z]/g, "")
  if (!v) return undefined
  return LANGUAGES[v] ?? v.slice(0, 3)
}

function toPrice(raw: string | undefined): number | undefined {
  if (!raw) return undefined
  const n = Number.parseFloat(raw.replace(/[^\d.,-]/g, "").replace(",", "."))
  return Number.isFinite(n) ? n : undefined
}

function parseCsvText(text: string): ParseResult {
  const grid = parseCsv(text)
  const skipped: string[] = []
  // Dragon Shield prefixes its export with a `sep=,` line; some tools add a
  // title line. Find the first row that looks like a header.
  const headerIdx = grid.findIndex((r) => {
    const hs = r.map(normHeader)
    return indexOfHeader(hs, H.name) >= 0 && (indexOfHeader(hs, H.quantity) >= 0 || indexOfHeader(hs, H.set) >= 0)
  })
  if (headerIdx < 0) return { rows: [], skipped: grid.map((r) => r.join(",")), format: "unknown" }

  const headers = grid[headerIdx].map(normHeader)
  const idx = {
    name: indexOfHeader(headers, H.name),
    set: indexOfHeader(headers, H.set),
    number: indexOfHeader(headers, H.number),
    quantity: indexOfHeader(headers, H.quantity),
    foil: indexOfHeader(headers, H.foil),
    condition: indexOfHeader(headers, H.condition),
    language: indexOfHeader(headers, H.language),
    folder: indexOfHeader(headers, H.folder),
    price: indexOfHeader(headers, H.price),
  }
  const format: ParseResult["format"] = headers.includes("foldername")
    ? "dragonshield"
    : headers.includes("count")
      ? "delver"
      : "csv"

  const rows: ImportRow[] = []
  for (let i = headerIdx + 1; i < grid.length; i++) {
    const cells = grid[i]
    const source = cells.join(",")
    const name = (cells[idx.name] ?? "").trim()
    if (!name) {
      skipped.push(source)
      continue
    }
    rows.push({
      name,
      setCode: idx.set >= 0 ? cells[idx.set]?.trim().toLowerCase() || undefined : undefined,
      collectorNumber: idx.number >= 0 ? cells[idx.number]?.trim() || undefined : undefined,
      quantity: toQuantity(idx.quantity >= 0 ? cells[idx.quantity] : undefined),
      foil: idx.foil >= 0 ? toFoil(cells[idx.foil]) : false,
      condition: idx.condition >= 0 ? toCondition(cells[idx.condition]) : undefined,
      language: idx.language >= 0 ? toLanguage(cells[idx.language]) : undefined,
      folderName: idx.folder >= 0 ? cells[idx.folder]?.trim() || undefined : undefined,
      purchasePrice: idx.price >= 0 ? toPrice(cells[idx.price]) : undefined,
      source,
    })
  }
  return { rows, skipped, format }
}

// ---------------------------------------------------------------- TXT parsing

// Deck-list section markers that must not be treated as card names.
const SECTION_HEADERS = new Set([
  "deck",
  "maindeck",
  "main",
  "sideboard",
  "commander",
  "companion",
  "maybeboard",
  "tokens",
  "other",
])

// "1x Sol Ring [C21] 263 *F*", "1 Sol Ring (C21) 263", "Sol Ring"
const TXT_LINE = /^\s*(?:(\d+)\s*[xX]?\s+)?([^[(\n]+?)\s*(?:[[(]([A-Za-z0-9]{2,6})[\])])?\s*(\d+[a-z]?)?\s*(\*F\*|\(foil\)|foil)?\s*$/i

function parseTxtText(text: string): ParseResult {
  const rows: ImportRow[] = []
  const skipped: string[] = []
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith("//") || line.startsWith("#")) continue
    if (SECTION_HEADERS.has(line.toLowerCase().replace(/[^a-z]/g, ""))) continue
    const m = TXT_LINE.exec(line)
    const name = m?.[2]?.trim()
    if (!m || !name || name.length < 2) {
      skipped.push(line)
      continue
    }
    rows.push({
      name,
      setCode: m[3]?.toLowerCase(),
      collectorNumber: m[4],
      quantity: toQuantity(m[1]),
      foil: Boolean(m[5]),
      source: line,
    })
  }
  return { rows, skipped, format: "txt" }
}

/** Entry point: picks the parser from the file name and the content shape. */
export function parseImport(text: string, fileName = ""): ParseResult {
  try {
    const isCsv =
      /\.csv$/i.test(fileName) ||
      (!/\.txt$/i.test(fileName) && /^[^\n]*[,;\t][^\n]*\n/.test(text) && /name/i.test(text.slice(0, 500)))
    return isCsv ? parseCsvText(text) : parseTxtText(text)
  } catch {
    return { rows: [], skipped: [text.slice(0, 200)], format: "unknown" }
  }
}

// ------------------------------------------------------------- Card resolving

function keyOf(setCode: string | undefined, collectorNumber: string | undefined): string {
  return `${(setCode ?? "").toLowerCase()}/${(collectorNumber ?? "").toLowerCase()}`
}

function normName(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "")
}

/**
 * Resolve parsed rows against Scryfall. Rows that cannot be matched are
 * returned in `failed` so the caller can report "150 of 152 imported".
 */
export async function resolveRows(
  rows: ImportRow[],
  lang: LangCode,
  onProgress?: (done: number, total: number) => void,
): Promise<ResolveResult> {
  const identifiers: CardIdentifier[] = rows.map((r) =>
    r.setCode && r.collectorNumber
      ? { set: r.setCode, collector_number: r.collectorNumber }
      : r.setCode
        ? { name: r.name, set: r.setCode }
        : { name: r.name },
  )

  const found = await collectionByIdentifiers(identifiers, lang, onProgress)

  const bySetNumber = new Map<string, CardData>()
  const byName = new Map<string, CardData>()
  for (const c of found) {
    bySetNumber.set(keyOf(c.set, c.collectorNumber), c)
    const n = normName(c.name)
    if (!byName.has(n)) byName.set(n, c)
    if (c.printedName) {
      const p = normName(c.printedName)
      if (!byName.has(p)) byName.set(p, c)
    }
  }

  const resolved: ResolvedRow[] = []
  const failed: ImportRow[] = []
  for (const row of rows) {
    const card =
      bySetNumber.get(keyOf(row.setCode, row.collectorNumber)) ??
      byName.get(normName(row.name)) ??
      null
    if (card) resolved.push({ row, card })
    else failed.push(row)
  }
  return { resolved, failed }
}

// -------------------------------------------------------------------- Export

const EXPORT_HEADERS = [
  "Quantity",
  "Name",
  "Set Code",
  "Set Name",
  "Card Number",
  "Foil",
  "Condition",
  "Language",
  "Folder Name",
  "Price Bought",
  "Scryfall ID",
] as const

function csvCell(value: string | number | null | undefined): string {
  const s = value == null ? "" : String(value)
  return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

/** Dragon-Shield-compatible CSV of the whole collection. */
export function entriesToCsv(entries: Entry[], folders: Folder[]): string {
  const folderName = new Map(folders.map((f) => [f.id, f.name]))
  const lines = [EXPORT_HEADERS.join(",")]
  for (const e of entries) {
    lines.push(
      [
        e.quantity,
        e.card.name,
        e.card.set.toUpperCase(),
        e.card.setName,
        e.card.collectorNumber,
        e.foil ? "Foil" : "Normal",
        e.condition,
        (e.language ?? "en").toUpperCase(),
        e.folderId ? folderName.get(e.folderId) ?? "" : "",
        e.purchasePrice ?? "",
        e.card.id,
      ]
        .map(csvCell)
        .join(","),
    )
  }
  return lines.join("\n")
}

export function downloadFile(content: string, fileName: string, mime: string): void {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = fileName
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
