import type { Condition } from "./types"

// Short badge label + a token-based color for each grade.
export const CONDITION_META: Record<Condition, { short: string; color: string }> = {
  NM: { short: "NM", color: "oklch(0.62 0.15 150)" }, // green
  LP: { short: "LP", color: "oklch(0.7 0.14 130)" }, // yellow-green
  MP: { short: "MP", color: "oklch(0.74 0.13 78)" }, // amber
  HP: { short: "HP", color: "oklch(0.65 0.18 45)" }, // orange
  DMG: { short: "DMG", color: "oklch(0.58 0.2 25)" }, // red
}

export function conditionKey(c: Condition): string {
  return "cond" + c
}

// Safe lookup for legacy entries saved before conditions existed.
export function conditionMeta(c: Condition | undefined | null) {
  return CONDITION_META[(c as Condition) in CONDITION_META ? (c as Condition) : "NM"]
}

export function safeCondition(c: Condition | undefined | null): Condition {
  return (c as Condition) in CONDITION_META ? (c as Condition) : "NM"
}
