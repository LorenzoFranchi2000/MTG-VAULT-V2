// Per-folder visual customisation: icon pack + background pack.
// Everything is expressed as plain CSS so a folder style can be stored as two
// short string keys plus the accent color the user already picks.

import type { CSSProperties } from "react"
import {
  Anchor,
  Archive,
  Award,
  Axe,
  BookOpen,
  Boxes,
  Castle,
  Circle,
  Crown,
  Diamond,
  Droplet,
  Feather,
  Flame,
  FolderOpen,
  Gem,
  Ghost,
  Heart,
  Hexagon,
  Key,
  Layers,
  Leaf,
  Library,
  Moon,
  Mountain,
  Package,
  Rocket,
  Shield,
  Skull,
  Snowflake,
  Sparkles,
  Square,
  Star,
  Sun,
  Sword,
  Swords,
  Target,
  Triangle,
  Trophy,
  WandSparkles,
  Zap,
  type LucideIcon,
} from "lucide-react"

export type FolderIconKey =
  | "folder"
  | "layers"
  | "library"
  | "archive"
  | "boxes"
  | "package"
  | "bookOpen"
  | "trophy"
  | "award"
  | "crown"
  | "shield"
  | "sword"
  | "swords"
  | "axe"
  | "castle"
  | "target"
  | "key"
  | "anchor"
  | "rocket"
  | "ghost"
  | "skull"
  | "heart"
  | "star"
  | "sparkles"
  | "gem"
  | "diamond"
  | "circle"
  | "square"
  | "triangle"
  | "hexagon"
  | "manaWhite"
  | "manaBlue"
  | "manaBlack"
  | "manaRed"
  | "manaGreen"
  | "manaColorless"
  | "wand"
  | "feather"
  | "snowflake"
  | "mountain"

export type FolderIconGroup = "shapes" | "mana" | "rarity" | "objects"

export const FOLDER_ICONS: Record<FolderIconKey, { icon: LucideIcon; group: FolderIconGroup }> = {
  folder: { icon: FolderOpen, group: "objects" },
  layers: { icon: Layers, group: "objects" },
  library: { icon: Library, group: "objects" },
  archive: { icon: Archive, group: "objects" },
  boxes: { icon: Boxes, group: "objects" },
  package: { icon: Package, group: "objects" },
  bookOpen: { icon: BookOpen, group: "objects" },
  trophy: { icon: Trophy, group: "rarity" },
  award: { icon: Award, group: "rarity" },
  crown: { icon: Crown, group: "rarity" },
  gem: { icon: Gem, group: "rarity" },
  star: { icon: Star, group: "rarity" },
  sparkles: { icon: Sparkles, group: "rarity" },
  shield: { icon: Shield, group: "objects" },
  sword: { icon: Sword, group: "objects" },
  swords: { icon: Swords, group: "objects" },
  axe: { icon: Axe, group: "objects" },
  castle: { icon: Castle, group: "objects" },
  target: { icon: Target, group: "objects" },
  key: { icon: Key, group: "objects" },
  anchor: { icon: Anchor, group: "objects" },
  rocket: { icon: Rocket, group: "objects" },
  ghost: { icon: Ghost, group: "objects" },
  skull: { icon: Skull, group: "mana" },
  heart: { icon: Heart, group: "objects" },
  diamond: { icon: Diamond, group: "shapes" },
  circle: { icon: Circle, group: "shapes" },
  square: { icon: Square, group: "shapes" },
  triangle: { icon: Triangle, group: "shapes" },
  hexagon: { icon: Hexagon, group: "shapes" },
  manaWhite: { icon: Sun, group: "mana" },
  manaBlue: { icon: Droplet, group: "mana" },
  manaBlack: { icon: Moon, group: "mana" },
  manaRed: { icon: Flame, group: "mana" },
  manaGreen: { icon: Leaf, group: "mana" },
  manaColorless: { icon: Hexagon, group: "mana" },
  wand: { icon: WandSparkles, group: "objects" },
  feather: { icon: Feather, group: "objects" },
  snowflake: { icon: Snowflake, group: "shapes" },
  mountain: { icon: Mountain, group: "shapes" },
}

export const FOLDER_ICON_KEYS = Object.keys(FOLDER_ICONS) as FolderIconKey[]
export const DEFAULT_FOLDER_ICON: FolderIconKey = "folder"

export function folderIcon(key: FolderIconKey | undefined): LucideIcon {
  return FOLDER_ICONS[key ?? DEFAULT_FOLDER_ICON]?.icon ?? FolderOpen
}

// ------------------------------------------------------------- Backgrounds

export type BackgroundKey =
  | "plain"
  | "tint"
  | "gradient"
  | "aurora"
  | "glass"
  | "carbon"
  | "dots"
  | "grid"
  | "diagonal"
  | "rays"
  | "mesh"
  | "parchment"

export const BACKGROUND_KEYS: BackgroundKey[] = [
  "plain",
  "tint",
  "gradient",
  "aurora",
  "glass",
  "carbon",
  "dots",
  "grid",
  "diagonal",
  "rays",
  "mesh",
  "parchment",
]

export const DEFAULT_BACKGROUND: BackgroundKey = "plain"

/** #rrggbb → rgba(r,g,b,alpha). Falls back to the raw value for named colors. */
export function withAlpha(hex: string, alpha: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return hex
  const n = Number.parseInt(m[1], 16)
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`
}

/** Inline style implementing the chosen texture, tinted with the folder color. */
export function backgroundStyle(key: BackgroundKey | undefined, color: string): CSSProperties {
  const k = key ?? DEFAULT_BACKGROUND
  const a = (v: number) => withAlpha(color, v)
  switch (k) {
    case "tint":
      return { backgroundColor: a(0.14) }
    case "gradient":
      return { backgroundImage: `linear-gradient(135deg, ${a(0.42)} 0%, ${a(0.06)} 55%, transparent 100%)` }
    case "aurora":
      return {
        backgroundImage: `radial-gradient(120% 90% at 0% 0%, ${a(0.5)} 0%, transparent 55%), radial-gradient(90% 80% at 100% 100%, ${a(
          0.32,
        )} 0%, transparent 60%)`,
      }
    case "glass":
      return {
        backgroundImage: `linear-gradient(135deg, ${a(0.3)} 0%, rgba(255,255,255,0.07) 100%)`,
        backdropFilter: "blur(14px) saturate(150%)",
        WebkitBackdropFilter: "blur(14px) saturate(150%)",
        borderColor: a(0.45),
      } as CSSProperties
    case "carbon":
      return {
        backgroundColor: a(0.1),
        backgroundImage: `repeating-linear-gradient(45deg, rgba(0,0,0,0.16) 0 2px, transparent 2px 5px), repeating-linear-gradient(-45deg, rgba(255,255,255,0.05) 0 2px, transparent 2px 5px)`,
      }
    case "dots":
      return {
        backgroundColor: a(0.08),
        backgroundImage: `radial-gradient(${a(0.7)} 1.3px, transparent 1.4px)`,
        backgroundSize: "14px 14px",
      }
    case "grid":
      return {
        backgroundColor: a(0.07),
        backgroundImage: `linear-gradient(${a(0.32)} 1px, transparent 1px), linear-gradient(90deg, ${a(
          0.32,
        )} 1px, transparent 1px)`,
        backgroundSize: "22px 22px",
      }
    case "diagonal":
      return {
        backgroundColor: a(0.08),
        backgroundImage: `repeating-linear-gradient(115deg, ${a(0.28)} 0 6px, transparent 6px 16px)`,
      }
    case "rays":
      return {
        backgroundColor: a(0.08),
        backgroundImage: `conic-gradient(from 210deg at 20% 0%, ${a(0.45)} 0deg, transparent 60deg, ${a(
          0.3,
        )} 140deg, transparent 220deg)`,
      }
    case "mesh":
      return {
        backgroundImage: `radial-gradient(60% 60% at 15% 20%, ${a(0.55)} 0%, transparent 60%), radial-gradient(50% 50% at 85% 15%, rgba(255,255,255,0.16) 0%, transparent 60%), radial-gradient(70% 70% at 60% 100%, ${a(
          0.35,
        )} 0%, transparent 65%)`,
      }
    case "parchment":
      return {
        backgroundColor: a(0.12),
        backgroundImage: `repeating-linear-gradient(0deg, rgba(0,0,0,0.05) 0 1px, transparent 1px 4px), radial-gradient(100% 100% at 50% 0%, rgba(255,255,255,0.12) 0%, transparent 70%)`,
      }
    case "plain":
    default:
      return {}
  }
}

/** Extra classes some textures need (blur cannot be expressed by style alone). */
export function backgroundClass(key: BackgroundKey | undefined): string {
  return (key ?? DEFAULT_BACKGROUND) === "glass" ? "backdrop-blur-md" : ""
}

export type BackgroundLabelKey = `bg${Capitalize<BackgroundKey>}`

/** i18n key for a background name ("aurora" → "bgAurora"). */
export function backgroundLabelKey(key: BackgroundKey): BackgroundLabelKey {
  return `bg${key.charAt(0).toUpperCase()}${key.slice(1)}` as BackgroundLabelKey
}
